@echo off
echo ========================================================
echo Running Backend Test Suite (Pytest)
echo ========================================================
cd backend
python -m pytest tests/test_core.py -v
pause
