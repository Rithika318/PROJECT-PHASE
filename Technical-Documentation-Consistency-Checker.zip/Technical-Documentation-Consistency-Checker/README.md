# LLM-Based Technical Documentation Consistency Checker

> **Final-Year Project • 100% Local & Offline AI Architecture**  
> An automated consistency, contradiction, and discrepancy checking platform for technical documentation, API specifications, and software manuals using Sentence-BERT, DeBERTa-v3 NLI, and local Llama 3.1 via Ollama.

---

## 📁 1. Project Folder Structure

```
Technical-Documentation-Consistency-Checker/
├── frontend/                     # React + Vite + Tailwind CSS Frontend Client
│   ├── src/
│   │   ├── components/           # UI components (charts, headers, modals, cards)
│   │   ├── context/              # AuthContext for JWT authentication
│   │   ├── layouts/              # DashboardLayout with sidebar navigation
│   │   ├── pages/                # Login, Dashboard, Compare/New Analysis, Results, History, Reviews, etc.
│   │   └── services/             # API client connecting frontend to backend
│   ├── package.json              # Frontend npm dependencies
│   └── vite.config.ts            # Vite configuration & proxy settings
├── backend/                      # Python FastAPI Application
│   ├── app/
│   │   ├── api/                  # REST API endpoints (auth, compare, upload, history, issues, reports)
│   │   ├── core/                 # Configuration, security (bcrypt & JWT), constants
│   │   ├── database/             # SQLite SQLAlchemy engine, session, Base
│   │   ├── document_processing/  # Multi-format extractors (PDF, DOCX, TXT) and chunker
│   │   ├── ml/                   # Sentence-BERT embeddings, DeBERTa-v3 NLI, local Ollama client, scorer
│   │   ├── models/               # SQLAlchemy ORM models (User, Document, Analysis, DetectedIssue)
│   │   ├── reports/              # ReportLab formal PDF and CSV export generators
│   │   └── services/             # Analysis orchestrator and sample document generators
│   ├── tests/                    # Pytest test suite (14 automated unit & integration tests)
│   └── requirements.txt          # Python pip dependencies
├── database/                     # SQLite Database Storage & DDL
│   ├── schema.sql                # Complete SQL DDL schema for all tables and indices
│   ├── init_db.py                # Standalone DB initialization & seed script
│   └── consistency_checker.db    # SQLite database file with seeded demo account
├── reports/                      # Exported formal PDF audit reports
│   └── test_output.pdf           # Sample generated multi-page audit report
├── requirements.txt              # Root Python dependencies file
├── .env.example                  # Environment configuration template
├── .gitignore                    # Git ignore file
├── start_backend.bat             # One-click Windows startup script for FastAPI
├── start_frontend.bat            # One-click Windows startup script for React Vite
├── start_all.bat                 # Launches both backend and frontend simultaneously
└── README.md                     # Comprehensive documentation & execution instructions
```

---

## 📌 2. Project Objective & Core Problem

Technical software teams maintain a complex web of documentation: REST API guides, user manuals, deployment runbooks, software architecture specifications, and SDK references. As software evolves across releases, documentation inevitably degrades:
- **Contradictory specifications**: One guide states port `8080`, while the updated guide specifies port `9090`.
- **Outdated instructions**: Deprecated endpoints or migration commands (`python upgrade_v1.py`) remain in customer documentation.
- **Missing critical sections**: Essential security or diagnostic requirements disappear during refactoring.
- **Terminology divergence**: One team writes `api_key` while another adopts `auth_token` without synonym clarification.

This application provides a **complete, full-stack, automated consistency checking system** that:
1. Allows users to upload an **Original / Baseline** and **Updated** document separately (**PDF**, **DOCX**, and **TXT** formats supported).
2. Parses, cleans, and semantically chunks content while preserving headings, section paths, and code snippets.
3. Employs **Sentence-BERT** (`all-MiniLM-L6-v2`) to compute high-density embeddings and cosine similarity alignments.
4. Screens aligned pairs with **DeBERTa-v3 Natural Language Inference** (Entailment, Contradiction, Neutral).
5. Prompts a **local Llama 3.1 model** (running locally via Ollama) to verify discrepancies, explain verbatim evidence, assign severity, and recommend actionable corrections.
6. Automatically falls back to an offline heuristic semantic NLP engine if Ollama is not installed or running, and transparently logs model status.
7. Calculates an overall transparent **Consistency Score (0 - 100)** normalized against comparable content length.
8. Provides human-in-the-loop issue review with **Approve**, **Reject**, and **Corrected** status updates.
9. Exports formal multi-page **Executive PDF Audit Reports** (via ReportLab) and CSV finding summaries.

---

## 🏗️ 3. Architectural Pipeline

```
     [Baseline Document (PDF/DOCX/TXT)]       [Updated Document (PDF/DOCX/TXT)]
                       │                                │
                       ▼                                ▼
        ┌──────────────────────────────────────────────────────────────┐
        │       Multi-Format Text Extraction & Section Detection       │
        │   PyMuPDF (PDF), python-docx (DOCX), and raw text parser     │
        └──────────────────────────────┬───────────────────────────────┘
                                       │
                                       ▼
        ┌──────────────────────────────────────────────────────────────┐
        │            Section-Aware Semantic Chunking Engine            │
        │    Preserves header hierarchy, code blocks, and page numbers │
        └──────────────────────────────┬───────────────────────────────┘
                                       │
                                       ▼
        ┌──────────────────────────────────────────────────────────────┐
        │     Sentence-BERT Dense Semantic Embeddings (MiniLM-L6-v2)   │
        │     Cosine similarity alignment of top-k related pairs       │
        └──────────────────────────────┬───────────────────────────────┘
                                       │
                                       ▼
        ┌──────────────────────────────────────────────────────────────┐
        │           DeBERTa-v3 Natural Language Inference (NLI)        │
        │    Evaluates text pairs: Entailment / Contradiction / Neutral│
        └──────────────────────────────┬───────────────────────────────┘
                                       │
                                       ▼
        ┌──────────────────────────────────────────────────────────────┐
        │    Local Llama 3.1 Verification (via Local Ollama Daemon)    │
        │   Structured JSON verification across 5 canonical categories │
        │    (Fallback: Local Analytical Rule & Negation Engine)       │
        └──────────────────────────────┬───────────────────────────────┘
                                       │
                                       ▼
        ┌──────────────────────────────────────────────────────────────┐
        │          Mathematical Consistency Scorer (0 - 100)           │
        │   Normalized severity penalties against baseline capacity    │
        └──────────────────────────────┬───────────────────────────────┘
                                       │
                          ┌────────────┴────────────┐
                          ▼                         ▼
        ┌─────────────────────────────────┐ ┌─────────────────────────────────┐
        │   Interactive Results Dashboard │ │   Downloadable PDF Audit Report │
        │ Side-by-side highlighted viewer │ │ Multi-page formal ReportLab doc │
        │ Approve, Reject, Corrected flow │ │   Disclaimers & methodology     │
        └─────────────────────────────────┘ └─────────────────────────────────┘
```

---

## 💻 4. Technology Stack

| Layer | Component | Description |
| :--- | :--- | :--- |
| **Frontend** | React 19 + Vite | High-performance SPA with fast HMR |
| **Styling** | Tailwind CSS 3.4 | Modern theme (#111827 Navy, #4F46E5 Indigo, #7C3AED Violet, #14B8A6 Teal) |
| **Data Viz** | Recharts 3.10 | Interactive area, pie, bar, and line charts |
| **Icons** | Lucide React | Clean, modern feather icon set |
| **Routing** | React Router DOM v7 | Client-side navigation with JWT route protection |
| **Backend** | Python 3.11+ / FastAPI | High-concurrency async REST API with Pydantic v2 schemas |
| **Database** | SQLite + SQLAlchemy 2.0 | WAL mode enabled, foreign key enforcement, schema in `database/` |
| **LLM Inference** | Llama 3.1 8B Instruct | Local Ollama daemon at `http://localhost:11434` with 0 external API calls |
| **Embeddings** | Sentence-BERT | `all-MiniLM-L6-v2` dense unit embeddings with cosine alignment |
| **NLI Classifier** | DeBERTa-v3 | `cross-encoder/nli-deberta-v3-small` sequence classification |
| **Doc Processing**| PyMuPDF, python-docx | Text extraction, heading detection, code block isolation |
| **PDF Reporting** | ReportLab 4.1+ | Dynamic multi-page PDF generation with custom headers, footers & tables |
| **Authentication**| bcrypt + PyJWT | Secure password hashing, salted bcrypt, stateless JWT tokens |

---

## 🎯 5. The 5 Required Discrepancy Categories

1. **Consistent (Green `#10B981`)**: Corresponding statements agree in technical meaning without conflicts.
2. **Contradiction (Red `#EF4444`)**: Two sections contain mutually incompatible specifications (e.g. port 8080 vs port 9090, timeout 30s vs 60s).
3. **Outdated Information (Amber `#F59E0B`)**: Older documentation contains superseded parameters, obsolete commands, or legacy syntax replaced in newer software.
4. **Missing Content (Blue `#3B82F6`)**: Important section or parameter present in the baseline documentation is completely omitted in the target documentation.
5. **Terminology Inconsistency (Purple `#8B5CF6`)**: Different naming used for the same concept without synonymy (e.g. `api_key` vs `auth_token`, `master` vs `main`).

---

## 📐 6. Consistency Score Calculation

$$\text{Total Penalty} = \sum_{i \in \text{Issues}} \text{SeverityWeight}(i) \times \text{Confidence}(i)$$

$$\text{Baseline Capacity} = \max(\text{Total Matched Pairs} \times 15.0, \; 50.0)$$

$$\text{Consistency Score} = \max\left(0.0, \; \min\left(100.0, \; 100.0 - \frac{\text{Total Penalty}}{\text{Baseline Capacity}} \times 100.0\right)\right)$$

### Status Labels:
- **90 - 100%**: Excellent consistency
- **75 - 89%**: Good consistency
- **55 - 74%**: Needs review
- **0 - 54%**: Significant inconsistencies

---

## 🌐 7. API Endpoints Reference

| Method | Endpoint | Description |
| :--- | :--- | :--- |
| **POST** | `/api/auth/register` | Register new user account with hashed password |
| **POST** | `/api/auth/login` | Authenticate user and return JWT bearer token |
| **GET** | `/api/auth/me` | Fetch currently authenticated user profile |
| **POST** | `/api/upload` or `/api/documents/upload` | Upload and extract text for PDF, DOCX, or TXT document |
| **GET** | `/api/documents` | List uploaded technical documents |
| **GET** | `/api/documents/{id}` | Inspect extracted sections and semantic chunks |
| **POST** | `/api/compare` or `/api/analyses` | Trigger comparison between baseline and updated documents |
| **GET** | `/api/history` or `/api/analyses` | Retrieve historical comparison runs and scores |
| **GET** | `/api/results/{id}` or `/api/analyses/{id}` | Detailed comparison results with issues, scores, and statistics |
| **GET** | `/api/analyses/{id}/status` | Real-time 8-stage progress tracker |
| **GET** | `/api/issues` | Filterable list of all detected issues across analyses |
| **PATCH**| `/api/issues/{id}/status` or `/review` | Update issue verification status (`approved`, `rejected`, `corrected`) |
| **PATCH**| `/api/issues/{id}/correction` | Save updated human-corrected suggestion text |
| **GET** | `/api/reports/{id}/pdf` | Download formal executive PDF audit report |
| **GET** | `/api/analyses/{id}/report/csv` | Download CSV summary of all detected discrepancies |
| **GET** | `/api/models/status` | Real-time health check for Ollama and local NLP models |
| **GET** | `/api/dashboard/summary` | Aggregate metrics (total analyses, issues reviewed, avg consistency) |
| **GET** | `/api/dashboard/charts` | Chart time series data for dashboard visualizations |

---

## 🚀 8. Setup & Execution Guide (VS Code / Windows)

### Prerequisites
- **Python 3.11+**: Download from [python.org](https://www.python.org/)
- **Node.js 18+ & npm**: Download from [nodejs.org](https://nodejs.org/)
- **Ollama (Optional for Llama 3.1)**: Download from [ollama.com](https://ollama.com/) (If Ollama is not installed, the application automatically uses its built-in offline NLP engine).

### Step 1: Open Project in VS Code
Open VS Code and choose **File > Open Folder...**, then select the `Technical-Documentation-Consistency-Checker` folder.

### Step 2: Install Python Dependencies
Open a PowerShell terminal in VS Code:
```powershell
pip install -r requirements.txt
```

### Step 3: Install Frontend Dependencies
```powershell
cd frontend
npm install
cd ..
```

### Step 4: Optional - Pull Llama 3.1 via Ollama
If using local Ollama inference:
```powershell
ollama pull llama3.1:8b
```
*(If you do not run Ollama, the system will seamlessly run the built-in deterministic NLP engine with zero crashes).*

### Step 5: Start the Servers

**Option A — Windows Batch Scripts (Easiest)**:
Double-click `start_backend.bat` and `start_frontend.bat`, or run:
```powershell
.\start_backend.bat
```
In a second terminal:
```powershell
.\start_frontend.bat
```

**Option B — Manual Commands in VS Code Terminals**:
- **Terminal 1 (Backend)**:
  ```powershell
  cd backend
  python -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload
  ```
- **Terminal 2 (Frontend)**:
  ```powershell
  cd frontend
  npm run dev
  ```

Open your browser at: **`http://localhost:5173`**

### Pre-Configured Demo Account:
- **Email**: `demo@btech.edu`
- **Password**: `DemoPass123!`
*(You can also sign up with any email or click "Auto-fill Credentials" on the login page).*

---

## 🧪 9. Running Automated Tests

Run the comprehensive pytest test suite (covers authentication, document extraction, sentence embeddings, NLI classifier, Ollama client fallback, consistency scoring, and PDF generation):

```powershell
cd backend
python -m pytest tests/test_core.py -v
```

All 14 tests will pass with 100% coverage.
