# Model Training & Fine-Tuning Module

This directory contains the training artifacts, dataset templates, evaluation scripts, and LoRA/QLoRA configuration workflows for adapting LLMs to technical documentation consistency checking.

## 📌 Important Disclaimer

The base **Llama 3.1 8B Instruct** model is created and pretrained by Meta AI. Our project utilizes parameter-efficient fine-tuning (PEFT) with **LoRA (Low-Rank Adaptation)** and **QLoRA (4-bit Quantization)** on domain-specific documentation contradiction datasets.

## 📁 Directory Structure

```
training/
├── datasets/
│   ├── sample_consistency_dataset.csv  # Illustrative sample training pairs
│   └── dataset_template.csv            # Downloadable template for user datasets
├── scripts/
│   ├── finetune_lora.py                # Hugging Face PEFT LoRA training script
│   └── evaluate.py                     # Metric calculation (Accuracy, F1, Confusion Matrix)
├── configs/
│   └── lora_config.json                # Default hyperparameters
└── checkpoints/
    └── lora_adapter/                   # Saved adapter weights and configuration
```

## 💻 Hardware Requirements

- **Base Inference (Ollama)**: 8 GB RAM (CPU) or 6 GB VRAM (GPU).
- **LoRA Fine-Tuning**: Minimum 16 GB VRAM with 4-bit quantization (QLoRA) or 24 GB VRAM for 16-bit LoRA.
- If your system does not meet the VRAM requirements for full 8B parameter training, the web application provides an interactive training simulation mode with synthetic loss tracking and real test-set evaluation metrics.

## 🚀 Running LoRA Training Manually

```bash
python scripts/finetune_lora.py \
  --dataset_path datasets/sample_consistency_dataset.csv \
  --output_dir checkpoints/lora_adapter \
  --epochs 3 \
  --batch_size 4 \
  --learning_rate 2e-4 \
  --lora_r 16 \
  --lora_alpha 32
```
