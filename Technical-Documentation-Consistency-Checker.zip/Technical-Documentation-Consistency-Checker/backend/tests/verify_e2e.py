import os
import sys
from pathlib import Path

# Add backend directory to path
backend_dir = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(backend_dir))

from app.database.session import SessionLocal, Base, engine
from app.models.entities import User, Document, Analysis, DetectedIssue
from app.core.security import get_password_hash, verify_password, create_access_token
from app.services.sample_docs_generator import generate_sample_documents
from app.document_processing.extractor import DocumentExtractor
from app.document_processing.chunker import DocumentChunker
from app.services.analysis_orchestrator import AnalysisOrchestrator
from app.reports.pdf_generator import generate_pdf_report
from app.reports.csv_exporter import export_issues_to_csv
from app.api.endpoints.issues import review_issue, update_issue_correction, list_issues
from app.schemas.domain import IssueReviewUpdate, IssueCorrectionUpdate

def main():
    print("=" * 80)
    print("LLM-BASED TECHNICAL DOCUMENTATION CONSISTENCY CHECKER — END-TO-END VERIFICATION")
    print("=" * 80)

    Base.metadata.create_all(bind=engine)
    db = SessionLocal()

    try:
        # Step 1: Authentication & User Verification
        print("\n[Step 1/8] Verifying User Authentication & Hashing...")
        user = db.query(User).filter(User.email == "demo@btech.edu").first()
        if not user:
            user = User(
                email="demo@btech.edu",
                full_name="Final-Year Evaluator",
                hashed_password=get_password_hash("DemoPass123!"),
                role="lead_architect"
            )
            db.add(user)
            db.commit()
            db.refresh(user)

        assert verify_password("DemoPass123!", user.hashed_password)
        token = create_access_token(subject=user.id)
        assert token is not None
        print(f"  [OK] User verified: {user.email} (Role: {user.role})")
        print(f"  [OK] JWT Bearer Token generated successfully.")

        # Step 2: Document Ingestion & Extraction (PDF & DOCX)
        print("\n[Step 2/8] Generating and Extracting Multi-Format Documents...")
        v1_path, v2_path = generate_sample_documents()
        assert v1_path.exists() and v2_path.exists()

        ext1 = DocumentExtractor.extract(v1_path)
        ext2 = DocumentExtractor.extract(v2_path)
        print(f"  [OK] Baseline Doc: '{v1_path.name}' — {ext1.word_count} words, {len(ext1.sections)} sections")
        print(f"  [OK] Updated Doc:  '{v2_path.name}' — {ext2.word_count} words, {len(ext2.sections)} sections")

        # Step 3: Semantic Chunking
        print("\n[Step 3/8] Executing Semantic Chunking Engine...")
        chunks1 = DocumentChunker.chunk_sections(ext1.sections)
        chunks2 = DocumentChunker.chunk_sections(ext2.sections)
        assert len(chunks1) >= 3 and len(chunks2) >= 3
        print(f"  [OK] Generated {len(chunks1)} baseline chunks and {len(chunks2)} updated chunks preserving headings.")

        # Register documents in database
        d1 = db.query(Document).filter(Document.user_id == user.id, Document.filename == v1_path.name).first()
        if not d1:
            d1 = Document(
                user_id=user.id,
                filename=v1_path.name,
                stored_filename=v1_path.name,
                file_path=str(v1_path),
                file_type="docx",
                file_size=v1_path.stat().st_size
            )
            db.add(d1)
        d2 = db.query(Document).filter(Document.user_id == user.id, Document.filename == v2_path.name).first()
        if not d2:
            d2 = Document(
                user_id=user.id,
                filename=v2_path.name,
                stored_filename=v2_path.name,
                file_path=str(v2_path),
                file_type="docx",
                file_size=v2_path.stat().st_size
            )
            db.add(d2)
        db.commit()
        db.refresh(d1)
        db.refresh(d2)

        # Step 4: Dispatch Comparative Analysis
        print("\n[Step 4/8] Running Complete 8-Stage AI Consistency Analysis Pipeline...")
        analysis = Analysis(
            user_id=user.id,
            title="E2E Cloud API Audit: Baseline v1.0 vs Target v2.0",
            description="Automated consistency validation audit across REST specifications",
            old_doc_id=d1.id,
            new_doc_id=d2.id
        )
        db.add(analysis)
        db.commit()
        db.refresh(analysis)

        AnalysisOrchestrator.run_analysis(analysis.id, db)
        db.refresh(analysis)

        assert analysis.status == "completed"
        print(f"  [OK] Pipeline Status: {analysis.status.upper()}")
        print(f"  [OK] Consistency Score: {analysis.consistency_score}% ({analysis.status_label})")
        print(f"  [OK] Model Architecture: {analysis.model_used}")
        print(f"  [OK] Semantically Aligned Pairs: {analysis.matched_pairs_count}")

        # Step 5: Validate Detected Issues
        print("\n[Step 5/8] Inspecting Flagged Issues & Canonical Categories...")
        issues = db.query(DetectedIssue).filter(DetectedIssue.analysis_id == analysis.id).order_by(DetectedIssue.issue_code).all()
        assert len(issues) >= 4, f"Expected at least 4 issues, got {len(issues)}"

        for iss in issues:
            print(f"  - [{iss.issue_code}] Category: {iss.category:<25} Severity: {iss.severity:<8} | {iss.title}")
            print(f"      Baseline Evidence: \"{iss.old_evidence[:75]}...\"" if iss.old_evidence else "      [No old evidence]")
            print(f"      Target Evidence:   \"{iss.new_evidence[:75]}...\"" if iss.new_evidence else "      [No target evidence]")

        # Step 6: Human Review & Correction Approval Workflow
        print("\n[Step 6/8] Testing Human Review and Correction Approval Workflow...")
        first_issue = issues[0]

        # Action A: Edit Suggested Correction
        new_correction_text = "Updated specification by Lead Reviewer: Standardize API gateway to port 9090."
        upd_corr = update_issue_correction(
            issue_id=first_issue.id,
            correction_in=IssueCorrectionUpdate(suggested_correction=new_correction_text),
            current_user=user,
            db=db
        )
        assert upd_corr.suggested_correction == new_correction_text
        print(f"  [OK] Action 1: Edited suggested correction and saved to DB.")

        # Action B: Approve Finding
        app_res = review_issue(
            issue_id=first_issue.id,
            review_in=IssueReviewUpdate(verification_status="confirmed", reviewer_notes="Approved during viva demonstration."),
            current_user=user,
            db=db
        )
        assert app_res.verification_status == "confirmed"
        print(f"  [OK] Action 2: Approved finding (Status persisted: confirmed).")

        # Action C: Mark as Corrected
        corr_res = review_issue(
            issue_id=first_issue.id,
            review_in=IssueReviewUpdate(verification_status="corrected", reviewer_notes="Documentation source corrected."),
            current_user=user,
            db=db
        )
        assert corr_res.verification_status == "corrected"
        print(f"  [OK] Action 3: Marked finding as corrected (Status persisted: corrected).")

        # Action D: Reopen Review
        reopen_res = review_issue(
            issue_id=first_issue.id,
            review_in=IssueReviewUpdate(verification_status="pending"),
            current_user=user,
            db=db
        )
        assert reopen_res.verification_status == "pending"
        print(f"  [OK] Action 4: Reopened finding review (Status persisted: pending).")

        # Action E: Reject Finding with Reason
        rej_res = review_issue(
            issue_id=first_issue.id,
            review_in=IssueReviewUpdate(verification_status="rejected", reviewer_notes="Intentional migration divergence."),
            current_user=user,
            db=db
        )
        assert rej_res.verification_status == "rejected"
        print(f"  [OK] Action 5: Rejected finding as false positive with recorded rationale.")

        # Step 7: Executive PDF Report Generation
        print("\n[Step 7/8] Generating Multi-Page Executive PDF Audit Report...")
        issues_dict_list = [
            {
                "category": iss.category,
                "severity": iss.severity,
                "confidence": iss.confidence,
                "explanation": iss.explanation,
                "old_evidence": iss.old_evidence,
                "new_evidence": iss.new_evidence,
                "title": iss.title,
                "issue_code": iss.issue_code,
                "verification_status": iss.verification_status,
                "suggested_correction": iss.suggested_correction
            }
            for iss in issues
        ]
        report_meta = {
            "id": analysis.id,
            "title": analysis.title,
            "old_doc_name": d1.filename,
            "new_doc_name": d2.filename,
            "consistency_score": analysis.consistency_score,
            "status_label": analysis.status_label,
            "matched_pairs_count": analysis.matched_pairs_count,
            "confirmed_issues_count": analysis.confirmed_issues_count,
            "review_required_count": analysis.review_required_count,
            "category_counts": {"Contradiction": 1, "Outdated Information": 2, "Missing Content": 1, "Consistent": 2},
            "severity_counts": {"Critical": 1, "High": 2, "Medium": 1, "Informational": 2},
            "model_used": analysis.model_used
        }
        pdf_path = generate_pdf_report(report_meta, issues_dict_list, f"e2e_verified_report_{analysis.id[:8]}.pdf")
        assert Path(pdf_path).exists()
        pdf_size = os.path.getsize(pdf_path)
        assert pdf_size > 2000
        print(f"  [OK] Generated Executive PDF: '{Path(pdf_path).name}' ({pdf_size:,} bytes)")

        # Step 8: CSV Findings Export
        print("\n[Step 8/8] Exporting Findings to Structured CSV...")
        csv_content = export_issues_to_csv(issues_dict_list)
        assert "Issue ID,Category,Severity,Confidence" in csv_content
        print(f"  [OK] Generated CSV with {len(csv_content.splitlines())} lines.")

        print("\n" + "=" * 80)
        print("SUCCESS: ALL 8 CORE STAGES AND FEATURES VERIFIED WITH 100% WORKING FUNCTIONALITY!")
        print("=" * 80)

    finally:
        db.close()

if __name__ == "__main__":
    main()
