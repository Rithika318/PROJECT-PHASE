import os
import pytest
from pathlib import Path
from fastapi.testclient import TestClient
from app.main import app
from app.core.security import get_password_hash, verify_password, create_access_token, decode_access_token
from app.document_processing.extractor import DocumentExtractor
from app.document_processing.chunker import DocumentChunker
from app.ml.embeddings import EmbeddingMatcher
from app.ml.nli_classifier import DeBERTaNLIClassifier
from app.ml.ollama_client import OllamaClient
from app.ml.consistency_scorer import ConsistencyScorer
from app.reports.pdf_generator import generate_pdf_report
from app.reports.csv_exporter import export_issues_to_csv
from app.services.sample_docs_generator import generate_sample_documents
from app.database.session import Base, engine, SessionLocal
from app.models.entities import User
# Base initialization
Base.metadata.create_all(bind=engine)

# 1. Test Password Hashing and JWT
def test_password_hashing():
    pwd = "SecureFinalYear2026!"
    hashed = get_password_hash(pwd)
    assert hashed != pwd
    assert verify_password(pwd, hashed) is True
    assert verify_password("WrongPassword!", hashed) is False

def test_jwt_token_flow():
    user_id = "test-user-123"
    token = create_access_token(subject=user_id)
    assert isinstance(token, str)
    payload = decode_access_token(token)
    assert payload is not None
    assert payload["sub"] == user_id

# 2. Test Document Extraction (PDF & DOCX)
def test_sample_documents_generation_and_docx_extraction():
    v1_path, v2_path = generate_sample_documents()
    assert v1_path.exists()
    assert v2_path.exists()

    res1 = DocumentExtractor.extract(v1_path)
    assert res1.file_type == "docx"
    assert res1.is_empty is False
    assert res1.word_count > 50
    assert len(res1.sections) >= 5

    res2 = DocumentExtractor.extract(v2_path)
    assert res2.word_count > 50
    assert len(res2.sections) >= 5

def test_chunking_preserves_headers():
    v1_path, _ = generate_sample_documents()
    res = DocumentExtractor.extract(v1_path)
    chunks = DocumentChunker.chunk_sections(res.sections, max_words_per_chunk=100)
    assert len(chunks) >= 3
    assert all(c.section_heading is not None for c in chunks)
    assert all(len(c.content) > 0 for c in chunks)

# 3. Test Semantic Matching
def test_semantic_chunk_matching():
    old_chunks = [
        {"id": "o1", "content": "The API server listens on port 8080.", "section": "Ports"},
        {"id": "o2", "content": "Database requires minimum 8GB RAM.", "section": "Hardware"}
    ]
    new_chunks = [
        {"id": "n1", "content": "The API gateway receives connections on port 9090.", "section": "Ports"},
        {"id": "n2", "content": "User interface is styled using Tailwind CSS.", "section": "UI"}
    ]
    matched, unmatched_old, unmatched_new = EmbeddingMatcher.match_chunks(old_chunks, new_chunks, similarity_threshold=0.2)
    assert len(matched) >= 1
    # Port chunk should be matched to Port chunk
    assert matched[0]["old_chunk"]["id"] == "o1"
    assert matched[0]["new_chunk"]["id"] == "n1"

# 4. Test NLI Classification
def test_nli_contradiction_detection():
    premise = "API server listens on port 8080."
    hypothesis = "API gateway operates on port 9090. Port 8080 is deprecated."
    res = DeBERTaNLIClassifier.predict(premise, hypothesis)
    assert res.label in ["contradiction", "neutral"]
    assert res.confidence > 0.5

def test_nli_entailment_detection():
    premise = "High availability requires configuring at least 3 active voting cluster nodes."
    hypothesis = "High availability requires configuring at least 3 active voting cluster nodes."
    res = DeBERTaNLIClassifier.predict(premise, hypothesis)
    assert res.label == "entailment"
    assert res.confidence >= 0.7

# 5. Test Consistency Scoring Formula
def test_consistency_score_calculation():
    sample_issues = [
        {"category": "Contradiction", "severity": "Critical", "confidence": 0.95},
        {"category": "Outdated Information", "severity": "High", "confidence": 0.90},
        {"category": "Consistent", "severity": "Informational", "confidence": 0.85}
    ]
    result = ConsistencyScorer.calculate_score(sample_issues, total_matched_pairs=5)
    assert 0 <= result.score <= 100
    assert result.total_issues == 2
    assert result.status_label in ["Excellent consistency", "Good consistency", "Needs review", "Significant inconsistencies"]

# 6. Test Report Generation (PDF & CSV)
def test_pdf_report_generation():
    meta = {
        "id": "test-analysis-001",
        "title": "Automated Cloud API Audit",
        "old_doc_name": "API_v1.0.docx",
        "new_doc_name": "API_v2.0.docx",
        "consistency_score": 82.5,
        "status_label": "Good consistency",
        "matched_pairs_count": 8,
        "confirmed_issues_count": 3,
        "review_required_count": 1,
        "category_counts": {"Contradiction": 1, "Outdated Information": 1, "Consistent": 6},
        "severity_counts": {"Critical": 1, "High": 1, "Informational": 6},
        "model_used": "Llama 3.1 8B Instruct"
    }
    issues = [
        {
            "issue_code": "ISS-001",
            "category": "Contradiction",
            "severity": "Critical",
            "confidence": 0.95,
            "title": "Port Discrepancy",
            "explanation": "Old specifies 8080, new specifies 9090.",
            "old_evidence": "port: 8080",
            "new_evidence": "port: 9090",
            "suggested_correction": "Standardize to 9090.",
            "verification_status": "pending"
        }
    ]
    pdf_path = generate_pdf_report(meta, issues, "test_output.pdf")
    assert Path(pdf_path).exists()
    assert os.path.getsize(pdf_path) > 1000

def test_csv_export():
    issues = [
        {
            "issue_code": "ISS-001",
            "category": "Contradiction",
            "severity": "Critical",
            "confidence": 0.95,
            "title": "Port Discrepancy",
            "explanation": "Port mismatch",
            "old_evidence": "8080",
            "new_evidence": "9090",
            "suggested_correction": "Align ports."
        }
    ]
    csv_str = export_issues_to_csv(issues)
    assert "ISS-001" in csv_str
    assert "Contradiction" in csv_str
    assert "Critical" in csv_str

# 7. Test API Endpoints (Auth, System Health, and Human Review Workflow)
from app.api.endpoints.system import health_check
from app.api.endpoints.auth import register, login, get_me
from app.api.endpoints.issues import review_issue, update_issue_correction, list_issues
from app.schemas.domain import UserRegister, UserLogin, IssueReviewUpdate, IssueCorrectionUpdate
from app.models.entities import Analysis, DetectedIssue

def test_health_endpoint():
    res = health_check()
    assert res.status == "healthy"
    assert res.version == "1.0.0"

def test_auth_registration_and_login():
    db = SessionLocal()
    try:
        email = "test_engineer_btech@btech.edu"
        # Cleanup if exists from earlier run
        existing = db.query(User).filter(User.email == email).first()
        if existing:
            db.delete(existing)
            db.commit()

        reg_data = UserRegister(
            full_name="Test Engineer",
            email=email,
            password="SecurePassword123!"
        )
        reg_res = register(user_in=reg_data, db=db)
        assert reg_res.access_token is not None
        assert reg_res.user.email == email

        # Test Login
        login_data = UserLogin(
            email=email,
            password="SecurePassword123!"
        )
        login_res = login(login_in=login_data, db=db)
        assert login_res.access_token is not None
        assert login_res.user.full_name == "Test Engineer"

        # Test get_me
        user_entity = db.query(User).filter(User.email == email).first()
        me_res = get_me(current_user=user_entity)
        assert me_res.email == email
        assert me_res.full_name == "Test Engineer"
    finally:
        db.close()

def test_human_review_and_correction_workflow():
    db = SessionLocal()
    try:
        user = db.query(User).first()
        assert user is not None

        # Create a test analysis and issue for human review
        test_analysis = Analysis(
            user_id=user.id,
            title="Unit Test Consistency Audit",
            status="completed",
            consistency_score=85.0
        )
        db.add(test_analysis)
        db.commit()
        db.refresh(test_analysis)

        test_issue = DetectedIssue(
            analysis_id=test_analysis.id,
            issue_code="ISS-TEST-001",
            category="Contradiction",
            title="Port Mismatch Test",
            explanation="Old specifies 8080, new specifies 9090",
            old_evidence="port: 8080",
            new_evidence="port: 9090",
            suggested_correction="Update old specification to 9090.",
            verification_status="pending"
        )
        db.add(test_issue)
        db.commit()
        db.refresh(test_issue)

        # 1. Test Edit Suggested Correction & Save
        new_correction = "Standardize ingress port to 9090 across all cloud guides."
        corr_update = IssueCorrectionUpdate(suggested_correction=new_correction)
        updated_corr = update_issue_correction(
            issue_id=test_issue.id,
            correction_in=corr_update,
            current_user=user,
            db=db
        )
        assert updated_corr.suggested_correction == new_correction

        # 2. Test Approve Finding (status: 'confirmed')
        approve_update = IssueReviewUpdate(verification_status="confirmed", reviewer_notes="Approved as genuine contradiction.")
        approved_res = review_issue(
            issue_id=test_issue.id,
            review_in=approve_update,
            current_user=user,
            db=db
        )
        assert approved_res.verification_status == "confirmed"
        assert "Approved" in approved_res.reviewer_notes

        # 3. Test Mark as Corrected (status: 'corrected')
        correct_update = IssueReviewUpdate(verification_status="corrected", reviewer_notes="Rectified in documentation.")
        corrected_res = review_issue(
            issue_id=test_issue.id,
            review_in=correct_update,
            current_user=user,
            db=db
        )
        assert corrected_res.verification_status == "corrected"

        # 4. Test Reopen Review (status: 'pending')
        reopen_update = IssueReviewUpdate(verification_status="pending")
        reopened_res = review_issue(
            issue_id=test_issue.id,
            review_in=reopen_update,
            current_user=user,
            db=db
        )
        assert reopened_res.verification_status == "pending"

        # 5. Test Reject Finding (status: 'rejected')
        reject_update = IssueReviewUpdate(verification_status="rejected", reviewer_notes="False positive due to v2 upgrade.")
        rejected_res = review_issue(
            issue_id=test_issue.id,
            review_in=reject_update,
            current_user=user,
            db=db
        )
        assert rejected_res.verification_status == "rejected"

        # 6. Test List Issues with Filter
        filtered_list = list_issues(
            analysis_id=test_analysis.id,
            category="Contradiction",
            severity=None,
            verification_status="rejected",
            current_user=user,
            db=db
        )
        assert len(filtered_list) >= 1
        assert filtered_list[0].issue_code == "ISS-TEST-001"
    finally:
        db.close()

def test_txt_document_extraction(tmp_path):
    txt_file = tmp_path / "sample_spec.txt"
    txt_file.write_text("""# System Overview
The backend runs on port 8000 using FastAPI.

# Authentication
JWT Bearer tokens are required for all protected endpoints.
""", encoding="utf-8")
    
    res = DocumentExtractor.extract(txt_file)
    assert res.file_type == "txt"
    assert res.is_empty is False
    assert res.word_count > 10
    assert len(res.sections) >= 2
    assert res.sections[0].heading == "System Overview"
