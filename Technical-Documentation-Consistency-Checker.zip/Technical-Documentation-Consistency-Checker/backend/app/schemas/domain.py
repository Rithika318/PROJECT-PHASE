from datetime import datetime
from typing import Optional, Any
from pydantic import BaseModel, Field, ConfigDict

# ----------------- Auth Schemas -----------------
class UserRegister(BaseModel):
    full_name: str = Field(..., min_length=2, max_length=100)
    email: str = Field(..., pattern=r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$')
    password: str = Field(..., min_length=6, max_length=100)

class UserLogin(BaseModel):
    email: str = Field(..., pattern=r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$')
    password: str

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: "UserOut"

class UserOut(BaseModel):
    id: str
    email: str
    full_name: str
    role: str
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)

Token.model_rebuild()

class PasswordChange(BaseModel):
    current_password: str
    new_password: str = Field(..., min_length=6)

# ----------------- Document Schemas -----------------
class DocumentChunkOut(BaseModel):
    id: str
    chunk_index: int
    page_number: Optional[int] = None
    section_heading: Optional[str] = None
    content: str
    token_count: int

    model_config = ConfigDict(from_attributes=True)

class DocumentOut(BaseModel):
    id: str
    filename: str
    file_type: str
    file_size: int
    word_count: int
    section_count: int
    chunk_count: int
    extraction_status: str
    is_scanned_ocr_needed: bool
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)

class DocumentDetailOut(DocumentOut):
    chunks: list[DocumentChunkOut] = []

# ----------------- Issue Schemas -----------------
class DetectedIssueOut(BaseModel):
    id: str
    analysis_id: str
    issue_code: str
    category: str
    title: str
    severity: str
    confidence: float
    explanation: str
    old_evidence: Optional[str] = None
    new_evidence: Optional[str] = None
    source_section_old: Optional[str] = None
    source_section_new: Optional[str] = None
    source_page_old: Optional[int] = None
    source_page_new: Optional[int] = None
    suggested_correction: Optional[str] = None
    verification_status: str
    reviewer_notes: Optional[str] = None
    analysis_title: Optional[str] = None
    old_doc_name: Optional[str] = None
    new_doc_name: Optional[str] = None
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)

class IssueReviewUpdate(BaseModel):
    verification_status: str  # confirmed, rejected, reviewed, pending
    reviewer_notes: Optional[str] = None

class IssueCommentCreate(BaseModel):
    comment: str

class IssueCorrectionUpdate(BaseModel):
    suggested_correction: str = Field(..., min_length=1, max_length=2000)

# ----------------- Analysis Schemas -----------------
class AnalysisCreate(BaseModel):
    title: str = Field(..., min_length=3, max_length=200)
    description: Optional[str] = None
    old_doc_id: str
    new_doc_id: str

class MatchedPairOut(BaseModel):
    id: str
    similarity_score: float
    nli_label: str
    nli_confidence: float
    old_chunk_id: Optional[str] = None
    new_chunk_id: Optional[str] = None

    model_config = ConfigDict(from_attributes=True)

class AnalysisOut(BaseModel):
    id: str
    title: str
    description: Optional[str] = None
    old_doc_id: Optional[str] = None
    new_doc_id: Optional[str] = None
    old_doc_name: Optional[str] = None
    new_doc_name: Optional[str] = None
    status: str
    progress_stage: int
    progress_percent: int
    error_message: Optional[str] = None
    consistency_score: float
    status_label: str
    matched_pairs_count: int
    confirmed_issues_count: int
    review_required_count: int
    approved_count: int = 0
    rejected_count: int = 0
    corrected_count: int = 0
    pending_count: int = 0
    duration_seconds: float
    model_used: str
    fine_tuned_adapter_used: bool
    created_at: datetime
    completed_at: Optional[datetime] = None

    model_config = ConfigDict(from_attributes=True)

class AnalysisDetailOut(AnalysisOut):
    issues: list[DetectedIssueOut] = []
    category_counts: dict[str, int] = {}
    severity_counts: dict[str, int] = {}

class AnalysisStatusOut(BaseModel):
    id: str
    status: str
    progress_stage: int
    stage_name: str
    progress_percent: int
    error_message: Optional[str] = None
    consistency_score: Optional[float] = None
    is_completed: bool = False

# ----------------- Dataset & Training Schemas -----------------
class DatasetOut(BaseModel):
    id: str
    filename: str
    row_count: int
    label_distribution_json: dict[str, int]
    validation_status: str
    train_count: int
    val_count: int
    test_count: int
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)

class TrainingConfigSchema(BaseModel):
    dataset_id: str
    base_model: str = "llama3.1:8b"
    learning_rate: float = 2e-4
    epochs: int = 3
    batch_size: int = 4
    lora_r: int = 16
    lora_alpha: int = 32
    lora_dropout: float = 0.05
    train_split: float = 0.8
    val_split: float = 0.1
    test_split: float = 0.1

class TrainingJobOut(BaseModel):
    id: str
    dataset_id: Optional[str] = None
    status: str
    progress_percent: int
    config_json: dict[str, Any]
    training_loss_history_json: list[dict[str, Any]]
    val_metrics_json: dict[str, Any]
    adapter_path: Optional[str] = None
    error_message: Optional[str] = None
    created_at: datetime
    completed_at: Optional[datetime] = None

    model_config = ConfigDict(from_attributes=True)

class EvaluationRequest(BaseModel):
    dataset_id: str
    model_name: str = "llama3.1:8b"
    use_adapter: bool = False

class EvaluationOut(BaseModel):
    id: str
    model_name: str
    dataset_id: Optional[str] = None
    accuracy: float
    precision: float
    recall: float
    macro_f1: float
    per_class_metrics_json: dict[str, Any]
    confusion_matrix_json: dict[str, Any]
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)

# ----------------- Dashboard & System Schemas -----------------
class DashboardSummaryOut(BaseModel):
    total_analyses: int
    total_documents: int
    total_issues: int
    average_consistency_score: float
    high_severity_issues: int
    reports_generated: int
    pending_reviews: int = 0
    approved_findings: int = 0
    corrected_findings: int = 0
    recent_analyses: list[AnalysisOut]

class DashboardChartsOut(BaseModel):
    score_trends: list[dict[str, Any]]
    category_distribution: list[dict[str, Any]]
    severity_distribution: list[dict[str, Any]]
    activity_by_date: list[dict[str, Any]]
    consistent_vs_inconsistent: list[dict[str, Any]]
    confidence_distribution: list[dict[str, Any]]
    review_status_distribution: list[dict[str, Any]] = []

class HealthStatusOut(BaseModel):
    status: str
    timestamp: datetime
    version: str

class ComponentStatus(BaseModel):
    name: str
    status: str  # Ready, Not Installed, Unavailable, Error
    details: str
    recommended_action: Optional[str] = None
    command_to_run: Optional[str] = None

class ModelStatusOut(BaseModel):
    ollama_service: ComponentStatus
    llama31_model: ComponentStatus
    sbert_embeddings: ComponentStatus
    deberta_nli: ComponentStatus
    backend_api: ComponentStatus
    database: ComponentStatus
    finetuned_adapter: ComponentStatus
    current_inference_mode: str
    last_analysis_time: Optional[datetime] = None

# ----------------- Settings Schema -----------------
class UserSettingsOut(BaseModel):
    similarity_threshold: float
    confidence_threshold: float
    critical_weight: float
    high_weight: float
    medium_weight: float
    low_weight: float
    selected_model: str
    use_adapter: bool
    inference_mode: str

    model_config = ConfigDict(from_attributes=True)

class UserSettingsUpdate(BaseModel):
    similarity_threshold: Optional[float] = None
    confidence_threshold: Optional[float] = None
    critical_weight: Optional[float] = None
    high_weight: Optional[float] = None
    medium_weight: Optional[float] = None
    low_weight: Optional[float] = None
    selected_model: Optional[str] = None
    use_adapter: Optional[bool] = None
    inference_mode: Optional[str] = None

# ----------------- LLM Structured Output Schema -----------------
class LLMIssueItem(BaseModel):
    is_inconsistency: bool
    category: str = Field(..., description="One of: Consistent, Contradiction, Outdated Information, Missing Content, Terminology Inconsistency")
    title: str
    severity: str = Field(..., description="One of: Critical, High, Medium, Low, Informational")
    confidence: float = Field(..., ge=0.0, le=1.0)
    explanation: str
    old_evidence: str
    new_evidence: str
    suggested_correction: str

class LLMVerificationResponse(BaseModel):
    findings: list[LLMIssueItem] = []
    general_summary: Optional[str] = None
