from pathlib import Path
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import FileResponse, Response
from sqlalchemy.orm import Session
from app.database.session import get_db
from app.models.entities import User, Analysis, DetectedIssue
from app.api.deps import get_current_user
from app.core.config import settings
from app.reports.pdf_generator import generate_pdf_report
from app.reports.csv_exporter import export_issues_to_csv

router = APIRouter(prefix="/analyses", tags=["Reports"])

@router.get("/{analysis_id}/report/pdf")
def download_pdf_report(
    analysis_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    analysis = db.query(Analysis).filter(Analysis.id == analysis_id, Analysis.user_id == current_user.id).first()
    if not analysis:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Analysis record not found.")

    issues = db.query(DetectedIssue).filter(DetectedIssue.analysis_id == analysis.id).order_by(DetectedIssue.issue_code).all()
    issues_dict = [
        {
            "issue_code": i.issue_code,
            "category": i.category,
            "severity": i.severity,
            "confidence": i.confidence,
            "title": i.title,
            "explanation": i.explanation,
            "old_evidence": i.old_evidence,
            "new_evidence": i.new_evidence,
            "suggested_correction": i.suggested_correction,
            "verification_status": i.verification_status
        }
        for i in issues
    ]

    category_counts = {}
    severity_counts = {}
    for iss in issues:
        category_counts[iss.category] = category_counts.get(iss.category, 0) + 1
        severity_counts[iss.severity] = severity_counts.get(iss.severity, 0) + 1

    report_meta = {
        "id": analysis.id,
        "title": analysis.title,
        "old_doc_name": analysis.old_document.filename if analysis.old_document else "Document A",
        "new_doc_name": analysis.new_document.filename if analysis.new_document else "Document B",
        "consistency_score": analysis.consistency_score,
        "status_label": analysis.status_label,
        "matched_pairs_count": analysis.matched_pairs_count,
        "confirmed_issues_count": analysis.confirmed_issues_count,
        "review_required_count": analysis.review_required_count,
        "category_counts": category_counts,
        "severity_counts": severity_counts,
        "model_used": analysis.model_used
    }

    pdf_path = generate_pdf_report(report_meta, issues_dict)
    
    clean_title = "".join(c for c in analysis.title if c.isalnum() or c in (' ', '_', '-')).rstrip()
    download_filename = f"Consistency_Report_{clean_title[:30]}_{analysis.id[:8]}.pdf"

    return FileResponse(
        path=pdf_path,
        media_type="application/pdf",
        filename=download_filename
    )

@router.get("/{analysis_id}/report/csv")
def download_csv_report(
    analysis_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    analysis = db.query(Analysis).filter(Analysis.id == analysis_id, Analysis.user_id == current_user.id).first()
    if not analysis:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Analysis record not found.")

    issues = db.query(DetectedIssue).filter(DetectedIssue.analysis_id == analysis.id).order_by(DetectedIssue.issue_code).all()
    issues_dict = [
        {
            "issue_code": i.issue_code,
            "category": i.category,
            "severity": i.severity,
            "confidence": i.confidence,
            "title": i.title,
            "explanation": i.explanation,
            "old_evidence": i.old_evidence,
            "new_evidence": i.new_evidence,
            "source_section_old": i.source_section_old,
            "source_section_new": i.source_section_new,
            "source_page_old": i.source_page_old,
            "source_page_new": i.source_page_new,
            "suggested_correction": i.suggested_correction,
            "verification_status": i.verification_status,
            "reviewer_notes": i.reviewer_notes
        }
        for i in issues
    ]

    csv_data = export_issues_to_csv(issues_dict)
    clean_title = "".join(c for c in analysis.title if c.isalnum() or c in (' ', '_', '-')).rstrip()
    download_filename = f"Issues_{clean_title[:30]}_{analysis.id[:8]}.csv"

    return Response(
        content=csv_data,
        media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename={download_filename}"}
    )

reports_direct_router = APIRouter(prefix="/reports", tags=["Reports"])

@reports_direct_router.get("/{analysis_id}/pdf")
def download_pdf_report_direct(
    analysis_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    return download_pdf_report(analysis_id, current_user, db)
