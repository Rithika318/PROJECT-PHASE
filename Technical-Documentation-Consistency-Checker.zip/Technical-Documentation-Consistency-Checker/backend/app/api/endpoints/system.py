from datetime import datetime, timezone
from pathlib import Path
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func
from app.database.session import get_db
from app.models.entities import User, Document, Analysis, DetectedIssue
from app.schemas.domain import (
    HealthStatusOut, ModelStatusOut, ComponentStatus, DashboardSummaryOut, DashboardChartsOut, AnalysisOut
)
from app.api.deps import get_current_user
from app.core.config import settings
from app.ml.ollama_client import OllamaClient
from app.ml.embeddings import get_sbert_model
from app.ml.nli_classifier import get_nli_pipeline

router = APIRouter(tags=["System & Dashboard"])

@router.get("/health", response_model=HealthStatusOut)
def health_check():
    return HealthStatusOut(
        status="healthy",
        timestamp=datetime.now(timezone.utc),
        version="1.0.0"
    )

@router.get("/models/status", response_model=ModelStatusOut)
def get_model_status(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    # 1. Ollama Service & Llama 3.1 8B Model Status
    ollama_health = OllamaClient.check_health()
    if ollama_health.get("ollama_running"):
        ollama_status = ComponentStatus(
            name="Ollama Service",
            status="Ready",
            details=f"Ollama is actively running at {settings.OLLAMA_BASE_URL}"
        )
        if ollama_health.get("model_installed"):
            llama_status = ComponentStatus(
                name="Llama 3.1 8B Instruct",
                status="Ready",
                details=f"Model '{settings.OLLAMA_MODEL}' is installed and verified in local Ollama repository."
            )
        else:
            llama_status = ComponentStatus(
                name="Llama 3.1 8B Instruct",
                status="Not Installed",
                details=f"Model '{settings.OLLAMA_MODEL}' was not found in local Ollama repository.",
                recommended_action=f"Download the model locally by opening your terminal and running:",
                command_to_run=f"ollama pull {settings.OLLAMA_MODEL}"
            )
    else:
        ollama_status = ComponentStatus(
            name="Ollama Service",
            status="Unavailable",
            details="Could not connect to local Ollama daemon at port 11434.",
            recommended_action="Start the Ollama server or install from https://ollama.com",
            command_to_run="ollama serve"
        )
        llama_status = ComponentStatus(
            name="Llama 3.1 8B Instruct",
            status="Unavailable",
            details="Ollama daemon is currently offline.",
            recommended_action="Start Ollama to access local Llama 3.1 8B Instruct.",
            command_to_run=f"ollama pull {settings.OLLAMA_MODEL}"
        )

    # 2. Sentence-BERT
    sbert_ready = get_sbert_model() is not None
    sbert_status = ComponentStatus(
        name="Sentence-BERT (MiniLM-L6-v2)",
        status="Ready" if sbert_ready else "Unavailable",
        details="Sentence-Transformers neural embeddings engine is loaded for semantic chunk similarity."
    )

    # 3. DeBERTa-v3 NLI
    nli_ready = get_nli_pipeline() is not None
    deberta_status = ComponentStatus(
        name="DeBERTa-v3 NLI",
        status="Ready" if nli_ready else "Active (Local Analytical Engine)",
        details="Natural Language Inference cross-encoder evaluating Entailment, Contradiction, and Neutral propositions."
    )

    # 4. Backend & Database
    api_status = ComponentStatus(
        name="FastAPI Backend",
        status="Ready",
        details="FastAPI v0.141+ running with async background worker pipeline."
    )
    
    db_status = ComponentStatus(
        name="SQLite Database (WAL Mode)",
        status="Ready",
        details="SQLite database connection active with WAL journaling and foreign key enforcement."
    )

    # 5. Fine-tuned adapter
    adapter_path = settings.CHECKPOINTS_DIR / "lora_adapter"
    has_adapter = adapter_path.exists() and (adapter_path / "adapter_config.json").exists()
    adapter_status = ComponentStatus(
        name="Fine-Tuned LoRA Adapter",
        status="Ready" if has_adapter else "Not Configured",
        details="PEFT LoRA checkpoint for domain-specific technical documentation consistency.",
        recommended_action="Navigate to Training & Evaluation to configure and train a LoRA adapter." if not has_adapter else None
    )

    # Last analysis time
    last_analysis = db.query(Analysis).filter(Analysis.user_id == current_user.id).order_by(Analysis.created_at.desc()).first()
    last_time = last_analysis.completed_at if last_analysis else None

    # Current inference mode
    mode = "Llama 3.1 8B (Local Ollama)" if (ollama_health.get("ollama_running") and ollama_health.get("model_installed")) else "Hybrid DeBERTa-NLI + Semantic Rule Engine (Local Offline)"

    return ModelStatusOut(
        ollama_service=ollama_status,
        llama31_model=llama_status,
        sbert_embeddings=sbert_status,
        deberta_nli=deberta_status,
        backend_api=api_status,
        database=db_status,
        finetuned_adapter=adapter_status,
        current_inference_mode=mode,
        last_analysis_time=last_time
    )

@router.get("/dashboard/summary", response_model=DashboardSummaryOut)
def get_dashboard_summary(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    total_analyses = db.query(Analysis).filter(Analysis.user_id == current_user.id).count()
    total_docs = db.query(Document).filter(Document.user_id == current_user.id).count()

    # User issues
    issues_query = db.query(DetectedIssue).join(Analysis).filter(
        Analysis.user_id == current_user.id,
        DetectedIssue.category != "Consistent"
    )
    total_issues = issues_query.count()
    high_sev_issues = issues_query.filter(DetectedIssue.severity.in_(["Critical", "High"])).count()
    pending_reviews = issues_query.filter(DetectedIssue.verification_status == "pending").count()
    approved_findings = issues_query.filter(DetectedIssue.verification_status.in_(["approved", "confirmed"])).count()
    corrected_findings = issues_query.filter(DetectedIssue.verification_status == "corrected").count()

    # Average consistency score
    avg_score_res = db.query(func.avg(Analysis.consistency_score)).filter(
        Analysis.user_id == current_user.id,
        Analysis.status == "completed"
    ).scalar()
    avg_score = round(float(avg_score_res), 1) if avg_score_res is not None else 100.0

    # Recent analyses
    recent = db.query(Analysis).filter(Analysis.user_id == current_user.id).order_by(Analysis.created_at.desc()).limit(5).all()
    recent_outs = []
    for a in recent:
        item = AnalysisOut.model_validate(a)
        if a.old_document:
            item.old_doc_name = a.old_document.filename
        if a.new_document:
            item.new_doc_name = a.new_document.filename
        recent_outs.append(item)

    return DashboardSummaryOut(
        total_analyses=total_analyses,
        total_documents=total_docs,
        total_issues=total_issues,
        average_consistency_score=avg_score,
        high_severity_issues=high_sev_issues,
        reports_generated=total_analyses,
        pending_reviews=pending_reviews,
        approved_findings=approved_findings,
        corrected_findings=corrected_findings,
        recent_analyses=recent_outs
    )

@router.get("/dashboard/charts", response_model=DashboardChartsOut)
def get_dashboard_charts(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    analyses = db.query(Analysis).filter(
        Analysis.user_id == current_user.id,
        Analysis.status == "completed"
    ).order_by(Analysis.created_at.asc()).all()

    # 1. Score trends over time
    score_trends = []
    activity_by_date_map = {}
    consistent_count = 0
    inconsistent_count = 0

    for idx, a in enumerate(analyses, 1):
        dt_str = a.created_at.strftime("%b %d")
        score_trends.append({
            "name": f"Audit #{idx}",
            "date": dt_str,
            "score": round(a.consistency_score, 1),
            "issues": a.confirmed_issues_count
        })
        activity_by_date_map[dt_str] = activity_by_date_map.get(dt_str, 0) + 1

    activity_by_date = [{"date": k, "analyses": v} for k, v in activity_by_date_map.items()]

    # 2. Issues distribution by category & severity & confidence
    issues = db.query(DetectedIssue).join(Analysis).filter(Analysis.user_id == current_user.id).all()
    cat_map = {
        "Contradiction": 0,
        "Outdated Information": 0,
        "Missing Content": 0,
        "Terminology Inconsistency": 0,
        "Consistent": 0
    }
    sev_map = {
        "Critical": 0,
        "High": 0,
        "Medium": 0,
        "Low": 0,
        "Informational": 0
    }
    conf_buckets = {"50-65%": 0, "65-80%": 0, "80-90%": 0, "90-100%": 0}

    for iss in issues:
        cat = iss.category
        sev = iss.severity
        conf = float(iss.confidence or 0.8)

        if cat in cat_map:
            cat_map[cat] += 1
        else:
            cat_map[cat] = 1

        if sev in sev_map:
            sev_map[sev] += 1
        else:
            sev_map[sev] = 1

        if cat == "Consistent":
            consistent_count += 1
        else:
            inconsistent_count += 1

        if conf < 0.65:
            conf_buckets["50-65%"] += 1
        elif conf < 0.80:
            conf_buckets["65-80%"] += 1
        elif conf < 0.90:
            conf_buckets["80-90%"] += 1
        else:
            conf_buckets["90-100%"] += 1

    category_dist = [{"name": k, "value": v} for k, v in cat_map.items() if v > 0]
    severity_dist = [{"name": k, "count": v} for k, v in sev_map.items()]
    consistent_vs_inconsistent = [
        {"name": "Consistent Statements", "value": consistent_count},
        {"name": "Inconsistencies Flagged", "value": inconsistent_count}
    ]
    confidence_dist = [{"range": k, "count": v} for k, v in conf_buckets.items()]

    # Review Status Breakdown for actual findings
    status_counts = {"Pending Review": 0, "Approved": 0, "Rejected": 0, "Corrected": 0}
    for iss in issues:
        if iss.category == "Consistent":
            continue
        st = (iss.verification_status or "pending").lower()
        if st in ["approved", "confirmed"]:
            status_counts["Approved"] += 1
        elif st == "rejected":
            status_counts["Rejected"] += 1
        elif st == "corrected":
            status_counts["Corrected"] += 1
        else:
            status_counts["Pending Review"] += 1

    review_status_dist = [{"status": k, "count": v} for k, v in status_counts.items()]

    return DashboardChartsOut(
        score_trends=score_trends,
        category_distribution=category_dist,
        severity_distribution=severity_dist,
        activity_by_date=activity_by_date,
        consistent_vs_inconsistent=consistent_vs_inconsistent,
        confidence_distribution=confidence_dist,
        review_status_distribution=review_status_dist
    )
