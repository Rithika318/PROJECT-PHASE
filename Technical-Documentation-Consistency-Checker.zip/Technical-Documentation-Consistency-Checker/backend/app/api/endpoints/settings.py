from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.database.session import get_db
from app.models.entities import User, UserSettings
from app.schemas.domain import UserSettingsOut, UserSettingsUpdate
from app.api.deps import get_current_user

router = APIRouter(prefix="/settings", tags=["Settings"])

@router.get("", response_model=UserSettingsOut)
def get_user_settings(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    settings_rec = db.query(UserSettings).filter(UserSettings.user_id == current_user.id).first()
    if not settings_rec:
        settings_rec = UserSettings(user_id=current_user.id)
        db.add(settings_rec)
        db.commit()
        db.refresh(settings_rec)
    return UserSettingsOut.model_validate(settings_rec)

@router.put("", response_model=UserSettingsOut)
def update_user_settings(
    settings_in: UserSettingsUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    settings_rec = db.query(UserSettings).filter(UserSettings.user_id == current_user.id).first()
    if not settings_rec:
        settings_rec = UserSettings(user_id=current_user.id)
        db.add(settings_rec)

    for field, value in settings_in.model_dump(exclude_unset=True).items():
        setattr(settings_rec, field, value)

    db.commit()
    db.refresh(settings_rec)
    return UserSettingsOut.model_validate(settings_rec)
