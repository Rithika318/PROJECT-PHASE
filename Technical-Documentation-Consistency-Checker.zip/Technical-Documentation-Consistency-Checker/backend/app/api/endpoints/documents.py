import os
import uuid
import shutil
from pathlib import Path
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, status
from sqlalchemy.orm import Session
from app.database.session import get_db
from app.models.entities import User, Document, DocumentChunk
from app.schemas.domain import DocumentOut, DocumentDetailOut
from app.api.deps import get_current_user
from app.core.config import settings
from app.document_processing.extractor import DocumentExtractor
from app.document_processing.chunker import DocumentChunker
from app.services.sample_docs_generator import generate_sample_documents

router = APIRouter(prefix="/documents", tags=["Documents"])

@router.post("/upload", response_model=DocumentOut, status_code=status.HTTP_201_CREATED)
async def upload_document(
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    original_filename = file.filename or "uploaded_document"
    ext = os.path.splitext(original_filename)[1].lower()

    if ext not in settings.ALLOWED_EXTENSIONS:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Unsupported file format '{ext}'. Allowed formats: {', '.join(settings.ALLOWED_EXTENSIONS)}"
        )

    # Secure random storage filename
    unique_name = f"{uuid.uuid4().hex[:12]}_{original_filename}"
    saved_path = settings.UPLOADS_DIR / unique_name

    # Save to disk with size check
    total_bytes = 0
    max_bytes = settings.MAX_UPLOAD_SIZE_MB * 1024 * 1024

    with open(saved_path, "wb") as buffer:
        while chunk := await file.read(1024 * 64):
            total_bytes += len(chunk)
            if total_bytes > max_bytes:
                buffer.close()
                if saved_path.exists():
                    os.remove(saved_path)
                raise HTTPException(
                    status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                    detail=f"File exceeds maximum upload limit of {settings.MAX_UPLOAD_SIZE_MB}MB."
                )
            buffer.write(chunk)

    if total_bytes == 0:
        if saved_path.exists():
            os.remove(saved_path)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="The uploaded file is empty (0 bytes)."
        )

    # Extract text and metadata
    try:
        extraction = DocumentExtractor.extract(saved_path)
    except Exception as e:
        if saved_path.exists():
            os.remove(saved_path)
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Failed to process document content: {str(e)}"
        )

    if extraction.is_empty:
        if saved_path.exists():
            os.remove(saved_path)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No readable text found in document. If this is a scanned image, OCR is required."
        )

    # Create Document record
    doc_record = Document(
        user_id=current_user.id,
        filename=original_filename,
        stored_filename=unique_name,
        file_path=str(saved_path),
        file_type=ext.replace(".", ""),
        file_size=total_bytes,
        word_count=extraction.word_count,
        section_count=len(extraction.sections),
        extraction_status="completed",
        is_scanned_ocr_needed=extraction.is_scanned_ocr_needed
    )
    db.add(doc_record)
    db.commit()
    db.refresh(doc_record)

    # Chunk and store chunks
    chunks = DocumentChunker.chunk_sections(extraction.sections)
    for c in chunks:
        chunk_ent = DocumentChunk(
            document_id=doc_record.id,
            chunk_index=c.chunk_index,
            page_number=c.page_number,
            section_heading=c.section_heading,
            content=c.content,
            token_count=c.token_count,
            metadata_json=c.metadata
        )
        db.add(chunk_ent)
    
    doc_record.chunk_count = len(chunks)
    db.commit()
    db.refresh(doc_record)

    return DocumentOut.model_validate(doc_record)

@router.get("", response_model=list[DocumentOut])
def list_documents(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    docs = db.query(Document).filter(Document.user_id == current_user.id).order_by(Document.created_at.desc()).all()
    return [DocumentOut.model_validate(d) for d in docs]

@router.get("/{document_id}", response_model=DocumentDetailOut)
def get_document(
    document_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    doc = db.query(Document).filter(Document.id == document_id, Document.user_id == current_user.id).first()
    if not doc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Document not found.")
    return DocumentDetailOut.model_validate(doc)

@router.delete("/{document_id}")
def delete_document(
    document_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    doc = db.query(Document).filter(Document.id == document_id, Document.user_id == current_user.id).first()
    if not doc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Document not found.")

    # Remove file from disk
    try:
        p = Path(doc.file_path)
        if p.exists():
            p.unlink()
    except Exception:
        pass

    db.delete(doc)
    db.commit()
    return {"message": "Document deleted successfully."}

@router.post("/load-sample", response_model=list[DocumentOut])
def load_sample_documents(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Generates and registers sample Cloud Core API v1.0 and v2.0 documents for instant comparison.
    """
    v1_path, v2_path = generate_sample_documents()
    
    created_docs = []
    for file_path, name in [(v1_path, "Cloud_Core_API_Specification_v1.0.docx"), (v2_path, "Cloud_Core_API_Specification_v2.0.docx")]:
        extraction = DocumentExtractor.extract(file_path)
        file_size = os.path.getsize(file_path)

        doc_record = Document(
            user_id=current_user.id,
            filename=name,
            stored_filename=file_path.name,
            file_path=str(file_path),
            file_type="docx",
            file_size=file_size,
            word_count=extraction.word_count,
            section_count=len(extraction.sections),
            extraction_status="completed",
            is_scanned_ocr_needed=False
        )
        db.add(doc_record)
        db.commit()
        db.refresh(doc_record)

        chunks = DocumentChunker.chunk_sections(extraction.sections)
        for c in chunks:
            chunk_ent = DocumentChunk(
                document_id=doc_record.id,
                chunk_index=c.chunk_index,
                page_number=c.page_number,
                section_heading=c.section_heading,
                content=c.content,
                token_count=c.token_count,
                metadata_json=c.metadata
            )
            db.add(chunk_ent)
        doc_record.chunk_count = len(chunks)
        db.commit()
        db.refresh(doc_record)
        created_docs.append(DocumentOut.model_validate(doc_record))

    return created_docs

upload_router = APIRouter(prefix="/upload", tags=["Upload"])

@upload_router.post("", response_model=DocumentOut, status_code=status.HTTP_201_CREATED)
async def upload_document_direct(
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    return await upload_document(file, current_user, db)
