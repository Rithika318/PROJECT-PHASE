import os
import uuid
from pathlib import Path
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Response, status
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from app.database.session import get_db
from app.models.entities import User, Dataset
from app.schemas.domain import DatasetOut
from app.api.deps import get_current_user
from app.core.config import settings
from app.services.training_service import TrainingService

router = APIRouter(prefix="/datasets", tags=["Datasets"])

@router.post("/upload", response_model=DatasetOut, status_code=status.HTTP_201_CREATED)
async def upload_dataset(
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    original_filename = file.filename or "dataset.csv"
    ext = os.path.splitext(original_filename)[1].lower()

    if ext not in [".csv", ".jsonl"]:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Only .csv and .jsonl datasets are supported."
        )

    unique_name = f"{uuid.uuid4().hex[:10]}_{original_filename}"
    saved_path = settings.DATASETS_DIR / unique_name

    with open(saved_path, "wb") as buffer:
        content = await file.read()
        buffer.write(content)

    try:
        parsed = TrainingService.validate_and_parse_dataset(saved_path)
    except Exception as e:
        if saved_path.exists():
            saved_path.unlink()
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Dataset validation failed: {str(e)}"
        )

    dataset_record = Dataset(
        user_id=current_user.id,
        filename=original_filename,
        file_path=str(saved_path),
        row_count=parsed["valid_rows"],
        label_distribution_json=parsed["label_distribution"],
        validation_status="valid",
        train_count=parsed["train_count"],
        val_count=parsed["val_count"],
        test_count=parsed["test_count"]
    )
    db.add(dataset_record)
    db.commit()
    db.refresh(dataset_record)

    return DatasetOut.model_validate(dataset_record)

@router.get("", response_model=list[DatasetOut])
def list_datasets(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    datasets = db.query(Dataset).filter(Dataset.user_id == current_user.id).order_by(Dataset.created_at.desc()).all()
    return [DatasetOut.model_validate(d) for d in datasets]

@router.get("/sample/download")
def download_sample_dataset():
    sample_path = TrainingService.create_sample_dataset_file()
    return FileResponse(
        path=str(sample_path),
        media_type="text/csv",
        filename="sample_consistency_dataset.csv"
    )

@router.get("/template/download")
def download_dataset_template():
    csv_str = TrainingService.get_csv_template()
    return Response(
        content=csv_str,
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=consistency_dataset_template.csv"}
    )
