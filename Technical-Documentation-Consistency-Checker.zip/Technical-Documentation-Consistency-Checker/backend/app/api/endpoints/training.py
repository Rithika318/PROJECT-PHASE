import asyncio
import time
from datetime import datetime, timezone
from pathlib import Path
from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks, status
from sqlalchemy.orm import Session
from app.database.session import get_db, SessionLocal
from app.models.entities import User, Dataset, TrainingJob, ModelEvaluation, UserSettings
from app.schemas.domain import (
    TrainingConfigSchema, TrainingJobOut, EvaluationRequest, EvaluationOut
)
from app.api.deps import get_current_user
from app.services.training_service import TrainingService

router = APIRouter(prefix="/training", tags=["Training & Evaluation"])

def _run_training_job_simulation(job_id: str):
    db = SessionLocal()
    try:
        job = db.query(TrainingJob).filter(TrainingJob.id == job_id).first()
        if not job:
            return

        job.status = "running"
        job.progress_percent = 10
        db.commit()

        # Simulate progressive loss reduction across 3 epochs
        loss_history = []
        for epoch in range(1, 4):
            time.sleep(1.0)
            train_loss = round(0.85 / epoch + 0.05, 4)
            val_loss = round(0.92 / epoch + 0.08, 4)
            loss_history.append({"epoch": epoch, "train_loss": train_loss, "val_loss": val_loss})
            job.progress_percent = int((epoch / 3.0) * 90)
            job.training_loss_history_json = loss_history
            db.commit()

        job.status = "completed"
        job.progress_percent = 100
        job.completed_at = datetime.now(timezone.utc)
        job.adapter_path = "training/checkpoints/lora_adapter"
        job.val_metrics_json = {
            "validation_accuracy": 0.895,
            "macro_f1": 0.882,
            "final_loss": 0.385
        }
        db.commit()
    except Exception as e:
        db.rollback()
        if job:
            job.status = "failed"
            job.error_message = str(e)
            db.commit()
    finally:
        db.close()

@router.post("/jobs", response_model=TrainingJobOut, status_code=status.HTTP_202_ACCEPTED)
def create_training_job(
    config: TrainingConfigSchema,
    background_tasks: BackgroundTasks,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    dataset = db.query(Dataset).filter(Dataset.id == config.dataset_id, Dataset.user_id == current_user.id).first()
    if not dataset:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Dataset not found or unauthorized.")

    job = TrainingJob(
        user_id=current_user.id,
        dataset_id=dataset.id,
        status="pending",
        progress_percent=0,
        config_json=config.model_dump()
    )
    db.add(job)
    db.commit()
    db.refresh(job)

    # Launch in background
    background_tasks.add_task(_run_training_job_simulation, job.id)

    return TrainingJobOut.model_validate(job)

@router.get("/jobs/{job_id}", response_model=TrainingJobOut)
def get_training_job(
    job_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    job = db.query(TrainingJob).filter(TrainingJob.id == job_id, TrainingJob.user_id == current_user.id).first()
    if not job:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Training job not found.")
    return TrainingJobOut.model_validate(job)

@router.post("/evaluations", response_model=EvaluationOut, status_code=status.HTTP_201_CREATED)
def run_model_evaluation(
    eval_req: EvaluationRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    dataset = db.query(Dataset).filter(Dataset.id == eval_req.dataset_id, Dataset.user_id == current_user.id).first()
    if not dataset:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Dataset not found.")

    # Parse dataset rows for test evaluation
    parsed = TrainingService.validate_and_parse_dataset(Path(dataset.file_path))
    test_rows = parsed["rows"][parsed["train_count"] + parsed["val_count"]:]
    if not test_rows:
        test_rows = parsed["rows"]  # fallback if dataset is small

    metrics = TrainingService.evaluate_model_on_dataset(
        model_name=eval_req.model_name,
        rows=test_rows,
        use_adapter=eval_req.use_adapter
    )

    eval_record = ModelEvaluation(
        user_id=current_user.id,
        model_name=eval_req.model_name + (" (LoRA Adapter)" if eval_req.use_adapter else " (Base)"),
        dataset_id=dataset.id,
        accuracy=metrics["accuracy"],
        precision=metrics["precision"],
        recall=metrics["recall"],
        macro_f1=metrics["macro_f1"],
        per_class_metrics_json=metrics["per_class_metrics"],
        confusion_matrix_json=metrics["confusion_matrix"]
    )
    db.add(eval_record)
    db.commit()
    db.refresh(eval_record)

    return EvaluationOut.model_validate(eval_record)

@router.get("/evaluations", response_model=list[EvaluationOut])
def list_evaluations(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    evals = db.query(ModelEvaluation).filter(ModelEvaluation.user_id == current_user.id).order_by(ModelEvaluation.created_at.desc()).all()
    return [EvaluationOut.model_validate(e) for e in evals]
