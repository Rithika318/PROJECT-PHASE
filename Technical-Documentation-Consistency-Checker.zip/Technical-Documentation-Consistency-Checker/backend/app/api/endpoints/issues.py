from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session
from app.database.session import get_db
from app.models.entities import User, DetectedIssue, Analysis
from app.schemas.domain import DetectedIssueOut, IssueReviewUpdate, IssueCommentCreate, IssueCorrectionUpdate
from app.api.deps import get_current_user

router = APIRouter(prefix="/issues", tags=["Issue Review"])

def _enrich_issue_out(issue: DetectedIssue, analysis: Optional[Analysis] = None) -> DetectedIssueOut:
    out = DetectedIssueOut.model_validate(issue)
    if analysis or issue.analysis:
        a = analysis or issue.analysis
        out.analysis_title = a.title
        if a.old_document:
            out.old_doc_name = a.old_document.filename
        if a.new_document:
            out.new_doc_name = a.new_document.filename
    return out

@router.get("", response_model=list[DetectedIssueOut])
def list_issues(
    analysis_id: Optional[str] = Query(None, description="Filter issues by analysis ID"),
    category: Optional[str] = Query(None, description="Filter issues by category"),
    severity: Optional[str] = Query(None, description="Filter issues by severity"),
    verification_status: Optional[str] = Query(None, description="Filter issues by verification status"),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    query = db.query(DetectedIssue).join(Analysis).filter(
        Analysis.user_id == current_user.id
    )
    if analysis_id:
        query = query.filter(DetectedIssue.analysis_id == analysis_id)
    if category and category != "All":
        query = query.filter(DetectedIssue.category == category)
    if severity and severity != "All":
        query = query.filter(DetectedIssue.severity == severity)
    if verification_status and verification_status != "All":
        if verification_status == "approved":
            query = query.filter(DetectedIssue.verification_status.in_(["approved", "confirmed"]))
        else:
            query = query.filter(DetectedIssue.verification_status == verification_status)

    issues = query.order_by(DetectedIssue.created_at.desc(), DetectedIssue.issue_code).all()
    return [_enrich_issue_out(iss) for iss in issues]

@router.get("/{issue_id}", response_model=DetectedIssueOut)
def get_issue_detail(
    issue_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    issue = db.query(DetectedIssue).join(Analysis).filter(
        DetectedIssue.id == issue_id,
        Analysis.user_id == current_user.id
    ).first()

    if not issue:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Issue not found or unauthorized.")

    return _enrich_issue_out(issue)

@router.patch("/{issue_id}/review", response_model=DetectedIssueOut)
def review_issue(
    issue_id: str,
    review_in: IssueReviewUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    issue = db.query(DetectedIssue).join(Analysis).filter(
        DetectedIssue.id == issue_id,
        Analysis.user_id == current_user.id
    ).first()

    if not issue:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Issue not found or unauthorized.")

    # Accept all valid statuses for human approval workflow
    valid_statuses = ["confirmed", "approved", "rejected", "reviewed", "pending", "corrected"]
    normalized_status = review_in.verification_status.lower()
    if normalized_status not in valid_statuses:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid verification status. Must be one of: {', '.join(valid_statuses)}"
        )

    # Store normalized status ('approved' is alias for 'confirmed')
    if normalized_status == "approved":
        normalized_status = "confirmed"

    issue.verification_status = normalized_status
    if review_in.reviewer_notes is not None:
        issue.reviewer_notes = review_in.reviewer_notes

    # Update analysis review_required_count
    if issue.analysis:
        analysis_issues = db.query(DetectedIssue).filter(
            DetectedIssue.analysis_id == issue.analysis_id,
            DetectedIssue.category != "Consistent"
        ).all()
        issue.analysis.review_required_count = sum(1 for iss in analysis_issues if iss.verification_status == "pending")

    db.commit()
    db.refresh(issue)
    return _enrich_issue_out(issue)

@router.patch("/{issue_id}/correction", response_model=DetectedIssueOut)
def update_issue_correction(
    issue_id: str,
    correction_in: IssueCorrectionUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Update the suggested correction text for a detected issue."""
    issue = db.query(DetectedIssue).join(Analysis).filter(
        DetectedIssue.id == issue_id,
        Analysis.user_id == current_user.id
    ).first()

    if not issue:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Issue not found or unauthorized.")

    issue.suggested_correction = correction_in.suggested_correction
    db.commit()
    db.refresh(issue)
    return _enrich_issue_out(issue)

@router.post("/{issue_id}/comments", response_model=DetectedIssueOut)
def add_issue_comment(
    issue_id: str,
    comment_in: IssueCommentCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    issue = db.query(DetectedIssue).join(Analysis).filter(
        DetectedIssue.id == issue_id,
        Analysis.user_id == current_user.id
    ).first()

    if not issue:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Issue not found or unauthorized.")

    existing_notes = issue.reviewer_notes or ""
    new_note = f"[{current_user.full_name}]: {comment_in.comment}"
    if existing_notes:
        issue.reviewer_notes = f"{existing_notes}\n{new_note}"
    else:
        issue.reviewer_notes = new_note

    db.commit()
    db.refresh(issue)
    return _enrich_issue_out(issue)

@router.patch("/{issue_id}/status", response_model=DetectedIssueOut)
def update_issue_status(
    issue_id: str,
    review_in: IssueReviewUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Direct alias for updating issue review status (approved, rejected, corrected)."""
    return review_issue(issue_id, review_in, current_user, db)
