import asyncio
from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks, status
from sqlalchemy.orm import Session
from app.database.session import get_db, SessionLocal
from app.models.entities import User, Document, Analysis, DetectedIssue
from app.schemas.domain import (
    AnalysisCreate, AnalysisOut, AnalysisDetailOut, AnalysisStatusOut, DetectedIssueOut
)
from app.api.deps import get_current_user
from app.services.analysis_orchestrator import AnalysisOrchestrator, STAGE_NAMES

router = APIRouter(prefix="/analyses", tags=["Analysis"])

def _run_analysis_in_background(analysis_id: str):
    db = SessionLocal()
    try:
        AnalysisOrchestrator.run_analysis(analysis_id, db)
    finally:
        db.close()

@router.post("", response_model=AnalysisOut, status_code=status.HTTP_202_ACCEPTED)
def create_analysis(
    analysis_in: AnalysisCreate,
    background_tasks: BackgroundTasks,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    old_doc = db.query(Document).filter(Document.id == analysis_in.old_doc_id, Document.user_id == current_user.id).first()
    new_doc = db.query(Document).filter(Document.id == analysis_in.new_doc_id, Document.user_id == current_user.id).first()

    if not old_doc or not new_doc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="One or both selected documents do not exist or do not belong to you."
        )

    analysis = Analysis(
        user_id=current_user.id,
        title=analysis_in.title,
        description=analysis_in.description,
        old_doc_id=old_doc.id,
        new_doc_id=new_doc.id,
        status="extracting",
        progress_stage=1,
        progress_percent=10
    )
    db.add(analysis)
    db.commit()
    db.refresh(analysis)

    # Dispatch to background task
    background_tasks.add_task(_run_analysis_in_background, analysis.id)

    out = AnalysisOut.model_validate(analysis)
    out.old_doc_name = old_doc.filename
    out.new_doc_name = new_doc.filename
    return out

@router.get("", response_model=list[AnalysisOut])
def list_analyses(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    analyses = db.query(Analysis).filter(Analysis.user_id == current_user.id).order_by(Analysis.created_at.desc()).all()
    results = []
    for a in analyses:
        item = AnalysisOut.model_validate(a)
        if a.old_document:
            item.old_doc_name = a.old_document.filename
        if a.new_document:
            item.new_doc_name = a.new_document.filename
        if a.issues:
            item.approved_count = sum(1 for iss in a.issues if iss.verification_status in ["approved", "confirmed"])
            item.rejected_count = sum(1 for iss in a.issues if iss.verification_status == "rejected")
            item.corrected_count = sum(1 for iss in a.issues if iss.verification_status == "corrected")
            item.pending_count = sum(1 for iss in a.issues if iss.verification_status == "pending")
        results.append(item)
    return results

@router.get("/{analysis_id}", response_model=AnalysisDetailOut)
def get_analysis_detail(
    analysis_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    analysis = db.query(Analysis).filter(Analysis.id == analysis_id, Analysis.user_id == current_user.id).first()
    if not analysis:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Analysis record not found.")

    issues = db.query(DetectedIssue).filter(DetectedIssue.analysis_id == analysis.id).order_by(DetectedIssue.issue_code).all()
    
    category_counts = {
        "Consistent": 0,
        "Contradiction": 0,
        "Outdated Information": 0,
        "Missing Content": 0,
        "Terminology Inconsistency": 0
    }
    severity_counts = {
        "Critical": 0,
        "High": 0,
        "Medium": 0,
        "Low": 0,
        "Informational": 0
    }

    for iss in issues:
        category_counts[iss.category] = category_counts.get(iss.category, 0) + 1
        severity_counts[iss.severity] = severity_counts.get(iss.severity, 0) + 1

    detail = AnalysisDetailOut.model_validate(analysis)
    old_doc_name = analysis.old_document.filename if analysis.old_document else "Document A"
    new_doc_name = analysis.new_document.filename if analysis.new_document else "Document B"
    detail.old_doc_name = old_doc_name
    detail.new_doc_name = new_doc_name

    detail.approved_count = sum(1 for iss in issues if iss.verification_status in ["approved", "confirmed"])
    detail.rejected_count = sum(1 for iss in issues if iss.verification_status == "rejected")
    detail.corrected_count = sum(1 for iss in issues if iss.verification_status == "corrected")
    detail.pending_count = sum(1 for iss in issues if iss.verification_status == "pending")

    enriched_issues = []
    for i in issues:
        iss_out = DetectedIssueOut.model_validate(i)
        iss_out.analysis_title = analysis.title
        iss_out.old_doc_name = old_doc_name
        iss_out.new_doc_name = new_doc_name
        enriched_issues.append(iss_out)

    detail.issues = enriched_issues
    detail.category_counts = category_counts
    detail.severity_counts = severity_counts
    return detail

@router.get("/{analysis_id}/issues", response_model=list[DetectedIssueOut])
def get_analysis_issues(
    analysis_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    analysis = db.query(Analysis).filter(Analysis.id == analysis_id, Analysis.user_id == current_user.id).first()
    if not analysis:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Analysis record not found.")

    issues = db.query(DetectedIssue).filter(DetectedIssue.analysis_id == analysis.id).order_by(DetectedIssue.issue_code).all()
    return [DetectedIssueOut.model_validate(i) for i in issues]

@router.get("/{analysis_id}/status", response_model=AnalysisStatusOut)
def get_analysis_status(
    analysis_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    analysis = db.query(Analysis).filter(Analysis.id == analysis_id, Analysis.user_id == current_user.id).first()
    if not analysis:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Analysis record not found.")

    stage_name = STAGE_NAMES.get(analysis.progress_stage, "Processing documentation")
    is_completed = analysis.status in ["completed", "failed"]

    return AnalysisStatusOut(
        id=analysis.id,
        status=analysis.status,
        progress_stage=analysis.progress_stage,
        stage_name=stage_name,
        progress_percent=analysis.progress_percent,
        error_message=analysis.error_message,
        consistency_score=analysis.consistency_score if is_completed else None,
        is_completed=is_completed
    )

@router.delete("/{analysis_id}")
def delete_analysis(
    analysis_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    analysis = db.query(Analysis).filter(Analysis.id == analysis_id, Analysis.user_id == current_user.id).first()
    if not analysis:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Analysis record not found.")

    db.delete(analysis)
    db.commit()
    return {"message": "Analysis deleted successfully."}

# Aliases for direct endpoint access matching final-year project specifications
compare_router = APIRouter(prefix="/compare", tags=["Compare"])
@compare_router.post("", response_model=AnalysisOut, status_code=status.HTTP_202_ACCEPTED)
def compare_documents_alias(
    analysis_in: AnalysisCreate,
    background_tasks: BackgroundTasks,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    return create_analysis(analysis_in, background_tasks, current_user, db)

history_router = APIRouter(prefix="/history", tags=["History"])
@history_router.get("", response_model=list[AnalysisOut])
def list_history_alias(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    return list_analyses(current_user, db)

@history_router.get("/{analysis_id}", response_model=AnalysisDetailOut)
def get_history_detail_alias(
    analysis_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    return get_analysis_detail(analysis_id, current_user, db)

results_router = APIRouter(prefix="/results", tags=["Results"])
@results_router.get("/{analysis_id}", response_model=AnalysisDetailOut)
def get_results_detail_alias(
    analysis_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    return get_analysis_detail(analysis_id, current_user, db)
