from fastapi import APIRouter
from app.api.endpoints import (
    auth, documents, analyses, issues, reports, datasets, training, system, settings
)

api_router = APIRouter(prefix="/api")

api_router.include_router(auth.router)
api_router.include_router(documents.router)
api_router.include_router(documents.upload_router)
api_router.include_router(analyses.router)
api_router.include_router(analyses.compare_router)
api_router.include_router(analyses.history_router)
api_router.include_router(analyses.results_router)
api_router.include_router(issues.router)
api_router.include_router(reports.router)
api_router.include_router(reports.reports_direct_router)
api_router.include_router(datasets.router)
api_router.include_router(training.router)
api_router.include_router(system.router)
api_router.include_router(settings.router)
