import os
from pathlib import Path
from pydantic import BaseModel

# Base directory for the project
BASE_DIR = Path(__file__).resolve().parent.parent.parent.parent
BACKEND_DIR = Path(__file__).resolve().parent.parent.parent
DATABASE_DIR = BASE_DIR / "database"
REPORTS_DIR = BASE_DIR / "reports"
STORAGE_DIR = BASE_DIR / "storage"
UPLOADS_DIR = STORAGE_DIR / "uploads"
DATASETS_DIR = STORAGE_DIR / "datasets"
CHECKPOINTS_DIR = BASE_DIR / "training" / "checkpoints"

# Ensure runtime directories exist
for directory in [DATABASE_DIR, REPORTS_DIR, UPLOADS_DIR, DATASETS_DIR, CHECKPOINTS_DIR]:
    directory.mkdir(parents=True, exist_ok=True)

# Default database path: prefer database/consistency_checker.db
default_db_file = DATABASE_DIR / "consistency_checker.db"
if not default_db_file.exists() and (STORAGE_DIR / "consistency_checker.db").exists():
    default_db_file = STORAGE_DIR / "consistency_checker.db"

class Settings(BaseModel):
    PROJECT_NAME: str = "LLM-Based Technical Documentation Consistency Checker"
    API_V1_STR: str = "/api"
    
    # Security & JWT
    SECRET_KEY: str = os.getenv("SECRET_KEY", "super-secret-production-grade-jwt-key-for-doc-checker-2026")
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24 * 7  # 7 days
    
    # Database
    DATABASE_URL: str = os.getenv("DATABASE_URL", f"sqlite:///{default_db_file}")
    
    # Ollama Local LLM
    OLLAMA_BASE_URL: str = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
    OLLAMA_MODEL: str = os.getenv("OLLAMA_MODEL", "llama3.1:8b")
    OLLAMA_TIMEOUT: int = int(os.getenv("OLLAMA_TIMEOUT", "120"))
    
    # NLP Models
    SBERT_MODEL_NAME: str = os.getenv("SBERT_MODEL_NAME", "all-MiniLM-L6-v2")
    NLI_MODEL_NAME: str = os.getenv("NLI_MODEL_NAME", "cross-encoder/nli-deberta-v3-small")
    
    # Storage directories
    BASE_DIR: Path = BASE_DIR
    DATABASE_DIR: Path = DATABASE_DIR
    REPORTS_DIR: Path = REPORTS_DIR
    STORAGE_DIR: Path = STORAGE_DIR
    UPLOADS_DIR: Path = UPLOADS_DIR
    DATASETS_DIR: Path = DATASETS_DIR
    CHECKPOINTS_DIR: Path = CHECKPOINTS_DIR
    
    # File limits
    MAX_UPLOAD_SIZE_MB: int = int(os.getenv("MAX_UPLOAD_SIZE_MB", "50"))
    ALLOWED_EXTENSIONS: list[str] = [".pdf", ".docx", ".txt"]
    
    # Analysis & Scoring Configuration Defaults
    DEFAULT_SIMILARITY_THRESHOLD: float = float(os.getenv("DEFAULT_SIMILARITY_THRESHOLD", "0.55"))
    DEFAULT_CONFIDENCE_THRESHOLD: float = float(os.getenv("DEFAULT_CONFIDENCE_THRESHOLD", "0.50"))
    
    # Scoring Severity Weights
    SEVERITY_WEIGHT_CRITICAL: float = 25.0
    SEVERITY_WEIGHT_HIGH: float = 15.0
    SEVERITY_WEIGHT_MEDIUM: float = 8.0
    SEVERITY_WEIGHT_LOW: float = 3.0
    SEVERITY_WEIGHT_INFORMATIONAL: float = 0.0

settings = Settings()
