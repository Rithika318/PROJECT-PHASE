import time
import asyncio
from datetime import datetime, timezone
from sqlalchemy.orm import Session
from app.models.entities import Analysis, Document, DocumentChunk, MatchedPair, DetectedIssue
from app.document_processing.extractor import DocumentExtractor
from app.document_processing.chunker import DocumentChunker
from app.ml.embeddings import EmbeddingMatcher
from app.ml.nli_classifier import DeBERTaNLIClassifier
from app.ml.ollama_client import OllamaClient
from app.ml.consistency_scorer import ConsistencyScorer
from app.reports.pdf_generator import generate_pdf_report

STAGE_NAMES = {
    1: "Uploading & validating documents",
    2: "Extracting text, sections, and metadata",
    3: "Preprocessing and semantic chunking",
    4: "Generating Sentence-BERT semantic embeddings",
    5: "Aligning related sections via cosine similarity",
    6: "Screening candidate pairs with DeBERTa-v3 NLI",
    7: "Verifying discrepancies with Llama 3.1 8B Instruct",
    8: "Calculating consistency scores and compiling audit report"
}

class AnalysisOrchestrator:
    """
    Executes the 8-stage documentation consistency checking pipeline.
    Updates database progress in real-time for live frontend tracking.
    """

    @classmethod
    def run_analysis(cls, analysis_id: str, db: Session):
        analysis = db.query(Analysis).filter(Analysis.id == analysis_id).first()
        if not analysis:
            return

        start_time = time.time()
        try:
            # Stage 1: Document validation
            cls._update_progress(db, analysis, stage=1, percent=10, status="extracting")
            old_doc = db.query(Document).filter(Document.id == analysis.old_doc_id).first()
            new_doc = db.query(Document).filter(Document.id == analysis.new_doc_id).first()
            if not old_doc or not new_doc:
                raise ValueError("Could not find one or both source documents.")

            # Stage 2: Extract text & sections
            cls._update_progress(db, analysis, stage=2, percent=25, status="extracting")
            old_extraction = DocumentExtractor.extract(old_doc.file_path)
            new_extraction = DocumentExtractor.extract(new_doc.file_path)

            old_doc.word_count = old_extraction.word_count
            old_doc.section_count = len(old_extraction.sections)
            old_doc.is_scanned_ocr_needed = old_extraction.is_scanned_ocr_needed
            old_doc.extraction_status = "completed"

            new_doc.word_count = new_extraction.word_count
            new_doc.section_count = len(new_extraction.sections)
            new_doc.is_scanned_ocr_needed = new_extraction.is_scanned_ocr_needed
            new_doc.extraction_status = "completed"
            db.commit()

            # Stage 3: Semantic Chunking
            cls._update_progress(db, analysis, stage=3, percent=40, status="chunking")
            old_chunks = DocumentChunker.chunk_sections(old_extraction.sections)
            new_chunks = DocumentChunker.chunk_sections(new_extraction.sections)

            # Persist chunks only if document has no existing chunks (avoid duplication on re-run)
            old_chunk_entities = []
            existing_old_count = db.query(DocumentChunk).filter(DocumentChunk.document_id == old_doc.id).count()
            if existing_old_count == 0:
                for c in old_chunks:
                    chunk_ent = DocumentChunk(
                        document_id=old_doc.id,
                        chunk_index=c.chunk_index,
                        page_number=c.page_number,
                        section_heading=c.section_heading,
                        content=c.content,
                        token_count=c.token_count,
                        metadata_json=c.metadata
                    )
                    db.add(chunk_ent)
                    old_chunk_entities.append(chunk_ent)
                db.commit()
                for e in old_chunk_entities:
                    db.refresh(e)
            else:
                # Reuse existing chunks
                old_chunk_entities = db.query(DocumentChunk).filter(
                    DocumentChunk.document_id == old_doc.id
                ).order_by(DocumentChunk.chunk_index).all()

            new_chunk_entities = []
            existing_new_count = db.query(DocumentChunk).filter(DocumentChunk.document_id == new_doc.id).count()
            if existing_new_count == 0:
                for c in new_chunks:
                    chunk_ent = DocumentChunk(
                        document_id=new_doc.id,
                        chunk_index=c.chunk_index,
                        page_number=c.page_number,
                        section_heading=c.section_heading,
                        content=c.content,
                        token_count=c.token_count,
                        metadata_json=c.metadata
                    )
                    db.add(chunk_ent)
                    new_chunk_entities.append(chunk_ent)
                db.commit()
                for e in new_chunk_entities:
                    db.refresh(e)
            else:
                new_chunk_entities = db.query(DocumentChunk).filter(
                    DocumentChunk.document_id == new_doc.id
                ).order_by(DocumentChunk.chunk_index).all()

            old_doc.chunk_count = len(old_chunk_entities)
            new_doc.chunk_count = len(new_chunk_entities)
            db.commit()

            # Stage 4: Sentence-BERT Embeddings
            cls._update_progress(db, analysis, stage=4, percent=55, status="embedding")
            old_dicts = [
                {"id": c.id, "content": c.content, "section": c.section_heading, "page": c.page_number}
                for c in old_chunk_entities
            ]
            new_dicts = [
                {"id": c.id, "content": c.content, "section": c.section_heading, "page": c.page_number}
                for c in new_chunk_entities
            ]

            # Stage 5: Cosine Similarity Matching
            cls._update_progress(db, analysis, stage=5, percent=65, status="retrieving")
            matched_pairs_raw, unmatched_old, unmatched_new = EmbeddingMatcher.match_chunks(
                old_dicts, new_dicts, similarity_threshold=0.35, top_k=2
            )

            # Stage 6: DeBERTa-v3 NLI Screening
            cls._update_progress(db, analysis, stage=6, percent=75, status="nli_evaluating")
            evaluated_pairs = []
            for pair in matched_pairs_raw:
                old_text = pair["old_chunk"]["content"]
                new_text = pair["new_chunk"]["content"]
                nli_result = DeBERTaNLIClassifier.predict(premise=old_text, hypothesis=new_text)

                matched_pair_ent = MatchedPair(
                    analysis_id=analysis.id,
                    old_chunk_id=pair["old_chunk"]["id"],
                    new_chunk_id=pair["new_chunk"]["id"],
                    similarity_score=pair["similarity_score"],
                    nli_label=nli_result.label,
                    nli_confidence=nli_result.confidence
                )
                db.add(matched_pair_ent)
                evaluated_pairs.append((matched_pair_ent, pair, nli_result))

            db.commit()
            for mp, _, _ in evaluated_pairs:
                db.refresh(mp)

            # Stage 7: LLM Verification (Llama 3.1 8B Instruct)
            cls._update_progress(db, analysis, stage=7, percent=85, status="llm_verifying")
            
            # Check Ollama health to determine model attribution
            health = OllamaClient.check_health()
            ollama_ready = bool(health.get("ollama_running") and health.get("model_installed"))
            if ollama_ready:
                analysis.model_used = f"Llama 3.1 8B Instruct (Local Ollama)"
            else:
                analysis.model_used = f"Hybrid DeBERTa-NLI + Semantic Rule Engine (Local Offline)"

            db_issues: list[DetectedIssue] = []
            issue_seq = 1

            for mp_ent, pair, nli_res in evaluated_pairs:
                old_text = pair["old_chunk"]["content"]
                new_text = pair["new_chunk"]["content"]
                old_sec = pair["old_chunk"]["section"]
                new_sec = pair["new_chunk"]["section"]

                llm_finding = OllamaClient.verify_pair(
                    old_text=old_text,
                    new_text=new_text,
                    old_section=old_sec,
                    new_section=new_sec,
                    nli_label=nli_res.label,
                    similarity=pair["similarity_score"],
                    ollama_available=ollama_ready
                )

                if llm_finding:
                    issue_ent = DetectedIssue(
                        analysis_id=analysis.id,
                        matched_pair_id=mp_ent.id,
                        issue_code=f"ISS-{issue_seq:03d}",
                        category=llm_finding.category,
                        title=llm_finding.title,
                        severity=llm_finding.severity,
                        confidence=llm_finding.confidence,
                        explanation=llm_finding.explanation,
                        old_evidence=llm_finding.old_evidence,
                        new_evidence=llm_finding.new_evidence,
                        source_section_old=old_sec,
                        source_section_new=new_sec,
                        source_page_old=pair["old_chunk"]["page"],
                        source_page_new=pair["new_chunk"]["page"],
                        suggested_correction=llm_finding.suggested_correction,
                        verification_status="pending"
                    )
                    db.add(issue_ent)
                    db_issues.append(issue_ent)
                    issue_seq += 1

            # Detect Missing Content for prominent unmatched old sections
            for uo in unmatched_old[:3]:  # Top 3 salient unmatched sections
                sec_name = uo.get("section", "Section")
                issue_ent = DetectedIssue(
                    analysis_id=analysis.id,
                    matched_pair_id=None,
                    issue_code=f"ISS-{issue_seq:03d}",
                    category="Missing Content",
                    title=f"Omitted Specification: {sec_name}",
                    severity="Medium",
                    confidence=0.88,
                    explanation=f"The section '{sec_name}' was present in the old documentation but has no corresponding section or coverage in the new document.",
                    old_evidence=uo["content"][:200],
                    new_evidence="[No matching section found in updated documentation]",
                    source_section_old=sec_name,
                    source_section_new=None,
                    source_page_old=uo.get("page"),
                    source_page_new=None,
                    suggested_correction=f"Verify whether the '{sec_name}' features were intentionally deprecated or inadvertently omitted during document revision.",
                    verification_status="pending"
                )
                db.add(issue_ent)
                db_issues.append(issue_ent)
                issue_seq += 1

            db.commit()
            for issue_ent in db_issues:
                db.refresh(issue_ent)

            # Stage 8: Score calculation & Report preparation
            cls._update_progress(db, analysis, stage=8, percent=95, status="scoring")
            
            issues_dict_list = [
                {
                    "category": iss.category,
                    "severity": iss.severity,
                    "confidence": iss.confidence,
                    "explanation": iss.explanation,
                    "old_evidence": iss.old_evidence,
                    "new_evidence": iss.new_evidence,
                    "title": iss.title,
                    "issue_code": iss.issue_code,
                    "verification_status": iss.verification_status,
                    "suggested_correction": iss.suggested_correction
                }
                for iss in db_issues
            ]

            score_res = ConsistencyScorer.calculate_score(
                issues=issues_dict_list,
                total_matched_pairs=max(len(evaluated_pairs), 1)
            )

            duration = round(time.time() - start_time, 2)
            analysis.consistency_score = score_res.score
            analysis.status_label = score_res.status_label
            analysis.matched_pairs_count = len(evaluated_pairs)
            analysis.confirmed_issues_count = score_res.total_issues
            analysis.review_required_count = score_res.review_required_count
            analysis.duration_seconds = duration
            analysis.status = "completed"
            analysis.progress_stage = 8
            analysis.progress_percent = 100
            analysis.completed_at = datetime.now(timezone.utc)
            db.commit()

            # Pre-generate PDF report
            try:
                report_meta = {
                    "id": analysis.id,
                    "title": analysis.title,
                    "old_doc_name": old_doc.filename,
                    "new_doc_name": new_doc.filename,
                    "consistency_score": score_res.score,
                    "status_label": score_res.status_label,
                    "matched_pairs_count": len(evaluated_pairs),
                    "confirmed_issues_count": score_res.total_issues,
                    "review_required_count": score_res.review_required_count,
                    "category_counts": score_res.category_counts,
                    "severity_counts": score_res.severity_counts,
                    "model_used": analysis.model_used
                }
                generate_pdf_report(report_meta, issues_dict_list)
            except Exception as e:
                print(f"[Warning] Failed to generate preliminary PDF report: {e}")

        except Exception as e:
            db.rollback()
            analysis.status = "failed"
            analysis.error_message = str(e)
            analysis.progress_percent = 0
            db.commit()
            print(f"[Error] Analysis {analysis_id} failed: {e}")

    @staticmethod
    def _update_progress(db: Session, analysis: Analysis, stage: int, percent: int, status: str):
        analysis.progress_stage = stage
        analysis.progress_percent = percent
        analysis.status = status
        db.commit()
