import os
from pathlib import Path
import docx
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from app.core.config import settings

def generate_sample_documents() -> tuple[Path, Path]:
    """
    Generates two sample technical documents (v1.0 Baseline vs v2.0 Updated)
    demonstrating Consistent sections, Contradictions, Outdated info,
    Missing content, and Terminology inconsistencies.
    """
    v1_docx = settings.UPLOADS_DIR / "sample_cloud_api_v1_baseline.docx"
    v2_docx = settings.UPLOADS_DIR / "sample_cloud_api_v2_updated.docx"

    # Generate v1.0 DOCX
    doc1 = docx.Document()
    doc1.add_heading("Cloud Core API Specification - Version 1.0 (Baseline)", level=0)
    
    doc1.add_heading("1. System Overview", level=1)
    doc1.add_paragraph(
        "The Cloud Core API platform provides microservice orchestration and high-availability workload "
        "management across distributed data centers. All requests communicate over encrypted TLS 1.3 channels."
    )
    
    doc1.add_heading("2. Network & Ingress Ports", level=1)
    doc1.add_paragraph(
        "The primary API gateway ingress listener operates on port 8080. Internal metrics telemetry "
        "is collected through Prometheus exporter listening on port 9090."
    )
    
    doc1.add_heading("3. Authentication & Credential Management", level=1)
    doc1.add_paragraph(
        "Developers must supply an 'api_key' in the X-API-Key HTTP header for all privileged operations. "
        "User sessions expire after 3600 seconds of inactivity."
    )
    
    doc1.add_heading("4. Deployment & Migration Scripts", level=1)
    doc1.add_paragraph(
        "To upgrade schema versions, run the standalone migration command: python upgrade_v1.py --force. "
        "Ensure database connection string uses SSL mode 'require'."
    )
    
    doc1.add_heading("5. High Availability Clustering", level=1)
    doc1.add_paragraph(
        "High availability requires configuring at least 3 active voting cluster nodes to ensure "
        "quorum consensus in case of partitioned network events."
    )

    doc1.add_heading("6. Legacy Diagnostics Engine", level=1)
    doc1.add_paragraph(
        "Run the legacy diagnostics utility via /debug/sysinfo to inspect memory fragmentation and thread pool saturation. "
        "This tool outputs raw kernel buffer metrics for debugging."
    )

    doc1.save(str(v1_docx))

    # Generate v2.0 DOCX
    doc2 = docx.Document()
    doc2.add_heading("Cloud Core API Specification - Version 2.0 (Updated)", level=0)
    
    doc2.add_heading("1. System Overview", level=1)
    doc2.add_paragraph(
        "The Cloud Core API platform provides microservice orchestration and high-availability workload "
        "management across distributed data centers. All requests communicate over encrypted TLS 1.3 channels."
    )
    
    doc2.add_heading("2. Network & Ingress Ports", level=1)
    # CONTRADICTION: Port 8080 -> Port 9090, Metrics 9090 -> 9100
    doc2.add_paragraph(
        "The primary API gateway ingress listener operates on port 9090. Internal metrics telemetry "
        "is collected through Prometheus exporter listening on port 9100. Port 8080 is strictly deprecated."
    )
    
    doc2.add_heading("3. Authentication & Credential Management", level=1)
    # TERMINOLOGY INCONSISTENCY: 'api_key' -> 'auth_token'
    doc2.add_paragraph(
        "Developers must supply an 'auth_token' in the Authorization Bearer header for all privileged operations. "
        "User sessions expire after 3600 seconds of inactivity."
    )
    
    doc2.add_heading("4. Deployment & Migration Scripts", level=1)
    # OUTDATED INFORMATION: upgrade_v1.py deprecated, replaced by cloud-cli migrate
    doc2.add_paragraph(
        "The legacy upgrade_v1.py script is completely deprecated and removed in v2.0. Teams must execute "
        "'cloud-cli migrate' instead. Ensure database connection string uses SSL mode 'require'."
    )
    
    doc2.add_heading("5. High Availability Clustering", level=1)
    # CONSISTENT
    doc2.add_paragraph(
        "High availability requires configuring at least 3 active voting cluster nodes to ensure "
        "quorum consensus in case of partitioned network events."
    )
    
    # Note: Section 6 "Legacy Diagnostics Engine" is omitted in v2 (MISSING CONTENT)

    doc2.save(str(v2_docx))

    return v1_docx, v2_docx
