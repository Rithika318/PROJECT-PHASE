import csv
import io
from typing import Any

def export_issues_to_csv(issues: list[dict[str, Any]]) -> str:
    """
    Exports a list of detected issues into a CSV formatted string.
    """
    output = io.StringIO()
    writer = csv.writer(output)
    
    # Header
    writer.writerow([
        "Issue ID",
        "Category",
        "Severity",
        "Confidence",
        "Title",
        "Explanation",
        "Old Document Evidence",
        "New Document Evidence",
        "Source Section (Old)",
        "Source Section (New)",
        "Source Page (Old)",
        "Source Page (New)",
        "Recommended Correction",
        "Verification Status",
        "Reviewer Notes"
    ])
    
    for issue in issues:
        writer.writerow([
            issue.get("issue_code", ""),
            issue.get("category", ""),
            issue.get("severity", ""),
            f"{float(issue.get('confidence', 0.0)):.2f}",
            issue.get("title", ""),
            issue.get("explanation", ""),
            issue.get("old_evidence", ""),
            issue.get("new_evidence", ""),
            issue.get("source_section_old", ""),
            issue.get("source_section_new", ""),
            issue.get("source_page_old", ""),
            issue.get("source_page_new", ""),
            issue.get("suggested_correction", ""),
            issue.get("verification_status", "pending"),
            issue.get("reviewer_notes", "")
        ])
        
    return output.getvalue()
