from typing import NamedTuple, Optional
from app.document_processing.extractor import ExtractedSection

class ProcessedChunk(NamedTuple):
    chunk_index: int
    content: str
    section_heading: str
    page_number: Optional[int]
    token_count: int
    metadata: dict

class DocumentChunker:
    """
    Splits extracted sections into semantically cohesive chunks while preserving
    section headings, page references, and code/table blocks.
    """

    @staticmethod
    def chunk_sections(
        sections: list[ExtractedSection],
        max_words_per_chunk: int = 150,
        min_words_per_chunk: int = 25
    ) -> list[ProcessedChunk]:
        chunks: list[ProcessedChunk] = []
        chunk_idx = 0
        
        current_heading = "General"
        current_page = None
        current_buffer: list[str] = []
        current_word_count = 0

        for section in sections:
            # If heading changes or section is large, flush buffer
            heading_changed = section.heading != current_heading and len(current_buffer) > 0
            
            section_words = section.content.split()
            section_len = len(section_words)
            
            if heading_changed or (current_word_count + section_len > max_words_per_chunk and current_word_count >= min_words_per_chunk):
                # Flush existing buffer as a chunk
                chunk_text = "\n\n".join(current_buffer)
                chunks.append(ProcessedChunk(
                    chunk_index=chunk_idx,
                    content=chunk_text,
                    section_heading=current_heading,
                    page_number=current_page,
                    token_count=len(chunk_text.split()),
                    metadata={"section": current_heading, "page": current_page}
                ))
                chunk_idx += 1
                current_buffer = []
                current_word_count = 0
                
            current_heading = section.heading
            current_page = section.page_number
            
            # If single section is itself larger than max_words_per_chunk, chunk it by sentences
            if section_len > max_words_per_chunk:
                # Simple sentence split
                sentences = [s.strip() for s in section.content.replace('\n', ' ').split('. ') if s.strip()]
                sub_buffer = []
                sub_words = 0
                for sent in sentences:
                    s_words = len(sent.split())
                    if sub_words + s_words > max_words_per_chunk and sub_words >= min_words_per_chunk:
                        sub_text = ". ".join(sub_buffer) + "."
                        chunks.append(ProcessedChunk(
                            chunk_index=chunk_idx,
                            content=sub_text,
                            section_heading=current_heading,
                            page_number=current_page,
                            token_count=len(sub_text.split()),
                            metadata={"section": current_heading, "page": current_page}
                        ))
                        chunk_idx += 1
                        sub_buffer = []
                        sub_words = 0
                    sub_buffer.append(sent)
                    sub_words += s_words
                
                if sub_buffer:
                    sub_text = ". ".join(sub_buffer)
                    if not sub_text.endswith('.'):
                        sub_text += "."
                    chunks.append(ProcessedChunk(
                        chunk_index=chunk_idx,
                        content=sub_text,
                        section_heading=current_heading,
                        page_number=current_page,
                        token_count=len(sub_text.split()),
                        metadata={"section": current_heading, "page": current_page}
                    ))
                    chunk_idx += 1
            else:
                current_buffer.append(section.content)
                current_word_count += section_len

        # Flush any remaining buffer
        if current_buffer:
            chunk_text = "\n\n".join(current_buffer)
            chunks.append(ProcessedChunk(
                chunk_index=chunk_idx,
                content=chunk_text,
                section_heading=current_heading,
                page_number=current_page,
                token_count=len(chunk_text.split()),
                metadata={"section": current_heading, "page": current_page}
            ))
            chunk_idx += 1

        return chunks
