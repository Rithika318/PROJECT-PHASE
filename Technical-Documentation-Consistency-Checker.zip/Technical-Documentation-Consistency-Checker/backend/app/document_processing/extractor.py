import os
import re
from pathlib import Path
from typing import NamedTuple, Optional

try:
    import pymupdf  # PyMuPDF
except ImportError:
    import fitz as pymupdf

import docx

class ExtractedSection(NamedTuple):
    heading: str
    content: str
    page_number: Optional[int]
    is_code: bool = False

class ExtractionResult(NamedTuple):
    sections: list[ExtractedSection]
    word_count: int
    is_scanned_ocr_needed: bool
    is_empty: bool
    file_type: str

class DocumentExtractor:
    """
    Extracts text, preserves headings, page numbers, technical parameters,
    and detects scanned/OCR-required documents for PDF and DOCX formats.
    """

    @staticmethod
    def clean_text(text: str) -> str:
        if not text:
            return ""
        # Remove null bytes and non-printable control chars except newlines and tabs
        text = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]', '', text)
        # Normalize multiple spaces but preserve single newlines
        lines = [line.strip() for line in text.splitlines()]
        # Filter out repetitive whitespace lines
        cleaned_lines = []
        for line in lines:
            if line:
                cleaned_lines.append(line)
        return "\n".join(cleaned_lines)

    @classmethod
    def extract_pdf(cls, file_path: str | Path) -> ExtractionResult:
        sections: list[ExtractedSection] = []
        total_text = ""
        current_heading = "General"
        is_scanned = False
        
        doc = pymupdf.open(str(file_path))
        num_pages = len(doc)
        
        if num_pages == 0:
            doc.close()
            return ExtractionResult(sections=[], word_count=0, is_scanned_ocr_needed=False, is_empty=True, file_type="pdf")

        total_extracted_chars = 0
        has_images = False

        for page_idx in range(num_pages):
            page = doc[page_idx]
            page_num = page_idx + 1
            
            # Check for images on page
            if len(page.get_images()) > 0:
                has_images = True
                
            # Extract structured text blocks
            blocks = page.get_text("blocks")  # (x0, y0, x1, y1, text, block_no, block_type)
            page_content = []

            for b in blocks:
                # b[4] is the text content, b[6] is block_type (0 = text, 1 = image)
                if len(b) > 4 and b[6] == 0:
                    raw_block_text = b[4].strip()
                    if not raw_block_text:
                        continue
                        
                    cleaned_block = cls.clean_text(raw_block_text)
                    total_extracted_chars += len(cleaned_block)
                    
                    # Detect heading heuristics: short line, ends without period, or all caps / title case
                    lines = cleaned_block.splitlines()
                    first_line = lines[0].strip()
                    
                    is_heading_candidate = (
                        len(first_line) < 80 and
                        (first_line.isupper() or
                         re.match(r'^(?:#+|\d+(\.\d+)*|[A-Z][a-zA-Z0-9\s:_-]{2,50})$', first_line)) and
                        not first_line.endswith('.')
                    )
                    
                    if is_heading_candidate and len(lines) == 1:
                        current_heading = first_line
                    else:
                        is_code_block = bool(re.search(r'[{}\[\];=><_()]|curl |POST |GET |DELETE |https?://', cleaned_block))
                        sections.append(ExtractedSection(
                            heading=current_heading,
                            content=cleaned_block,
                            page_number=page_num,
                            is_code=is_code_block
                        ))
                        page_content.append(cleaned_block)

            total_text += "\n" + "\n".join(page_content)

        doc.close()
        
        words = total_text.split()
        word_count = len(words)
        
        # Detect if document is scanned: has pages/images but virtually no extractable text
        if word_count < 15 and has_images and num_pages > 0:
            is_scanned = True

        is_empty = word_count == 0

        return ExtractionResult(
            sections=sections,
            word_count=word_count,
            is_scanned_ocr_needed=is_scanned,
            is_empty=is_empty,
            file_type="pdf"
        )

    @classmethod
    def extract_docx(cls, file_path: str | Path) -> ExtractionResult:
        doc = docx.Document(str(file_path))
        sections: list[ExtractedSection] = []
        current_heading = "General"
        total_text = ""

        for para in doc.paragraphs:
            text = cls.clean_text(para.text)
            if not text:
                continue
                
            style_name = para.style.name.lower() if para.style else ""
            if "heading" in style_name or "title" in style_name:
                current_heading = text
                continue
                
            is_code = "code" in style_name or "quote" in style_name or bool(re.search(r'[{}\[\];=><_()]|curl |POST |GET ', text))
            sections.append(ExtractedSection(
                heading=current_heading,
                content=text,
                page_number=None,
                is_code=is_code
            ))
            total_text += " " + text

        # Also extract text from tables
        for table in doc.tables:
            table_rows = []
            for row in table.rows:
                row_cells = [cls.clean_text(cell.text) for cell in row.cells if cell.text.strip()]
                if row_cells:
                    table_rows.append(" | ".join(row_cells))
            if table_rows:
                table_content = "\n".join(table_rows)
                sections.append(ExtractedSection(
                    heading=f"{current_heading} (Table)",
                    content=table_content,
                    page_number=None,
                    is_code=True
                ))
                total_text += " " + table_content

        words = total_text.split()
        word_count = len(words)
        is_empty = word_count == 0

        return ExtractionResult(
            sections=sections,
            word_count=word_count,
            is_scanned_ocr_needed=False,
            is_empty=is_empty,
            file_type="docx"
        )

    @classmethod
    def extract_txt(cls, file_path: str | Path) -> ExtractionResult:
        sections: list[ExtractedSection] = []
        current_heading = "General"
        
        try:
            with open(str(file_path), "r", encoding="utf-8") as f:
                content = f.read()
        except UnicodeDecodeError:
            with open(str(file_path), "r", encoding="latin-1", errors="replace") as f:
                content = f.read()

        cleaned_text = cls.clean_text(content)
        lines = cleaned_text.splitlines()
        current_buffer: list[str] = []

        for line in lines:
            line_str = line.strip()
            if not line_str:
                continue

            # Heading candidate detection: markdown style '#' or short upper/title case line
            is_heading_candidate = (
                (line_str.startswith("#") and len(line_str.lstrip("#").strip()) > 0) or
                (len(line_str) < 70 and
                 (line_str.isupper() or re.match(r'^(?:\d+(\.\d+)*|[A-Z][a-zA-Z0-9\s:_-]{2,50})$', line_str)) and
                 not line_str.endswith('.'))
            )

            if is_heading_candidate:
                if current_buffer:
                    block_text = "\n".join(current_buffer)
                    is_code = bool(re.search(r'[{}\[\];=><_()]|curl |POST |GET |DELETE |https?://', block_text))
                    sections.append(ExtractedSection(
                        heading=current_heading,
                        content=block_text,
                        page_number=1,
                        is_code=is_code
                    ))
                    current_buffer = []
                current_heading = line_str.lstrip("#").strip()
            else:
                current_buffer.append(line_str)

        if current_buffer:
            block_text = "\n".join(current_buffer)
            is_code = bool(re.search(r'[{}\[\];=><_()]|curl |POST |GET |DELETE |https?://', block_text))
            sections.append(ExtractedSection(
                heading=current_heading,
                content=block_text,
                page_number=1,
                is_code=is_code
            ))

        words = cleaned_text.split()
        word_count = len(words)
        is_empty = word_count == 0

        return ExtractionResult(
            sections=sections,
            word_count=word_count,
            is_scanned_ocr_needed=False,
            is_empty=is_empty,
            file_type="txt"
        )

    @classmethod
    def extract(cls, file_path: str | Path) -> ExtractionResult:
        ext = os.path.splitext(str(file_path))[1].lower()
        if ext == ".pdf":
            return cls.extract_pdf(file_path)
        elif ext == ".docx":
            return cls.extract_docx(file_path)
        elif ext == ".txt":
            return cls.extract_txt(file_path)
        else:
            raise ValueError(f"Unsupported file format '{ext}'. Only .pdf, .docx, and .txt are supported.")
