import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.core.config import settings
from app.database.session import engine, Base, SessionLocal
from app.api.api import api_router
from app.models.entities import User, UserSettings
from app.core.security import get_password_hash
from app.services.sample_docs_generator import generate_sample_documents

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger("app.main")

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: initialize database tables
    logger.info("Initializing database schema...")
    Base.metadata.create_all(bind=engine)

    # Seed default developer account for quick evaluation
    db = SessionLocal()
    try:
        admin = db.query(User).filter(User.email == "demo@btech.edu").first()
        if not admin:
            logger.info("Seeding demo account: demo@btech.edu / DemoPass123!")
            hashed_pwd = get_password_hash("DemoPass123!")
            user = User(
                email="demo@btech.edu",
                full_name="Final-Year Project Evaluator",
                hashed_password=hashed_pwd,
                role="lead_architect"
            )
            db.add(user)
            db.commit()
            db.refresh(user)

            user_settings = UserSettings(user_id=user.id)
            db.add(user_settings)
            db.commit()

        # Ensure sample docs exist
        generate_sample_documents()
    finally:
        db.close()

    yield
    # Shutdown logic if any
    logger.info("Application shutting down.")

app = FastAPI(
    title=settings.PROJECT_NAME,
    description="Full-stack AI consistency and contradiction checking platform for technical documentation.",
    version="1.0.0",
    lifespan=lifespan
)

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # For local development across any Vite/React port
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register API routes
app.include_router(api_router)

@app.get("/")
def root():
    return {
        "project": settings.PROJECT_NAME,
        "status": "online",
        "documentation": "/docs",
        "api_v1": "/api"
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host="127.0.0.1", port=8000, reload=True)
