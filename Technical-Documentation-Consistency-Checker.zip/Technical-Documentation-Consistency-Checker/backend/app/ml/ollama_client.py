import json
import re
from typing import Any, Optional
import httpx
from pydantic import ValidationError
from app.core.config import settings
from app.schemas.domain import LLMVerificationResponse, LLMIssueItem

VALID_CATEGORIES = [
    "Consistent",
    "Contradiction",
    "Outdated Information",
    "Missing Content",
    "Terminology Inconsistency"
]

VALID_SEVERITIES = [
    "Critical",
    "High",
    "Medium",
    "Low",
    "Informational"
]

class OllamaClient:
    """
    Manages local inference with Llama 3.1 8B Instruct via Ollama at localhost:11434.
    Includes health checks, structured JSON generation, Pydantic validation, and transparent fallbacks.
    """

    @classmethod
    def check_health(cls) -> dict[str, Any]:
        """
        Queries Ollama service directly to verify connection and model presence.
        """
        try:
            with httpx.Client(timeout=1.5) as client:
                res = client.get(f"{settings.OLLAMA_BASE_URL}/api/tags")
                if res.status_code == 200:
                    data = res.json()
                    models = [m.get("name", "") for m in data.get("models", [])]
                    target_model = settings.OLLAMA_MODEL
                    # Check if target model or variant (e.g. llama3.1:8b or llama3.1:latest) exists
                    has_model = any(target_model in m or "llama3.1" in m for m in models)
                    
                    return {
                        "ollama_running": True,
                        "model_installed": has_model,
                        "installed_models": models,
                        "target_model": target_model,
                        "error": None
                    }
                else:
                    return {
                        "ollama_running": True,
                        "model_installed": False,
                        "installed_models": [],
                        "target_model": settings.OLLAMA_MODEL,
                        "error": f"Ollama returned HTTP status {res.status_code}"
                    }
        except Exception as e:
            return {
                "ollama_running": False,
                "model_installed": False,
                "installed_models": [],
                "target_model": settings.OLLAMA_MODEL,
                "error": str(e)
            }

    @classmethod
    def verify_pair(
        cls,
        old_text: str,
        new_text: str,
        old_section: str,
        new_section: str,
        nli_label: str,
        similarity: float,
        model_name: Optional[str] = None,
        ollama_available: bool = True
    ) -> Optional[LLMIssueItem]:
        """
        Sends candidate text pair to Llama 3.1 8B Instruct for verification, categorization,
        severity estimation, and correction recommendation with strict JSON output.
        """
        if not ollama_available:
            return cls._local_analytical_verifier(old_text, new_text, old_section, new_section, nli_label, similarity)

        model = model_name or settings.OLLAMA_MODEL

        prompt = f"""You are a senior technical documentation auditor. Analyze the following comparison between an OLD version and a NEW version of a technical document.

Context:
- Old Section: {old_section}
- New Section: {new_section}
- Semantic Similarity: {similarity}
- Preliminary NLI Classifier Hint: {nli_label}

OLD DOCUMENT TEXT:
\"\"\"{old_text}\"\"\"

NEW DOCUMENT TEXT:
\"\"\"{new_text}\"\"\"

TASK:
1. Determine if there is an inconsistency between the two texts.
2. Select EXACTLY ONE category from this list:
   - Consistent (both texts agree in meaning)
   - Contradiction (mutually incompatible instructions, parameters, or specifications)
   - Outdated Information (old statement is superseded, invalid, or replaced in new version)
   - Missing Content (important parameter or section present in one but omitted in another)
   - Terminology Inconsistency (different terms used for the same concept/API without synonymy)
3. Assign severity: Critical, High, Medium, Low, or Informational.
4. Provide verbatim evidence from the texts.
5. Suggest a recommended correction.

Return ONLY a valid JSON object matching this schema, with no markdown code fences or conversational text:
{{
  "is_inconsistency": true,
  "category": "Contradiction",
  "title": "Short title describing the issue",
  "severity": "High",
  "confidence": 0.90,
  "explanation": "Clear explanation grounded strictly in the provided text.",
  "old_evidence": "Verbatim quote from old text",
  "new_evidence": "Verbatim quote from new text",
  "suggested_correction": "Specific recommendation to align documentation."
}}
"""

        try:
            timeout_cfg = httpx.Timeout(timeout=float(settings.OLLAMA_TIMEOUT), connect=1.5)
            with httpx.Client(timeout=timeout_cfg) as client:
                response = client.post(
                    f"{settings.OLLAMA_BASE_URL}/api/generate",
                    json={
                        "model": model,
                        "prompt": prompt,
                        "stream": False,
                        "format": "json",
                        "options": {
                            "temperature": 0.1,
                            "top_p": 0.9
                        }
                    }
                )
                if response.status_code == 200:
                    raw_response = response.json().get("response", "")
                    return cls._parse_and_validate_llm_json(raw_response, old_text, new_text)
        except Exception as e:
            print(f"[Warning] Ollama call failed ({e}). Using local analytical verifier.")

        # Fallback to local analytical verifier if Ollama is not running or timed out
        return cls._local_analytical_verifier(old_text, new_text, old_section, new_section, nli_label, similarity)

    @classmethod
    def _parse_and_validate_llm_json(cls, raw_json_str: str, old_text: str, new_text: str) -> Optional[LLMIssueItem]:
        try:
            # Clean possible markdown fences
            clean_str = re.sub(r'^```json\s*', '', raw_json_str.strip())
            clean_str = re.sub(r'```$', '', clean_str.strip())
            
            data = json.loads(clean_str)
            
            # Enforce valid category
            cat = data.get("category", "Consistent")
            if cat not in VALID_CATEGORIES:
                # Map close variations
                for vc in VALID_CATEGORIES:
                    if vc.lower() in cat.lower():
                        cat = vc
                        break
                else:
                    cat = "Consistent"
            data["category"] = cat

            # Enforce valid severity
            sev = data.get("severity", "Medium")
            if sev not in VALID_SEVERITIES:
                sev = "Medium"
            data["severity"] = sev

            # Ensure evidence strings are not empty
            if not data.get("old_evidence"):
                data["old_evidence"] = old_text[:120]
            if not data.get("new_evidence"):
                data["new_evidence"] = new_text[:120]

            item = LLMIssueItem(**data)
            return item
        except (json.JSONDecodeError, ValidationError) as e:
            print(f"[Warning] Failed to validate LLM JSON output: {e}. Raw: {raw_json_str[:150]}")
            return None

    @classmethod
    def _local_analytical_verifier(
        cls,
        old_text: str,
        new_text: str,
        old_section: str,
        new_section: str,
        nli_label: str,
        similarity: float
    ) -> LLMIssueItem:
        """
        Deterministic, local rule-and-NLI verified analysis when Ollama is offline.
        Strictly categorizes issues according to the 5 required categories.
        """
        old_lower = old_text.lower()
        new_lower = new_text.lower()

        # 1. Contradiction: conflicting ports, endpoints, limits, or parameters
        port_pattern = r'\bport\s*[:=]?\s*(\d+)\b'
        old_ports = re.findall(port_pattern, old_lower)
        new_ports = re.findall(port_pattern, new_lower)

        if old_ports and new_ports and old_ports != new_ports:
            return LLMIssueItem(
                is_inconsistency=True,
                category="Contradiction",
                title=f"Conflicting Port Specification in {new_section}",
                severity="Critical",
                confidence=0.95,
                explanation=f"Old documentation specifies port {old_ports[0]}, while new documentation specifies port {new_ports[0]}.",
                old_evidence=old_text[:150],
                new_evidence=new_text[:150],
                suggested_correction=f"Standardize network port configuration across both guides to port {new_ports[0]}."
            )

        # Contradictory Boolean or numerical settings
        timeout_old = re.findall(r'(\d+)\s*(?:s|sec|seconds|ms)', old_lower)
        timeout_new = re.findall(r'(\d+)\s*(?:s|sec|seconds|ms)', new_lower)
        if ("timeout" in old_lower or "limit" in old_lower) and timeout_old and timeout_new and timeout_old != timeout_new:
            return LLMIssueItem(
                is_inconsistency=True,
                category="Contradiction",
                title=f"Configuration Limit Discrepancy in {new_section}",
                severity="High",
                confidence=0.92,
                explanation=f"Timeout/limit value changed from {timeout_old[0]} to {timeout_new[0]} without backward compatibility note.",
                old_evidence=old_text[:150],
                new_evidence=new_text[:150],
                suggested_correction="Update configuration instructions to document the new threshold and explain migration impact."
            )

        # 2. Outdated Information: deprecated or superseded syntax
        outdated_markers = ["deprecated", "obsolete", "v1", "v2", "superseded", "legacy", "no longer supported"]
        if any(m in new_lower for m in outdated_markers) or nli_label == "contradiction":
            return LLMIssueItem(
                is_inconsistency=True,
                category="Outdated Information",
                title=f"Outdated Specification in {old_section}",
                severity="High",
                confidence=0.88,
                explanation="The older documentation provides instructions or parameters that are flagged as deprecated or updated in the newer release.",
                old_evidence=old_text[:150],
                new_evidence=new_text[:150],
                suggested_correction="Mark the older section as deprecated and redirect developers to the updated standard."
            )

        # 3. Terminology Inconsistency
        # E.g. token vs api_key, user_id vs account_id, master vs main
        term_pairs = [
            ("api_key", "auth_token"),
            ("api_token", "bearer_token"),
            ("master", "main"),
            ("whitelist", "allowlist"),
            ("blacklist", "blocklist"),
            ("user_id", "account_id"),
            ("secret_key", "client_secret")
        ]
        for t1, t2 in term_pairs:
            if (t1 in old_lower and t2 in new_lower) or (t2 in old_lower and t1 in new_lower):
                return LLMIssueItem(
                    is_inconsistency=True,
                    category="Terminology Inconsistency",
                    title=f"Inconsistent Terminology: '{t1}' vs '{t2}'",
                    severity="Medium",
                    confidence=0.89,
                    explanation=f"One document uses '{t1}' while the other refers to the same concept as '{t2}', leading to confusion.",
                    old_evidence=old_text[:150],
                    new_evidence=new_text[:150],
                    suggested_correction=f"Establish a unified technical glossary and standardize on '{t2}' throughout all documentation."
                )

        # 4. Check NLI Contradiction
        if nli_label == "contradiction":
            return LLMIssueItem(
                is_inconsistency=True,
                category="Contradiction",
                title=f"Direct Semantic Conflict in {new_section}",
                severity="High",
                confidence=0.85,
                explanation="DeBERTa-v3 Natural Language Inference detected mutually contradictory propositions between these related sections.",
                old_evidence=old_text[:150],
                new_evidence=new_text[:150],
                suggested_correction="Reconcile the contradictory specifications with the core engineering release notes."
            )

        # 5. Consistent
        return LLMIssueItem(
            is_inconsistency=False,
            category="Consistent",
            title=f"Consistent Documentation for {new_section}",
            severity="Informational",
            confidence=round(max(0.70, similarity), 2),
            explanation="Both document versions express consistent technical meaning with no conflicting requirements or parameters.",
            old_evidence=old_text[:150],
            new_evidence=new_text[:150],
            suggested_correction="No action required. Documentation aligns accurately."
        )
