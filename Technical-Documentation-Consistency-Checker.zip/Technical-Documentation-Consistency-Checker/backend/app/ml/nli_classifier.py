import re
from typing import NamedTuple
import torch

class NLIPrediction(NamedTuple):
    label: str  # 'entailment', 'contradiction', 'neutral'
    confidence: float
    scores: dict[str, float]

_NLI_TOKENIZER = None
_NLI_MODEL = None

def get_nli_components():
    global _NLI_TOKENIZER, _NLI_MODEL
    if _NLI_TOKENIZER is None or _NLI_MODEL is None:
        try:
            from transformers import AutoTokenizer, AutoModelForSequenceClassification
            model_name = "cross-encoder/nli-deberta-v3-small"
            try:
                _NLI_TOKENIZER = AutoTokenizer.from_pretrained(model_name, local_files_only=True)
                _NLI_MODEL = AutoModelForSequenceClassification.from_pretrained(model_name, local_files_only=True)
            except Exception:
                _NLI_TOKENIZER = AutoTokenizer.from_pretrained(model_name)
                _NLI_MODEL = AutoModelForSequenceClassification.from_pretrained(model_name)
            _NLI_MODEL.eval()
        except Exception as e:
            print(f"[Info] DeBERTa-v3 components not loaded: {e}")
            _NLI_TOKENIZER = None
            _NLI_MODEL = None
    return _NLI_TOKENIZER, _NLI_MODEL

def get_nli_pipeline():
    tok, mod = get_nli_components()
    return mod

class DeBERTaNLIClassifier:
    """
    Evaluates text pairs for Natural Language Inference using DeBERTa-v3:
    Labels:
      0: contradiction
      1: entailment
      2: neutral
    """

    @classmethod
    def predict(cls, premise: str, hypothesis: str) -> NLIPrediction:
        tokenizer, model = get_nli_components()
        if tokenizer is not None and model is not None:
            try:
                inputs = tokenizer(premise, hypothesis, return_tensors="pt", truncation=True, max_length=512)
                with torch.no_grad():
                    logits = model(**inputs).logits
                    probs = torch.softmax(logits, dim=-1)[0].tolist()
                
                # Model id2label: {0: 'contradiction', 1: 'entailment', 2: 'neutral'}
                scores = {
                    "contradiction": round(float(probs[0]), 4),
                    "entailment": round(float(probs[1]), 4),
                    "neutral": round(float(probs[2]), 4)
                }
                
                # Pick max label
                top_label = max(scores, key=scores.get)
                confidence = scores[top_label]
                return NLIPrediction(label=top_label, confidence=confidence, scores=scores)
            except Exception as e:
                print(f"[Warning] DeBERTa-v3 inference exception: {e}")

        # Fallback to analytical NLI if model not initialized
        return cls._analytical_nli(premise, hypothesis)

    @classmethod
    def _analytical_nli(cls, premise: str, hypothesis: str) -> NLIPrediction:
        premise_lower = premise.lower()
        hypo_lower = hypothesis.lower()

        # Check for numeric or parameter conflict
        premise_nums = set(re.findall(r'\b\d+(?:\.\d+)?(?:mb|gb|ms|s|port|v\d+)?\b', premise_lower))
        hypo_nums = set(re.findall(r'\b\d+(?:\.\d+)?(?:mb|gb|ms|s|port|v\d+)?\b', hypo_lower))
        
        has_number_conflict = False
        if premise_nums and hypo_nums and premise_nums != hypo_nums:
            for term in ["port", "timeout", "limit", "version", "rate", "max", "min", "memory", "retry"]:
                if term in premise_lower and term in hypo_lower:
                    has_number_conflict = True
                    break

        contradiction_keywords = ["deprecated", "removed", "disabled", "no longer supported", "obsolete", "replaced by", "instead of"]
        has_contradiction_keyword = any(k in hypo_lower for k in contradiction_keywords)

        if has_contradiction_keyword or has_number_conflict:
            return NLIPrediction(
                label="contradiction",
                confidence=0.88,
                scores={"contradiction": 0.88, "neutral": 0.08, "entailment": 0.04}
            )

        # High text overlap -> Entailment
        words1 = set(premise_lower.split())
        words2 = set(hypo_lower.split())
        jaccard = len(words1 & words2) / max(len(words1 | words2), 1)

        if jaccard > 0.6:
            return NLIPrediction(
                label="entailment",
                confidence=round(0.7 + (jaccard * 0.25), 4),
                scores={"entailment": 0.85, "neutral": 0.10, "contradiction": 0.05}
            )
        
        return NLIPrediction(
            label="neutral",
            confidence=0.65,
            scores={"neutral": 0.65, "entailment": 0.20, "contradiction": 0.15}
        )
