from typing import Any
from app.core.config import settings

class ConsistencyScoreResult:
    def __init__(
        self,
        score: float,
        status_label: str,
        total_matched_pairs: int,
        total_issues: int,
        review_required_count: int,
        category_counts: dict[str, int],
        severity_counts: dict[str, int],
        calculation_breakdown: dict[str, Any]
    ):
        self.score = score
        self.status_label = status_label
        self.total_matched_pairs = total_matched_pairs
        self.total_issues = total_issues
        self.review_required_count = review_required_count
        self.category_counts = category_counts
        self.severity_counts = severity_counts
        self.calculation_breakdown = calculation_breakdown

class ConsistencyScorer:
    """
    Transparent, deterministic consistency score calculation.
    
    Formula:
      Weighted Penalty = Sum(SeverityWeight * Confidence) for all non-consistent issues
      Baseline Capacity = Max(Total Matched Pairs * 15.0, 50.0)
      Consistency Score = Max(0.0, Min(100.0, 100.0 - (Weighted Penalty / Baseline Capacity * 100.0)))
    """

    @classmethod
    def calculate_score(
        cls,
        issues: list[dict[str, Any]],
        total_matched_pairs: int,
        custom_weights: dict[str, float] | None = None
    ) -> ConsistencyScoreResult:
        weights = {
            "Critical": settings.SEVERITY_WEIGHT_CRITICAL,
            "High": settings.SEVERITY_WEIGHT_HIGH,
            "Medium": settings.SEVERITY_WEIGHT_MEDIUM,
            "Low": settings.SEVERITY_WEIGHT_LOW,
            "Informational": settings.SEVERITY_WEIGHT_INFORMATIONAL
        }
        if custom_weights:
            weights.update(custom_weights)

        category_counts = {
            "Consistent": 0,
            "Contradiction": 0,
            "Outdated Information": 0,
            "Missing Content": 0,
            "Terminology Inconsistency": 0
        }
        severity_counts = {
            "Critical": 0,
            "High": 0,
            "Medium": 0,
            "Low": 0,
            "Informational": 0
        }

        total_penalty = 0.0
        review_required_count = 0
        non_consistent_issues = 0

        for issue in issues:
            cat = issue.get("category", "Consistent")
            sev = issue.get("severity", "Medium")
            conf = float(issue.get("confidence", 0.8))

            if cat in category_counts:
                category_counts[cat] += 1
            else:
                category_counts[cat] = 1

            if sev in severity_counts:
                severity_counts[sev] += 1
            else:
                severity_counts[sev] = 1

            # Only penalize genuine inconsistencies, not Consistent statements
            if cat != "Consistent":
                non_consistent_issues += 1
                weight = weights.get(sev, 8.0)
                penalty = weight * conf
                total_penalty += penalty

                if conf < 0.75 or sev in ["Critical", "High"]:
                    review_required_count += 1

        # Base capacity scales with the size/depth of documentation matched
        base_capacity = max(total_matched_pairs * 15.0, 50.0)
        
        # Calculate raw percentage deduction
        penalty_ratio = total_penalty / base_capacity
        raw_score = 100.0 - (penalty_ratio * 100.0)
        final_score = round(max(0.0, min(100.0, raw_score)), 1)

        # Assign status label
        if final_score >= 90.0:
            status_label = "Excellent consistency"
        elif final_score >= 75.0:
            status_label = "Good consistency"
        elif final_score >= 55.0:
            status_label = "Needs review"
        else:
            status_label = "Significant inconsistencies"

        breakdown = {
            "formula": "100.0 - (Total Weighted Penalty / Baseline Capacity * 100.0)",
            "total_penalty": round(total_penalty, 2),
            "base_capacity": round(base_capacity, 2),
            "penalty_ratio": round(penalty_ratio, 4),
            "severity_weights_applied": weights,
            "non_consistent_issues": non_consistent_issues
        }

        return ConsistencyScoreResult(
            score=final_score,
            status_label=status_label,
            total_matched_pairs=total_matched_pairs,
            total_issues=non_consistent_issues,
            review_required_count=review_required_count,
            category_counts=category_counts,
            severity_counts=severity_counts,
            calculation_breakdown=breakdown
        )
