from typing import Any
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity

# Global model cache to avoid re-loading weights on every request
_SBERT_MODEL = None

def get_sbert_model():
    global _SBERT_MODEL
    if _SBERT_MODEL is None:
        try:
            from sentence_transformers import SentenceTransformer
            # Try loading cached local files first for instant offline startup
            try:
                _SBERT_MODEL = SentenceTransformer("all-MiniLM-L6-v2", local_files_only=True)
            except Exception:
                _SBERT_MODEL = SentenceTransformer("all-MiniLM-L6-v2")
        except Exception as e:
            print(f"[Warning] Could not load SentenceTransformer: {e}")
            _SBERT_MODEL = None
    return _SBERT_MODEL

class EmbeddingMatcher:
    """
    Encodes text chunks using Sentence-BERT and computes cosine similarity
    to identify candidate aligned sections across old and new documentation.
    """

    @classmethod
    def encode_chunks(cls, texts: list[str]) -> np.ndarray:
        model = get_sbert_model()
        if model is not None:
            try:
                embeddings = model.encode(texts, convert_to_numpy=True, show_progress_bar=False)
                # L2 normalize
                norms = np.linalg.norm(embeddings, axis=1, keepdims=True)
                norms[norms == 0] = 1e-10
                return embeddings / norms
            except Exception as e:
                print(f"[Warning] SBERT encode failed: {e}. Falling back to TF-IDF vectorizer.")
        
        # Fallback to TF-IDF if SBERT weights fail to download or memory limit reached
        from sklearn.feature_extraction.text import TfidfVectorizer
        vectorizer = TfidfVectorizer(ngram_range=(1, 2), stop_words='english')
        tfidf_matrix = vectorizer.fit_transform(texts)
        return tfidf_matrix.toarray()

    @classmethod
    def match_chunks(
        cls,
        old_chunks: list[dict[str, Any]],
        new_chunks: list[dict[str, Any]],
        similarity_threshold: float = 0.45,
        top_k: int = 3
    ) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]]]:
        """
        Returns:
            - matched_pairs: list of candidate pairs with similarity >= threshold
            - unmatched_old: old chunks with no match (potential missing/removed content)
            - unmatched_new: new chunks with no match (newly added content)
        """
        if not old_chunks or not new_chunks:
            return [], old_chunks, new_chunks

        old_texts = [c["content"] for c in old_chunks]
        new_texts = [c["content"] for c in new_chunks]

        old_embeddings = cls.encode_chunks(old_texts)
        new_embeddings = cls.encode_chunks(new_texts)

        # Compute cosine similarity matrix: shape (len(old_chunks), len(new_chunks))
        sim_matrix = cosine_similarity(old_embeddings, new_embeddings)

        matched_pairs: list[dict[str, Any]] = []
        matched_old_indices = set()
        matched_new_indices = set()

        for i, old_chunk in enumerate(old_chunks):
            # Sort matches for this old chunk
            row_sims = sim_matrix[i]
            best_matches = np.argsort(row_sims)[::-1][:top_k]

            for j in best_matches:
                score = float(row_sims[j])
                if score >= similarity_threshold:
                    matched_pairs.append({
                        "old_chunk": old_chunk,
                        "new_chunk": new_chunks[j],
                        "similarity_score": round(score, 4),
                        "old_index": i,
                        "new_index": j
                    })
                    matched_old_indices.add(i)
                    matched_new_indices.add(j)

        unmatched_old = [old_chunks[i] for i in range(len(old_chunks)) if i not in matched_old_indices]
        unmatched_new = [new_chunks[j] for j in range(len(new_chunks)) if j not in matched_new_indices]

        # Sort matched pairs descending by similarity
        matched_pairs.sort(key=lambda x: x["similarity_score"], reverse=True)

        return matched_pairs, unmatched_old, unmatched_new
