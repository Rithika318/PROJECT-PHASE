import uuid
from datetime import datetime, timezone
from sqlalchemy import Column, String, Integer, Float, Boolean, DateTime, ForeignKey, Text, JSON
from sqlalchemy.orm import relationship
from app.database.session import Base

def generate_uuid() -> str:
    return str(uuid.uuid4())

class User(Base):
    __tablename__ = "users"

    id = Column(String, primary_key=True, default=generate_uuid, index=True)
    email = Column(String, unique=True, index=True, nullable=False)
    full_name = Column(String, nullable=False)
    hashed_password = Column(String, nullable=False)
    role = Column(String, default="developer")
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))

    # Relationships
    documents = relationship("Document", back_populates="owner", cascade="all, delete-orphan")
    analyses = relationship("Analysis", back_populates="owner", cascade="all, delete-orphan")
    datasets = relationship("Dataset", back_populates="owner", cascade="all, delete-orphan")
    training_jobs = relationship("TrainingJob", back_populates="owner", cascade="all, delete-orphan")
    settings = relationship("UserSettings", back_populates="owner", uselist=False, cascade="all, delete-orphan")

class Document(Base):
    __tablename__ = "documents"

    id = Column(String, primary_key=True, default=generate_uuid, index=True)
    user_id = Column(String, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    filename = Column(String, nullable=False)
    stored_filename = Column(String, nullable=False)
    file_path = Column(String, nullable=False)
    file_type = Column(String, nullable=False)  # 'pdf', 'docx', or 'txt'
    file_size = Column(Integer, default=0)
    word_count = Column(Integer, default=0)
    section_count = Column(Integer, default=0)
    chunk_count = Column(Integer, default=0)
    extraction_status = Column(String, default="pending")  # pending, completed, failed
    is_scanned_ocr_needed = Column(Boolean, default=False)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    owner = relationship("User", back_populates="documents")
    chunks = relationship("DocumentChunk", back_populates="document", cascade="all, delete-orphan", order_by="DocumentChunk.chunk_index")

class DocumentChunk(Base):
    __tablename__ = "document_chunks"

    id = Column(String, primary_key=True, default=generate_uuid, index=True)
    document_id = Column(String, ForeignKey("documents.id", ondelete="CASCADE"), nullable=False, index=True)
    chunk_index = Column(Integer, nullable=False)
    page_number = Column(Integer, nullable=True)
    section_heading = Column(String, nullable=True)
    content = Column(Text, nullable=False)
    token_count = Column(Integer, default=0)
    metadata_json = Column(JSON, default=dict)

    document = relationship("Document", back_populates="chunks")

class Analysis(Base):
    __tablename__ = "analyses"

    id = Column(String, primary_key=True, default=generate_uuid, index=True)
    user_id = Column(String, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    title = Column(String, nullable=False)
    description = Column(Text, nullable=True)
    old_doc_id = Column(String, ForeignKey("documents.id", ondelete="SET NULL"), nullable=True)
    new_doc_id = Column(String, ForeignKey("documents.id", ondelete="SET NULL"), nullable=True)
    
    # Progress & Status
    status = Column(String, default="pending")  # pending, extracting, chunking, embedding, retrieving, nli_evaluating, llm_verifying, scoring, completed, failed
    progress_stage = Column(Integer, default=1)  # 1 to 8
    progress_percent = Column(Integer, default=0)
    error_message = Column(Text, nullable=True)
    
    # Metrics
    consistency_score = Column(Float, default=100.0)
    status_label = Column(String, default="Pending Analysis")  # Excellent consistency, Good consistency, Needs review, Significant inconsistencies
    matched_pairs_count = Column(Integer, default=0)
    confirmed_issues_count = Column(Integer, default=0)
    review_required_count = Column(Integer, default=0)
    duration_seconds = Column(Float, default=0.0)
    model_used = Column(String, default="Llama 3.1 8B Instruct (Local Ollama)")
    fine_tuned_adapter_used = Column(Boolean, default=False)
    
    # Timestamps
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    completed_at = Column(DateTime, nullable=True)

    owner = relationship("User", back_populates="analyses")
    old_document = relationship("Document", foreign_keys=[old_doc_id])
    new_document = relationship("Document", foreign_keys=[new_doc_id])
    matched_pairs = relationship("MatchedPair", back_populates="analysis", cascade="all, delete-orphan")
    issues = relationship("DetectedIssue", back_populates="analysis", cascade="all, delete-orphan")

class MatchedPair(Base):
    __tablename__ = "matched_pairs"

    id = Column(String, primary_key=True, default=generate_uuid, index=True)
    analysis_id = Column(String, ForeignKey("analyses.id", ondelete="CASCADE"), nullable=False, index=True)
    old_chunk_id = Column(String, ForeignKey("document_chunks.id", ondelete="SET NULL"), nullable=True)
    new_chunk_id = Column(String, ForeignKey("document_chunks.id", ondelete="SET NULL"), nullable=True)
    similarity_score = Column(Float, default=0.0)
    nli_label = Column(String, default="neutral")  # entailment, contradiction, neutral
    nli_confidence = Column(Float, default=0.0)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    analysis = relationship("Analysis", back_populates="matched_pairs")
    old_chunk = relationship("DocumentChunk", foreign_keys=[old_chunk_id])
    new_chunk = relationship("DocumentChunk", foreign_keys=[new_chunk_id])
    issues = relationship("DetectedIssue", back_populates="matched_pair")

class DetectedIssue(Base):
    __tablename__ = "detected_issues"

    id = Column(String, primary_key=True, default=generate_uuid, index=True)
    analysis_id = Column(String, ForeignKey("analyses.id", ondelete="CASCADE"), nullable=False, index=True)
    matched_pair_id = Column(String, ForeignKey("matched_pairs.id", ondelete="SET NULL"), nullable=True)
    issue_code = Column(String, nullable=False)  # e.g. ISS-001
    
    # The 5 Required Categories
    # Consistent, Contradiction, Outdated Information, Missing Content, Terminology Inconsistency
    category = Column(String, nullable=False, index=True)
    title = Column(String, nullable=False)
    severity = Column(String, default="Medium")  # Critical, High, Medium, Low, Informational
    confidence = Column(Float, default=0.85)
    explanation = Column(Text, nullable=False)
    old_evidence = Column(Text, nullable=True)
    new_evidence = Column(Text, nullable=True)
    source_section_old = Column(String, nullable=True)
    source_section_new = Column(String, nullable=True)
    source_page_old = Column(Integer, nullable=True)
    source_page_new = Column(Integer, nullable=True)
    suggested_correction = Column(Text, nullable=True)
    
    # Review workflow
    verification_status = Column(String, default="pending")  # pending, confirmed, rejected, reviewed
    reviewer_notes = Column(Text, nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    analysis = relationship("Analysis", back_populates="issues")
    matched_pair = relationship("MatchedPair", back_populates="issues")

class Dataset(Base):
    __tablename__ = "datasets"

    id = Column(String, primary_key=True, default=generate_uuid, index=True)
    user_id = Column(String, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    filename = Column(String, nullable=False)
    file_path = Column(String, nullable=False)
    row_count = Column(Integer, default=0)
    label_distribution_json = Column(JSON, default=dict)
    validation_status = Column(String, default="valid")
    train_count = Column(Integer, default=0)
    val_count = Column(Integer, default=0)
    test_count = Column(Integer, default=0)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    owner = relationship("User", back_populates="datasets")
    training_jobs = relationship("TrainingJob", back_populates="dataset")

class TrainingJob(Base):
    __tablename__ = "training_jobs"

    id = Column(String, primary_key=True, default=generate_uuid, index=True)
    user_id = Column(String, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    dataset_id = Column(String, ForeignKey("datasets.id", ondelete="SET NULL"), nullable=True)
    status = Column(String, default="pending")  # pending, running, completed, failed
    progress_percent = Column(Integer, default=0)
    config_json = Column(JSON, default=dict)
    training_loss_history_json = Column(JSON, default=list)
    val_metrics_json = Column(JSON, default=dict)
    adapter_path = Column(String, nullable=True)
    error_message = Column(Text, nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    completed_at = Column(DateTime, nullable=True)

    owner = relationship("User", back_populates="training_jobs")
    dataset = relationship("Dataset", back_populates="training_jobs")

class ModelEvaluation(Base):
    __tablename__ = "model_evaluations"

    id = Column(String, primary_key=True, default=generate_uuid, index=True)
    user_id = Column(String, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    model_name = Column(String, nullable=False)
    dataset_id = Column(String, ForeignKey("datasets.id", ondelete="SET NULL"), nullable=True)
    accuracy = Column(Float, default=0.0)
    precision = Column(Float, default=0.0)
    recall = Column(Float, default=0.0)
    macro_f1 = Column(Float, default=0.0)
    per_class_metrics_json = Column(JSON, default=dict)
    confusion_matrix_json = Column(JSON, default=dict)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

class UserSettings(Base):
    __tablename__ = "user_settings"

    id = Column(String, primary_key=True, default=generate_uuid, index=True)
    user_id = Column(String, ForeignKey("users.id", ondelete="CASCADE"), unique=True, nullable=False)
    similarity_threshold = Column(Float, default=0.55)
    confidence_threshold = Column(Float, default=0.50)
    critical_weight = Column(Float, default=25.0)
    high_weight = Column(Float, default=15.0)
    medium_weight = Column(Float, default=8.0)
    low_weight = Column(Float, default=3.0)
    selected_model = Column(String, default="llama3.1:8b")
    use_adapter = Column(Boolean, default=False)
    inference_mode = Column(String, default="ollama")  # ollama or local_nli_hybrid
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    owner = relationship("User", back_populates="settings")
