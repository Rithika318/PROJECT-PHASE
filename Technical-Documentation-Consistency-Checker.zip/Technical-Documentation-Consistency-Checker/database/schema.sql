CREATE TABLE analyses (
	id VARCHAR NOT NULL, 
	user_id VARCHAR NOT NULL, 
	title VARCHAR NOT NULL, 
	description TEXT, 
	old_doc_id VARCHAR, 
	new_doc_id VARCHAR, 
	status VARCHAR, 
	progress_stage INTEGER, 
	progress_percent INTEGER, 
	error_message TEXT, 
	consistency_score FLOAT, 
	status_label VARCHAR, 
	matched_pairs_count INTEGER, 
	confirmed_issues_count INTEGER, 
	review_required_count INTEGER, 
	duration_seconds FLOAT, 
	model_used VARCHAR, 
	fine_tuned_adapter_used BOOLEAN, 
	created_at DATETIME, 
	completed_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(user_id) REFERENCES users (id) ON DELETE CASCADE, 
	FOREIGN KEY(old_doc_id) REFERENCES documents (id) ON DELETE SET NULL, 
	FOREIGN KEY(new_doc_id) REFERENCES documents (id) ON DELETE SET NULL
);
CREATE TABLE datasets (
	id VARCHAR NOT NULL, 
	user_id VARCHAR NOT NULL, 
	filename VARCHAR NOT NULL, 
	file_path VARCHAR NOT NULL, 
	row_count INTEGER, 
	label_distribution_json JSON, 
	validation_status VARCHAR, 
	train_count INTEGER, 
	val_count INTEGER, 
	test_count INTEGER, 
	created_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(user_id) REFERENCES users (id) ON DELETE CASCADE
);
CREATE TABLE detected_issues (
	id VARCHAR NOT NULL, 
	analysis_id VARCHAR NOT NULL, 
	matched_pair_id VARCHAR, 
	issue_code VARCHAR NOT NULL, 
	category VARCHAR NOT NULL, 
	title VARCHAR NOT NULL, 
	severity VARCHAR, 
	confidence FLOAT, 
	explanation TEXT NOT NULL, 
	old_evidence TEXT, 
	new_evidence TEXT, 
	source_section_old VARCHAR, 
	source_section_new VARCHAR, 
	source_page_old INTEGER, 
	source_page_new INTEGER, 
	suggested_correction TEXT, 
	verification_status VARCHAR, 
	reviewer_notes TEXT, 
	created_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(analysis_id) REFERENCES analyses (id) ON DELETE CASCADE, 
	FOREIGN KEY(matched_pair_id) REFERENCES matched_pairs (id) ON DELETE SET NULL
);
CREATE TABLE document_chunks (
	id VARCHAR NOT NULL, 
	document_id VARCHAR NOT NULL, 
	chunk_index INTEGER NOT NULL, 
	page_number INTEGER, 
	section_heading VARCHAR, 
	content TEXT NOT NULL, 
	token_count INTEGER, 
	metadata_json JSON, 
	PRIMARY KEY (id), 
	FOREIGN KEY(document_id) REFERENCES documents (id) ON DELETE CASCADE
);
CREATE TABLE documents (
	id VARCHAR NOT NULL, 
	user_id VARCHAR NOT NULL, 
	filename VARCHAR NOT NULL, 
	stored_filename VARCHAR NOT NULL, 
	file_path VARCHAR NOT NULL, 
	file_type VARCHAR NOT NULL, 
	file_size INTEGER, 
	word_count INTEGER, 
	section_count INTEGER, 
	chunk_count INTEGER, 
	extraction_status VARCHAR, 
	is_scanned_ocr_needed BOOLEAN, 
	created_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(user_id) REFERENCES users (id) ON DELETE CASCADE
);
CREATE TABLE matched_pairs (
	id VARCHAR NOT NULL, 
	analysis_id VARCHAR NOT NULL, 
	old_chunk_id VARCHAR, 
	new_chunk_id VARCHAR, 
	similarity_score FLOAT, 
	nli_label VARCHAR, 
	nli_confidence FLOAT, 
	created_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(analysis_id) REFERENCES analyses (id) ON DELETE CASCADE, 
	FOREIGN KEY(old_chunk_id) REFERENCES document_chunks (id) ON DELETE SET NULL, 
	FOREIGN KEY(new_chunk_id) REFERENCES document_chunks (id) ON DELETE SET NULL
);
CREATE TABLE model_evaluations (
	id VARCHAR NOT NULL, 
	user_id VARCHAR NOT NULL, 
	model_name VARCHAR NOT NULL, 
	dataset_id VARCHAR, 
	accuracy FLOAT, 
	precision FLOAT, 
	recall FLOAT, 
	macro_f1 FLOAT, 
	per_class_metrics_json JSON, 
	confusion_matrix_json JSON, 
	created_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(user_id) REFERENCES users (id) ON DELETE CASCADE, 
	FOREIGN KEY(dataset_id) REFERENCES datasets (id) ON DELETE SET NULL
);
CREATE TABLE training_jobs (
	id VARCHAR NOT NULL, 
	user_id VARCHAR NOT NULL, 
	dataset_id VARCHAR, 
	status VARCHAR, 
	progress_percent INTEGER, 
	config_json JSON, 
	training_loss_history_json JSON, 
	val_metrics_json JSON, 
	adapter_path VARCHAR, 
	error_message TEXT, 
	created_at DATETIME, 
	completed_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(user_id) REFERENCES users (id) ON DELETE CASCADE, 
	FOREIGN KEY(dataset_id) REFERENCES datasets (id) ON DELETE SET NULL
);
CREATE TABLE user_settings (
	id VARCHAR NOT NULL, 
	user_id VARCHAR NOT NULL, 
	similarity_threshold FLOAT, 
	confidence_threshold FLOAT, 
	critical_weight FLOAT, 
	high_weight FLOAT, 
	medium_weight FLOAT, 
	low_weight FLOAT, 
	selected_model VARCHAR, 
	use_adapter BOOLEAN, 
	inference_mode VARCHAR, 
	created_at DATETIME, 
	PRIMARY KEY (id), 
	UNIQUE (user_id), 
	FOREIGN KEY(user_id) REFERENCES users (id) ON DELETE CASCADE
);
CREATE TABLE users (
	id VARCHAR NOT NULL, 
	email VARCHAR NOT NULL, 
	full_name VARCHAR NOT NULL, 
	hashed_password VARCHAR NOT NULL, 
	role VARCHAR, 
	created_at DATETIME, 
	updated_at DATETIME, 
	PRIMARY KEY (id)
);
CREATE INDEX ix_users_id ON users (id);
CREATE INDEX ix_documents_id ON documents (id);
CREATE INDEX ix_documents_user_id ON documents (user_id);
CREATE INDEX ix_datasets_user_id ON datasets (user_id);
CREATE INDEX ix_datasets_id ON datasets (id);
CREATE INDEX ix_user_settings_id ON user_settings (id);
CREATE INDEX ix_document_chunks_id ON document_chunks (id);
CREATE INDEX ix_document_chunks_document_id ON document_chunks (document_id);
CREATE INDEX ix_analyses_user_id ON analyses (user_id);
CREATE INDEX ix_analyses_id ON analyses (id);
CREATE INDEX ix_training_jobs_id ON training_jobs (id);
CREATE INDEX ix_training_jobs_user_id ON training_jobs (user_id);
CREATE INDEX ix_model_evaluations_id ON model_evaluations (id);
CREATE INDEX ix_model_evaluations_user_id ON model_evaluations (user_id);
CREATE INDEX ix_matched_pairs_id ON matched_pairs (id);
CREATE INDEX ix_matched_pairs_analysis_id ON matched_pairs (analysis_id);
CREATE INDEX ix_detected_issues_category ON detected_issues (category);
CREATE INDEX ix_detected_issues_analysis_id ON detected_issues (analysis_id);
CREATE INDEX ix_detected_issues_id ON detected_issues (id);
