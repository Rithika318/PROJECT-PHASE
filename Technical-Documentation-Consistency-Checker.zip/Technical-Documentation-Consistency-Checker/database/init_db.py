"""
Database Initialization Script for Technical Documentation Consistency Checker.
Creates all required tables in SQLite and seeds the default evaluator account.
"""

import sys
from pathlib import Path

# Add backend directory to sys.path
backend_dir = Path(__file__).resolve().parent.parent / "backend"
sys.path.insert(0, str(backend_dir))

from app.database.session import engine, Base, SessionLocal
from app.models.entities import User, UserSettings
from app.core.security import get_password_hash
from app.services.sample_docs_generator import generate_sample_documents

def init_db():
    print("=" * 60)
    print("Initializing Technical Documentation Consistency Checker Database...")
    print("=" * 60)

    # Create all tables defined in metadata
    Base.metadata.create_all(bind=engine)
    print("✓ Database tables created successfully.")

    # Seed demo account
    db = SessionLocal()
    try:
        admin = db.query(User).filter(User.email == "demo@btech.edu").first()
        if not admin:
            print("✓ Seeding demo user: demo@btech.edu / DemoPass123!")
            hashed_pwd = get_password_hash("DemoPass123!")
            user = User(
                email="demo@btech.edu",
                full_name="Final-Year Project Evaluator",
                hashed_password=hashed_pwd,
                role="lead_architect"
            )
            db.add(user)
            db.commit()
            db.refresh(user)

            user_settings = UserSettings(user_id=user.id)
            db.add(user_settings)
            db.commit()
            print("✓ Demo account created.")
        else:
            print("✓ Demo account already present.")

        # Ensure sample documents exist
        generate_sample_documents()
        print("✓ Sample baseline & updated technical documents ready.")
    finally:
        db.close()

    print("=" * 60)
    print("Database initialization complete.")
    print("=" * 60)

if __name__ == "__main__":
    init_db()
