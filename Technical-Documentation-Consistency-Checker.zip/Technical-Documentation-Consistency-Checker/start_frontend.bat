@echo off
echo ========================================================
echo Starting Technical Documentation Consistency Checker
echo React + Vite Frontend Client (Port 5173)
echo ========================================================
cd frontend
npm run dev
pause
