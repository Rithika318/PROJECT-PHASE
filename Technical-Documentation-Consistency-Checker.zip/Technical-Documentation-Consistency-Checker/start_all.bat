@echo off
echo ========================================================
echo Launching LLM-Based Documentation Consistency Checker
echo Full-Stack Application (Backend + Frontend)
echo ========================================================
echo Starting FastAPI Backend on http://127.0.0.1:8000 ...
start "Backend - FastAPI" cmd /k "cd backend && python -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload"

echo Starting Vite Frontend on http://localhost:5173 ...
start "Frontend - React Vite" cmd /k "cd frontend && npm run dev"

echo Both processes launched in separate windows.
echo Navigate to http://localhost:5173 to access the dashboard.
