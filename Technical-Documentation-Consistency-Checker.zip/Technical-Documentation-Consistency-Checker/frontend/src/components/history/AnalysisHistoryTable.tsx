﻿import React, { useState } from 'react';
import { 
  History, 
  FileText, 
  ArrowRight, 
  Calendar, 
  CheckCircle2, 
  AlertCircle,
  Eye,
  Download,
  Filter
} from 'lucide-react';
import { SAMPLE_HISTORY } from '../../data/sampleHistory';
import { useAnalysis } from '../../context/AnalysisContext';
import { AuditSession } from '../../types';

export const AnalysisHistoryTable: React.FC = () => {
  const { setActiveTab } = useAnalysis();
  const [selectedSession, setSelectedSession] = useState<AuditSession | null>(null);

  const getScoreColor = (score: number) => {
    if (score >= 85) return 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30';
    if (score >= 75) return 'text-indigo-400 bg-indigo-500/10 border-indigo-500/30';
    return 'text-amber-400 bg-amber-500/10 border-amber-500/30';
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <History className="w-5 h-5 text-indigo-400" />
            <span>Analysis Audit Trail & Historical Sessions</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Historical consistency evaluations across previous software release document pairs
          </p>
        </div>

        <span className="text-xs font-mono px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-300">
          6 Recorded Sessions
        </span>
      </div>

      {/* History Table */}
      <div className="rounded-2xl bg-slate-900/80 border border-slate-800/80 backdrop-blur-md shadow-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950/60 text-slate-400 text-[11px] uppercase tracking-wider font-semibold border-b border-slate-800">
              <tr>
                <th className="py-3.5 px-4">Session ID</th>
                <th className="py-3.5 px-4">Document Pair Evaluated</th>
                <th className="py-3.5 px-4">Analysis Date</th>
                <th className="py-3.5 px-4">Consistency Score</th>
                <th className="py-3.5 px-4">Total Issues</th>
                <th className="py-3.5 px-4">Severity Breakdown</th>
                <th className="py-3.5 px-4">Status</th>
                <th className="py-3.5 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/50">
              {SAMPLE_HISTORY.map((sess) => (
                <tr key={sess.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-3.5 px-4 font-mono font-bold text-indigo-300">
                    {sess.id}
                  </td>
                  <td className="py-3.5 px-4">
                    <div className="space-y-0.5">
                      <div className="font-semibold text-slate-200 flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-rose-400"></span>
                        <span className="truncate max-w-[200px]">{sess.docOldName}</span>
                      </div>
                      <div className="font-semibold text-slate-400 flex items-center gap-1.5 text-[11px]">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                        <span className="truncate max-w-[200px]">{sess.docNewName}</span>
                      </div>
                    </div>
                  </td>
                  <td className="py-3.5 px-4 text-slate-300 font-mono text-[11px]">
                    {sess.date}
                  </td>
                  <td className="py-3.5 px-4 font-mono font-bold">
                    <span className={`px-2.5 py-1 rounded-full text-xs border ${getScoreColor(sess.consistencyScore)}`}>
                      {sess.consistencyScore}%
                    </span>
                  </td>
                  <td className="py-3.5 px-4 font-bold text-white font-mono">
                    {sess.totalIssues}
                  </td>
                  <td className="py-3.5 px-4">
                    <div className="flex items-center gap-1.5 text-[10px] font-mono">
                      <span className="px-1.5 py-0.5 rounded bg-rose-500/20 text-rose-300">
                        {sess.highSeverity}H
                      </span>
                      <span className="px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300">
                        {sess.mediumSeverity}M
                      </span>
                      <span className="px-1.5 py-0.5 rounded bg-slate-500/20 text-slate-300">
                        {sess.lowSeverity}L
                      </span>
                    </div>
                  </td>
                  <td className="py-3.5 px-4">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      sess.status === 'Completed' 
                        ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30' 
                        : 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                    }`}>
                      {sess.status}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-right">
                    <button
                      onClick={() => {
                        setSelectedSession(sess);
                        setActiveTab('reports');
                      }}
                      className="px-3 py-1.5 rounded-lg bg-indigo-600/20 hover:bg-indigo-600 text-indigo-300 hover:text-white border border-indigo-500/30 font-semibold text-xs transition-all flex items-center gap-1.5 ml-auto"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>View Report</span>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
