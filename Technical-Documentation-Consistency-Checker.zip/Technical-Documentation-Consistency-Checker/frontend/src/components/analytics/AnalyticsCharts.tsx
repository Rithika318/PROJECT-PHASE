﻿import React from 'react';
import { 
  BarChart3, 
  PieChart as PieIcon, 
  TrendingUp, 
  Activity, 
  Layers, 
  ShieldCheck 
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell, 
  LineChart, 
  Line, 
  AreaChart, 
  Area, 
  CartesianGrid 
} from 'recharts';

export const AnalyticsCharts: React.FC = () => {
  // 1. Issues by Category
  const categoryData = [
    { name: 'Inconsistency', count: 14, fill: '#6366f1' },
    { name: 'Outdated Info', count: 12, fill: '#f59e0b' },
    { name: 'Missing Content', count: 7, fill: '#3b82f6' },
    { name: 'Terminology', count: 3, fill: '#10b981' },
    { name: 'Contradiction', count: 1, fill: '#ec4899' },
  ];

  // 2. Issues by Severity
  const severityData = [
    { name: 'High Severity', count: 8, color: '#f43f5e' },
    { name: 'Medium Severity', count: 17, color: '#f59e0b' },
    { name: 'Low Severity', count: 12, color: '#64748b' },
  ];

  // 3. Consistency Score Over Time
  const scoreTrendData = [
    { date: 'Aug 01', score: 88 },
    { date: 'Aug 14', score: 68 },
    { date: 'Aug 28', score: 92 },
    { date: 'Sep 02', score: 71 },
    { date: 'Sep 08', score: 84 },
    { date: 'Sep 15', score: 78 },
  ];

  // 4. Documents Analyzed Over Time
  const docsOverTimeData = [
    { month: 'Apr', docs: 2 },
    { month: 'May', docs: 4 },
    { month: 'Jun', docs: 5 },
    { month: 'Jul', docs: 8 },
    { month: 'Aug', docs: 16 },
    { month: 'Sep', docs: 24 },
  ];

  // 5. Most Affected Sections
  const affectedSectionsData = [
    { section: 'User API', issues: 8 },
    { section: 'Authentication', issues: 7 },
    { section: 'Search API', issues: 5 },
    { section: 'Payment Gateway', issues: 5 },
    { section: 'Webhook Security', issues: 4 },
    { section: 'File Upload', issues: 4 },
    { section: 'Rate Limiting', issues: 4 },
  ];

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-indigo-400" />
            <span>Audit Analytics & Metric Distributions</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Visual aggregation of 37 detected discrepancies across 24 analyzed technical documents
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono text-slate-400">
          <span>Engine: Custom Transformer Scorer</span>
        </div>
      </div>

      {/* Row 1: Issues by Category & Issues by Severity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Issues by Category */}
        <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800/80 backdrop-blur-md shadow-xl">
          <div className="flex items-center justify-between pb-4 border-b border-slate-800">
            <div>
              <h3 className="text-sm font-bold text-white">Issues by Category</h3>
              <p className="text-xs text-slate-400">Distribution across detection classifications</p>
            </div>
            <span className="text-xs font-mono font-bold text-indigo-400">37 Total</span>
          </div>

          <div className="h-64 mt-4">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={categoryData} margin={{ top: 10, right: 10, left: -20, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                <XAxis dataKey="name" stroke="#64748b" tick={{ fontSize: 11 }} angle={-15} textAnchor="end" />
                <YAxis stroke="#64748b" tick={{ fontSize: 11 }} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '0.75rem', fontSize: '12px' }}
                />
                <Bar dataKey="count" radius={[6, 6, 0, 0]}>
                  {categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Issues by Severity Donut */}
        <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800/80 backdrop-blur-md shadow-xl">
          <div className="flex items-center justify-between pb-4 border-b border-slate-800">
            <div>
              <h3 className="text-sm font-bold text-white">Issues by Severity</h3>
              <p className="text-xs text-slate-400">Contract impact prioritization</p>
            </div>
            <span className="text-xs font-mono font-bold text-rose-400">8 High Priority</span>
          </div>

          <div className="h-64 mt-4 flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={severityData}
                  cx="50%"
                  cy="50%"
                  innerRadius={55}
                  outerRadius={85}
                  paddingAngle={4}
                  dataKey="count"
                >
                  {severityData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '0.75rem', fontSize: '12px' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="flex items-center justify-around pt-2 border-t border-slate-800 text-xs">
            {severityData.map((s, idx) => (
              <div key={idx} className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: s.color }} />
                <span className="text-slate-300 font-medium">{s.name}:</span>
                <span className="font-mono font-bold text-white">{s.count}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Row 2: Consistency Score Trend & Documents Analyzed Over Time */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Consistency Score Over Time */}
        <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800/80 backdrop-blur-md shadow-xl">
          <div className="flex items-center justify-between pb-4 border-b border-slate-800">
            <div>
              <h3 className="text-sm font-bold text-white">Consistency Score Trend</h3>
              <p className="text-xs text-slate-400">Longitudinal index across audited release branches</p>
            </div>
            <span className="text-xs font-mono font-bold text-emerald-400">Current: 78%</span>
          </div>

          <div className="h-64 mt-4">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={scoreTrendData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                <XAxis dataKey="date" stroke="#64748b" tick={{ fontSize: 11 }} />
                <YAxis domain={[50, 100]} stroke="#64748b" tick={{ fontSize: 11 }} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '0.75rem', fontSize: '12px' }}
                  formatter={(val: any) => [`${val}%`, 'Consistency Score']}
                />
                <Line 
                  type="monotone" 
                  dataKey="score" 
                  stroke="#10b981" 
                  strokeWidth={3} 
                  dot={{ fill: '#10b981', r: 5 }} 
                  activeDot={{ r: 8, stroke: '#ffffff', strokeWidth: 2 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Documents Analyzed Over Time */}
        <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800/80 backdrop-blur-md shadow-xl">
          <div className="flex items-center justify-between pb-4 border-b border-slate-800">
            <div>
              <h3 className="text-sm font-bold text-white">Cumulative Documents Analyzed</h3>
              <p className="text-xs text-slate-400">Corpus scale expansion over project lifecycle</p>
            </div>
            <span className="text-xs font-mono font-bold text-indigo-400">24 Documents</span>
          </div>

          <div className="h-64 mt-4">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={docsOverTimeData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="docColor" x1="0%" y1="0%" x2="0%" y2="100%">
                    <stop offset="5%" stopColor="#6366f1" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                <XAxis dataKey="month" stroke="#64748b" tick={{ fontSize: 11 }} />
                <YAxis stroke="#64748b" tick={{ fontSize: 11 }} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '0.75rem', fontSize: '12px' }}
                />
                <Area type="monotone" dataKey="docs" stroke="#6366f1" strokeWidth={3} fillOpacity={1} fill="url(#docColor)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Row 3: Most Affected Documentation Sections */}
      <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800/80 backdrop-blur-md shadow-xl">
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div>
            <h3 className="text-sm font-bold text-white">Most Affected Technical Sections</h3>
            <p className="text-xs text-slate-400">Concentration of issues per technical subsystem</p>
          </div>
          <span className="text-xs font-mono text-slate-400">Top 7 Subsystems</span>
        </div>

        <div className="h-64 mt-4">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart 
              data={affectedSectionsData} 
              layout="vertical"
              margin={{ top: 10, right: 20, left: 40, bottom: 10 }}
            >
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" horizontal={false} />
              <XAxis type="number" stroke="#64748b" tick={{ fontSize: 11 }} />
              <YAxis type="category" dataKey="section" stroke="#64748b" tick={{ fontSize: 11 }} width={120} />
              <Tooltip 
                contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '0.75rem', fontSize: '12px' }}
              />
              <Bar dataKey="issues" fill="#818cf8" radius={[0, 6, 6, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
