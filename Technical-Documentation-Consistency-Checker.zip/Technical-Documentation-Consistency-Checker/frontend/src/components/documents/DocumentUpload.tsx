﻿import React, { useState, useRef } from 'react';
import { 
  UploadCloud, 
  FileText, 
  CheckCircle2, 
  FileCode, 
  Layers, 
  Cpu, 
  Terminal, 
  ArrowRight,
  RefreshCw,
  Sparkles,
  Info
} from 'lucide-react';
import { useAnalysis } from '../../context/AnalysisContext';
import { DocumentFile } from '../../types';

export const DocumentUpload: React.FC = () => {
  const { oldDoc, newDoc, setOldDoc, setNewDoc, runAnalysisSimulation, loadSampleDocs, setActiveTab } = useAnalysis();
  const [dragOverOld, setDragOverOld] = useState(false);
  const [dragOverNew, setDragOverNew] = useState(false);

  const fileInputOldRef = useRef<HTMLInputElement>(null);
  const fileInputNewRef = useRef<HTMLInputElement>(null);

  const handleSimulatedUpload = (versionType: 'old' | 'new', file: File) => {
    const ext = file.name.split('.').pop()?.toUpperCase() || 'TXT';
    const docType = (['PDF', 'MARKDOWN', 'HTML', 'TXT'].includes(ext) 
      ? (ext === 'MD' ? 'Markdown' : ext) 
      : 'Markdown') as DocumentFile['type'];

    const newDocObj: DocumentFile = {
      id: `DOC-${Date.now()}`,
      name: file.name,
      version: versionType === 'old' ? 'v1.0.x' : 'v2.0.x',
      type: docType,
      size: `${(file.size / 1024).toFixed(1)} KB`,
      uploadDate: new Date().toISOString().split('T')[0],
      status: 'Ready',
      content: `# Uploaded Document: ${file.name}\n\n[Parsed document content successfully extracted by Multi-Format Ingest Engine]`
    };

    if (versionType === 'old') {
      setOldDoc(newDocObj);
    } else {
      setNewDoc(newDocObj);
    }
  };

  const extractionCategories = [
    { label: 'Extracted Text Tokens', count: '4,820 words', detail: 'Tokenized with local vocabulary' },
    { label: 'Document Headings', count: '18 sections', detail: 'H1, H2, H3 hierarchy preserved' },
    { label: 'Code Blocks & Schemas', count: '14 snippets', detail: 'HTTP, JSON, Bash, YAML' },
    { label: 'API Endpoints', count: '18 routes', detail: 'GET, POST, PUT, DELETE' },
    { label: 'Functions & Methods', count: '12 signatures', detail: 'TypeScript / AST definitions' },
    { label: 'Extracted Parameters', count: '64 params', detail: 'Query, path, body, and header types' },
    { label: 'Data Types', count: '16 schemas', detail: 'integer, string, UUID, ISO-8601' },
    { label: 'API Versions Detected', count: 'v1.0 vs v2.0', detail: 'Version migration boundaries' },
    { label: 'Dependencies & SDKs', count: '8 libraries', detail: 'Node.js >= 18, Python >= 3.10' },
    { label: 'Workflow Sequences', count: '5 flows', detail: 'Auth handshake, charge, retry' },
    { label: 'Technical Terminology', count: '42 concepts', detail: 'HMAC-SHA256, Idempotency, RBAC' }
  ];

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <span>Document Ingestion & Multi-Format Extraction</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Upload two versions of your technical documentation (PDF, Markdown, HTML, TXT) for automated parsing.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={loadSampleDocs}
            className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700/80 border border-slate-700/80 text-xs font-semibold text-slate-200 hover:text-white flex items-center gap-1.5 transition-all shadow-sm"
          >
            <RefreshCw className="w-3.5 h-3.5 text-indigo-400" />
            <span>Load Sample API Specs</span>
          </button>
          <button
            onClick={runAnalysisSimulation}
            className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-500 hover:to-indigo-600 text-xs font-semibold text-white flex items-center gap-1.5 shadow-md shadow-indigo-600/30 transition-all"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Run Consistency Engine</span>
          </button>
        </div>
      </div>

      {/* Dual Upload Zone: Old Document & New Document */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Upload Card: Old Version Document */}
        <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800/80 backdrop-blur-md shadow-xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-rose-500/80"></div>
                <h3 className="text-sm font-bold text-white">1. Baseline (Old Version Document)</h3>
              </div>
              <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-rose-500/10 text-rose-400 border border-rose-500/20">
                BASELINE
              </span>
            </div>

            <p className="text-xs text-slate-400 mt-2 mb-4">
              The reference technical documentation or previously approved release specification.
            </p>

            {/* Dropzone */}
            <div
              onDragOver={(e) => { e.preventDefault(); setDragOverOld(true); }}
              onDragLeave={() => setDragOverOld(false)}
              onDrop={(e) => {
                e.preventDefault();
                setDragOverOld(false);
                if (e.dataTransfer.files?.[0]) {
                  handleSimulatedUpload('old', e.dataTransfer.files[0]);
                }
              }}
              onClick={() => fileInputOldRef.current?.click()}
              className={`border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition-all duration-200 ${
                dragOverOld 
                  ? 'border-indigo-500 bg-indigo-500/10' 
                  : 'border-slate-700/80 hover:border-slate-600 bg-slate-950/40 hover:bg-slate-950/70'
              }`}
            >
              <input
                type="file"
                ref={fileInputOldRef}
                className="hidden"
                accept=".pdf,.md,.markdown,.html,.txt"
                onChange={(e) => {
                  if (e.target.files?.[0]) handleSimulatedUpload('old', e.target.files[0]);
                }}
              />
              <UploadCloud className="w-10 h-10 mx-auto text-indigo-400 mb-2" />
              <p className="text-xs font-semibold text-slate-200">
                Drag & Drop Old Document or <span className="text-indigo-400 underline">Browse</span>
              </p>
              <p className="text-[10px] text-slate-500 mt-1">
                Supported formats: PDF, Markdown (.md), HTML, TXT
              </p>
            </div>

            {/* Uploaded File Summary */}
            <div className="mt-4 p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-slate-200 flex items-center gap-2 truncate">
                  <FileCode className="w-4 h-4 text-indigo-400 shrink-0" />
                  <span className="truncate">{oldDoc.name}</span>
                </span>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-500/20 text-emerald-300 font-bold">
                  {oldDoc.status}
                </span>
              </div>

              <div className="grid grid-cols-3 gap-2 text-[10px] text-slate-400 pt-2 border-t border-slate-800/60 font-mono">
                <div>
                  <span className="text-slate-500 block">Version</span>
                  <span className="text-slate-300 font-bold">{oldDoc.version}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">Type</span>
                  <span className="text-slate-300 font-bold">{oldDoc.type}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">Size</span>
                  <span className="text-slate-300 font-bold">{oldDoc.size}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Upload Card: New Version Document */}
        <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800/80 backdrop-blur-md shadow-xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-emerald-400"></div>
                <h3 className="text-sm font-bold text-white">2. Target (New Version Document)</h3>
              </div>
              <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                UPDATED
              </span>
            </div>

            <p className="text-xs text-slate-400 mt-2 mb-4">
              The revised technical documentation to evaluate for consistency and completeness.
            </p>

            {/* Dropzone */}
            <div
              onDragOver={(e) => { e.preventDefault(); setDragOverNew(true); }}
              onDragLeave={() => setDragOverNew(false)}
              onDrop={(e) => {
                e.preventDefault();
                setDragOverNew(false);
                if (e.dataTransfer.files?.[0]) {
                  handleSimulatedUpload('new', e.dataTransfer.files[0]);
                }
              }}
              onClick={() => fileInputNewRef.current?.click()}
              className={`border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition-all duration-200 ${
                dragOverNew 
                  ? 'border-emerald-500 bg-emerald-500/10' 
                  : 'border-slate-700/80 hover:border-slate-600 bg-slate-950/40 hover:bg-slate-950/70'
              }`}
            >
              <input
                type="file"
                ref={fileInputNewRef}
                className="hidden"
                accept=".pdf,.md,.markdown,.html,.txt"
                onChange={(e) => {
                  if (e.target.files?.[0]) handleSimulatedUpload('new', e.target.files[0]);
                }}
              />
              <UploadCloud className="w-10 h-10 mx-auto text-emerald-400 mb-2" />
              <p className="text-xs font-semibold text-slate-200">
                Drag & Drop New Document or <span className="text-emerald-400 underline">Browse</span>
              </p>
              <p className="text-[10px] text-slate-500 mt-1">
                Supported formats: PDF, Markdown (.md), HTML, TXT
              </p>
            </div>

            {/* Uploaded File Summary */}
            <div className="mt-4 p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-slate-200 flex items-center gap-2 truncate">
                  <FileCode className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span className="truncate">{newDoc.name}</span>
                </span>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-500/20 text-emerald-300 font-bold">
                  {newDoc.status}
                </span>
              </div>

              <div className="grid grid-cols-3 gap-2 text-[10px] text-slate-400 pt-2 border-t border-slate-800/60 font-mono">
                <div>
                  <span className="text-slate-500 block">Version</span>
                  <span className="text-slate-300 font-bold">{newDoc.version}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">Type</span>
                  <span className="text-slate-300 font-bold">{newDoc.type}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">Size</span>
                  <span className="text-slate-300 font-bold">{newDoc.size}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Multi-Format Extraction Breakdown Grid */}
      <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800/80 backdrop-blur-md shadow-xl">
        <div className="flex items-center justify-between pb-4 border-b border-slate-800/60">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Layers className="w-4 h-4 text-indigo-400" />
              Document Parsing & Structured Information Extraction
            </h3>
            <p className="text-xs text-slate-400">
              Granular technical elements extracted by the Multi-Format Ingest Engine & Custom NLP Model
            </p>
          </div>
          <button
            onClick={() => setActiveTab('compare')}
            className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 flex items-center gap-1 transition-colors"
          >
            <span>Proceed to Compare</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3.5 mt-4">
          {extractionCategories.map((item, idx) => (
            <div key={idx} className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800/80 hover:border-indigo-500/30 transition-all">
              <span className="text-[11px] font-medium text-slate-400 block">
                {item.label}
              </span>
              <div className="flex items-baseline justify-between mt-1">
                <span className="text-sm font-bold text-white font-mono">
                  {item.count}
                </span>
                <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
              </div>
              <p className="text-[10px] text-slate-500 mt-1 leading-snug">
                {item.detail}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
