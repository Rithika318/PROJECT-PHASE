﻿import React, { useState } from 'react';
import { 
  X, 
  AlertTriangle, 
  CheckCircle2, 
  ArrowRight, 
  Copy, 
  Check, 
  ShieldAlert, 
  FileCode, 
  Cpu, 
  Sparkles,
  ExternalLink
} from 'lucide-react';
import { useAnalysis } from '../../context/AnalysisContext';

export const IssueDetailModal: React.FC = () => {
  const { selectedIssue, setSelectedIssue, toggleResolveIssue } = useAnalysis();
  const [copied, setCopied] = useState(false);

  if (!selectedIssue) return null;

  const handleCopyCorrection = () => {
    navigator.clipboard.writeText(selectedIssue.suggestedCorrection);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const getSeverityBadge = (sev: string) => {
    switch (sev) {
      case 'High':
        return 'bg-rose-500/20 text-rose-300 border-rose-500/40';
      case 'Medium':
        return 'bg-amber-500/20 text-amber-300 border-amber-500/40';
      default:
        return 'bg-slate-500/20 text-slate-300 border-slate-500/40';
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-150">
      <div 
        className="w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden animate-in zoom-in-95 duration-150 flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="p-6 border-b border-slate-800 flex items-start justify-between gap-4 bg-slate-950/40">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                {selectedIssue.id}
              </span>
              <span className={`text-xs font-semibold px-2.5 py-0.5 rounded-full border ${getSeverityBadge(selectedIssue.severity)}`}>
                {selectedIssue.severity} Severity
              </span>
              <span className="text-xs font-medium px-2.5 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                {selectedIssue.type}
              </span>
            </div>
            <h2 className="text-lg font-bold text-white tracking-tight">
              {selectedIssue.section}: {selectedIssue.type}
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Endpoint: <span className="font-mono text-indigo-300">{selectedIssue.endpoint || 'General Contract Specification'}</span>
            </p>
          </div>

          <button
            onClick={() => setSelectedIssue(null)}
            className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body (Scrollable) */}
        <div className="p-6 space-y-5 overflow-y-auto flex-1">
          {/* Side-by-Side Old vs New Value */}
          <div>
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-2">
              Detected Value Shift (Old vs New)
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* Old Value */}
              <div className="p-4 rounded-xl bg-slate-950/80 border border-rose-500/30 space-y-1">
                <span className="text-[11px] font-semibold text-rose-400 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-rose-500"></span>
                  Old Value (Documented)
                </span>
                <div className="p-2.5 rounded-lg bg-slate-900 font-mono text-xs text-rose-300 border border-rose-900/40 break-words">
                  {selectedIssue.oldValue}
                </div>
              </div>

              {/* New Value */}
              <div className="p-4 rounded-xl bg-slate-950/80 border border-emerald-500/30 space-y-1">
                <span className="text-[11px] font-semibold text-emerald-400 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                  New Value (Actual / Target)
                </span>
                <div className="p-2.5 rounded-lg bg-slate-900 font-mono text-xs text-emerald-300 border border-emerald-900/40 break-words">
                  {selectedIssue.newValue}
                </div>
              </div>
            </div>
          </div>

          {/* Reason Section */}
          <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 space-y-1.5">
            <span className="text-xs font-bold text-slate-300 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              Technical Discrepancy Reason
            </span>
            <p className="text-xs text-slate-300 leading-relaxed">
              {selectedIssue.reason}
            </p>
          </div>

          {/* Suggested Correction Section */}
          <div className="p-4 rounded-xl bg-gradient-to-br from-indigo-950/40 via-slate-950 to-slate-950 border border-indigo-500/30 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-indigo-300 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-indigo-400" />
                Suggested Documentation Correction
              </span>
              <button
                onClick={handleCopyCorrection}
                className="flex items-center gap-1 text-[11px] font-medium text-slate-300 hover:text-white px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 transition-colors"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
            <p className="text-xs text-slate-200 font-medium leading-relaxed bg-slate-900/80 p-3 rounded-lg border border-slate-800">
              {selectedIssue.suggestedCorrection}
            </p>
          </div>

          {/* Metadata Grid */}
          <div className="grid grid-cols-3 gap-3 text-[11px] font-mono text-slate-400 p-3 rounded-xl bg-slate-950/40 border border-slate-800">
            <div>
              <span className="text-slate-500 block text-[10px]">Rule Triggered</span>
              <span className="text-slate-200 font-bold">{selectedIssue.ruleId || 'RULE-AUTO-01'}</span>
            </div>
            <div>
              <span className="text-slate-500 block text-[10px]">Model Confidence</span>
              <span className="text-emerald-400 font-bold">{((selectedIssue.confidenceScore || 0.94) * 100).toFixed(0)}%</span>
            </div>
            <div>
              <span className="text-slate-500 block text-[10px]">Line Range</span>
              <span className="text-slate-300">{selectedIssue.lineRange || 'Lines 42-45'}</span>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/60 flex items-center justify-between">
          <button
            onClick={() => toggleResolveIssue(selectedIssue.id)}
            className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all ${
              selectedIssue.resolved
                ? 'bg-emerald-600/20 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-600/30'
                : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-600/25'
            }`}
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>{selectedIssue.resolved ? 'Marked as Resolved' : 'Mark Issue as Resolved'}</span>
          </button>

          <button
            onClick={() => setSelectedIssue(null)}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300 hover:text-white transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
