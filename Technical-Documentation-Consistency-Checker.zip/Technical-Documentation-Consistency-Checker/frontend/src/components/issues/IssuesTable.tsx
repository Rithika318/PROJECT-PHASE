﻿import React, { useState, useMemo } from 'react';
import { 
  AlertTriangle, 
  ArrowUpDown, 
  ChevronLeft, 
  ChevronRight, 
  Eye, 
  CheckCircle2, 
  ExternalLink,
  ShieldAlert,
  Info
} from 'lucide-react';
import { useAnalysis } from '../../context/AnalysisContext';
import { IssueFilterBar } from './IssueFilterBar';
import { IssueDetailModal } from './IssueDetailModal';

export const IssuesTable: React.FC = () => {
  const { 
    issues, 
    setSelectedIssue, 
    searchQuery, 
    selectedSeverity, 
    selectedCategory, 
    selectedSection,
    toggleResolveIssue 
  } = useAnalysis();

  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;
  const [sortField, setSortField] = useState<'id' | 'severity' | 'section'>('id');
  const [sortAsc, setSortAsc] = useState(true);

  const getSeverityWeight = (sev: string) => {
    switch (sev) {
      case 'High': return 3;
      case 'Medium': return 2;
      case 'Low': return 1;
      default: return 0;
    }
  };

  // Filter and sort logic
  const filteredIssues = useMemo(() => {
    return issues.filter((issue) => {
      // Search query
      const q = searchQuery.toLowerCase();
      const matchesSearch = !q || 
        issue.id.toLowerCase().includes(q) ||
        issue.section.toLowerCase().includes(q) ||
        issue.reason.toLowerCase().includes(q) ||
        issue.oldValue.toLowerCase().includes(q) ||
        issue.newValue.toLowerCase().includes(q) ||
        issue.suggestedCorrection.toLowerCase().includes(q);

      // Severity filter
      const matchesSeverity = selectedSeverity === 'All' || issue.severity === selectedSeverity;

      // Category filter
      const matchesCategory = selectedCategory === 'All' || issue.type === selectedCategory;

      // Section filter
      const matchesSection = selectedSection === 'All' || issue.section === selectedSection;

      return matchesSearch && matchesSeverity && matchesCategory && matchesSection;
    }).sort((a, b) => {
      if (sortField === 'severity') {
        const weightA = getSeverityWeight(a.severity);
        const weightB = getSeverityWeight(b.severity);
        return sortAsc ? weightA - weightB : weightB - weightA;
      } else if (sortField === 'section') {
        return sortAsc ? a.section.localeCompare(b.section) : b.section.localeCompare(a.section);
      } else {
        return sortAsc ? a.id.localeCompare(b.id) : b.id.localeCompare(a.id);
      }
    });
  }, [issues, searchQuery, selectedSeverity, selectedCategory, selectedSection, sortField, sortAsc]);

  const totalPages = Math.ceil(filteredIssues.length / itemsPerPage) || 1;
  const paginatedIssues = filteredIssues.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const getSeverityBadge = (sev: string) => {
    switch (sev) {
      case 'High':
        return 'bg-rose-500/15 text-rose-300 border-rose-500/30';
      case 'Medium':
        return 'bg-amber-500/15 text-amber-300 border-amber-500/30';
      default:
        return 'bg-slate-500/15 text-slate-300 border-slate-500/30';
    }
  };

  const handleSort = (field: 'id' | 'severity' | 'section') => {
    if (sortField === field) {
      setSortAsc(!sortAsc);
    } else {
      setSortField(field);
      setSortAsc(true);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-amber-400" />
            <span>Issue Detection & Discrepancy Registry</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Displaying {filteredIssues.length} of {issues.length} detected documentation discrepancies
          </p>
        </div>

        {/* Severity Summary Pills */}
        <div className="flex items-center gap-2 text-xs">
          <span className="px-2.5 py-1 rounded-lg bg-rose-500/15 border border-rose-500/30 text-rose-300 font-medium">
            8 High
          </span>
          <span className="px-2.5 py-1 rounded-lg bg-amber-500/15 border border-amber-500/30 text-amber-300 font-medium">
            17 Medium
          </span>
          <span className="px-2.5 py-1 rounded-lg bg-slate-500/15 border border-slate-500/30 text-slate-300 font-medium">
            12 Low
          </span>
        </div>
      </div>

      {/* Filter Bar */}
      <IssueFilterBar />

      {/* Issues Table Card */}
      <div className="rounded-2xl bg-slate-900/80 border border-slate-800/80 backdrop-blur-md shadow-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950/60 text-slate-400 text-[11px] uppercase tracking-wider font-semibold border-b border-slate-800">
              <tr>
                <th 
                  className="py-3.5 px-4 cursor-pointer hover:text-white transition-colors"
                  onClick={() => handleSort('id')}
                >
                  <div className="flex items-center gap-1.5">
                    <span>Issue ID</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th 
                  className="py-3.5 px-4 cursor-pointer hover:text-white transition-colors"
                  onClick={() => handleSort('section')}
                >
                  <div className="flex items-center gap-1.5">
                    <span>Section</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th className="py-3.5 px-4">Issue Type</th>
                <th 
                  className="py-3.5 px-4 cursor-pointer hover:text-white transition-colors"
                  onClick={() => handleSort('severity')}
                >
                  <div className="flex items-center gap-1.5">
                    <span>Severity</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th className="py-3.5 px-4">Old Value</th>
                <th className="py-3.5 px-4">New Value</th>
                <th className="py-3.5 px-4">Reason</th>
                <th className="py-3.5 px-4">Suggested Correction</th>
                <th className="py-3.5 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/50">
              {paginatedIssues.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-slate-500">
                    No issues match the selected filters.
                  </td>
                </tr>
              ) : (
                paginatedIssues.map((issue) => (
                  <tr
                    key={issue.id}
                    onClick={() => setSelectedIssue(issue)}
                    className="hover:bg-slate-800/40 transition-colors cursor-pointer group"
                  >
                    <td className="py-3.5 px-4 font-mono font-bold text-indigo-300 whitespace-nowrap">
                      {issue.id}
                    </td>
                    <td className="py-3.5 px-4 font-semibold text-slate-200 whitespace-nowrap">
                      {issue.section}
                    </td>
                    <td className="py-3.5 px-4 text-slate-300 whitespace-nowrap">
                      {issue.type}
                    </td>
                    <td className="py-3.5 px-4 whitespace-nowrap">
                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${getSeverityBadge(issue.severity)}`}>
                        {issue.severity}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 font-mono text-rose-300 max-w-[140px] truncate" title={issue.oldValue}>
                      {issue.oldValue}
                    </td>
                    <td className="py-3.5 px-4 font-mono text-emerald-300 max-w-[140px] truncate" title={issue.newValue}>
                      {issue.newValue}
                    </td>
                    <td className="py-3.5 px-4 text-slate-400 max-w-[200px] truncate" title={issue.reason}>
                      {issue.reason}
                    </td>
                    <td className="py-3.5 px-4 text-slate-300 max-w-[220px] truncate" title={issue.suggestedCorrection}>
                      {issue.suggestedCorrection}
                    </td>
                    <td className="py-3.5 px-4 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-2" onClick={(e) => e.stopPropagation()}>
                        <button
                          onClick={() => setSelectedIssue(issue)}
                          className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
                          title="Inspect Details"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => toggleResolveIssue(issue.id)}
                          className={`p-1.5 rounded-lg transition-colors ${
                            issue.resolved 
                              ? 'bg-emerald-500/20 text-emerald-300' 
                              : 'bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white'
                          }`}
                          title={issue.resolved ? 'Resolved' : 'Mark Resolved'}
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Footer */}
        <div className="p-4 bg-slate-950/40 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-400">
          <span>
            Showing {((currentPage - 1) * itemsPerPage) + 1} to {Math.min(currentPage * itemsPerPage, filteredIssues.length)} of {filteredIssues.length} issues
          </span>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setCurrentPage(p => Math.max(p - 1, 1))}
              disabled={currentPage === 1}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 disabled:opacity-40 disabled:cursor-not-allowed transition-all"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="font-mono text-slate-200">
              Page {currentPage} of {totalPages}
            </span>
            <button
              onClick={() => setCurrentPage(p => Math.min(p + 1, totalPages))}
              disabled={currentPage === totalPages}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 disabled:opacity-40 disabled:cursor-not-allowed transition-all"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Modal Detail Popup */}
      <IssueDetailModal />
    </div>
  );
};
