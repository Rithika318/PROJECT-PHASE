﻿import React, { useState } from 'react';
import { 
  GitCompare, 
  ArrowRight, 
  FileText, 
  AlertCircle, 
  CheckCircle2, 
  Sparkles, 
  Maximize2,
  Copy,
  Check
} from 'lucide-react';
import { useAnalysis } from '../../context/AnalysisContext';

interface DiffBlock {
  sectionTitle: string;
  category: string;
  oldContent: {
    title: string;
    version: string;
    code: string;
    items: string[];
  };
  newContent: {
    title: string;
    version: string;
    code: string;
    items: string[];
  };
  changeType: 'modified' | 'added' | 'deprecated';
  issueId?: string;
}

export const DocumentComparisonView: React.FC = () => {
  const { oldDoc, newDoc, issues, setSelectedIssue } = useAnalysis();
  const [selectedSection, setSelectedSection] = useState('All');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const diffBlocks: DiffBlock[] = [
    {
      sectionTitle: 'Authentication & Headers',
      category: 'Security & Protocol',
      changeType: 'modified',
      issueId: 'ISS-002',
      oldContent: {
        title: 'OAuth 1.0 & Cookie Sessions',
        version: 'API v1.0',
        code: `Accept-Version: 1.0\nAuthorization: Bearer <oauth_token>\nContent-Type: application/json\nCookie: session_id=<val>`,
        items: [
          'Version: API v1.0 header required',
          'Rate limit: 100 req/min',
          'Session state: Cookie-based stateful sessions',
          'Auth failure: HTTP 400 Bad Request'
        ]
      },
      newContent: {
        title: 'JWT Bearer & Path Versioning',
        version: 'API v2.0',
        code: `Authorization: Bearer <jwt_token>\nContent-Type: application/json; charset=utf-8\nX-Session-Token: <session_uuid>`,
        items: [
          'Version: API v2.0 prefix in URL path',
          'Rate limit: 60 req/min with Tier Bursting',
          'Session state: X-Session-Token header',
          'Auth failure: HTTP 401 Unauthorized (RFC-compliant)'
        ]
      }
    },
    {
      sectionTitle: 'User API Parameter Types',
      category: 'Data Contracts',
      changeType: 'modified',
      issueId: 'ISS-001',
      oldContent: {
        title: 'Integer User Identifier',
        version: 'API v1.0',
        code: `GET /api/v1/users/{id}\n\nParameters:\n- id: integer (Required)\n- avatar_url: string (Optional)`,
        items: [
          'Param "id": integer (Auto-increment)',
          'Field label: "avatar_url"',
          'Management: deleteUser() unavailable in public REST API'
        ]
      },
      newContent: {
        title: 'UUID String User Identifier',
        version: 'API v2.0',
        code: `GET /api/v2/users/{id}\n\nParameters:\n- id: string (Required, UUIDv4)\n- profile_image_url: string (Optional)`,
        items: [
          'Param "id": string (UUIDv4 standard)',
          'Field label: "profile_image_url"',
          'Management: DELETE /api/v2/users/{user_id} added'
        ]
      }
    },
    {
      sectionTitle: 'Search API Parameter Renaming',
      category: 'Query Interface',
      changeType: 'modified',
      issueId: 'ISS-003',
      oldContent: {
        title: 'Abbreviated Query Parameter',
        version: 'API v1.0',
        code: `GET /api/v1/search?q={query}&limit=20&order=asc`,
        items: [
          'Parameter: "q" (string)',
          'Default limit: 20 records',
          'Sorting: "order=asc"'
        ]
      },
      newContent: {
        title: 'Explicit Query Parameter',
        version: 'API v2.0',
        code: `GET /api/v2/search?query={keyword}&limit=25&sort_dir=asc`,
        items: [
          'Parameter: "query" (Full word identifier)',
          'Default limit: 25 records',
          'Sorting: "sort_dir=asc"'
        ]
      }
    },
    {
      sectionTitle: 'Storage & File Upload Quotas',
      category: 'Storage Infrastructure',
      changeType: 'modified',
      issueId: 'ISS-010',
      oldContent: {
        title: 'Legacy 5 MB Quota',
        version: 'API v1.0',
        code: `POST /api/v1/files/upload\nContent-Type: multipart/form-data\nMax-Size: 5 MB`,
        items: [
          'Maximum payload: 5 MB threshold',
          'Checksum: No checksum verification'
        ]
      },
      newContent: {
        title: 'Expanded 10 MB with Checksum',
        version: 'API v2.0',
        code: `POST /api/v2/files/upload\nContent-Type: multipart/form-data\nContent-MD5: <base64_digest>\nMax-Size: 10 MB`,
        items: [
          'Maximum payload: 10 MB threshold',
          'Checksum: Content-MD5 header mandatory for PUT/POST'
        ]
      }
    },
    {
      sectionTitle: 'Payment Gateway & Idempotency',
      category: 'Financial Operations',
      changeType: 'modified',
      issueId: 'ISS-004',
      oldContent: {
        title: 'USD Single-Currency',
        version: 'API v1.0',
        code: `POST /api/v1/charges\nIdempotency-Key: (Optional)`,
        items: [
          'Currency: USD only',
          'Idempotency: Optional header'
        ]
      },
      newContent: {
        title: 'Multi-Currency ISO-4217',
        version: 'API v2.0',
        code: `POST /api/v2/charges\nIdempotency-Key: (Mandatory UUIDv4)`,
        items: [
          'Currency: ISO-4217 (USD, EUR, GBP, JPY)',
          'Idempotency: Mandatory on POST /charges'
        ]
      }
    },
    {
      sectionTitle: 'Webhook Signing Standard',
      category: 'Asynchronous Events',
      changeType: 'modified',
      issueId: 'ISS-005',
      oldContent: {
        title: 'HMAC-MD5 Digest',
        version: 'API v1.0',
        code: `X-Signature: <md5_hex>\nRetries: 3 linear (1m interval)`,
        items: [
          'Algorithm: HMAC-MD5 (Cryptographically weak)',
          'Billing Event: "invoice.created"'
        ]
      },
      newContent: {
        title: 'HMAC-SHA256 Digest',
        version: 'API v2.0',
        code: `X-Signature: <sha256_hex>\nRetries: 5 exponential (2s, 4s, 8s, 16s, 32s)`,
        items: [
          'Algorithm: HMAC-SHA256 (Enforced)',
          'Billing Event: "billing.invoice.generated"'
        ]
      }
    }
  ];

  const sections = ['All', ...new Set(diffBlocks.map(b => b.sectionTitle))];

  const filteredBlocks = selectedSection === 'All' 
    ? diffBlocks 
    : diffBlocks.filter(b => b.sectionTitle === selectedSection);

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1500);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <GitCompare className="w-5 h-5 text-indigo-400" />
            <span>Document Comparison (Side-by-Side Diff)</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Bilateral comparison highlighting breaking contract changes between {oldDoc.name} and {newDoc.name}
          </p>
        </div>

        {/* Legend */}
        <div className="flex items-center gap-3 text-xs font-mono">
          <span className="flex items-center gap-1.5 text-rose-300">
            <span className="w-2.5 h-2.5 rounded bg-rose-500/30 border border-rose-500/60"></span>
            Old / Superseded
          </span>
          <span className="flex items-center gap-1.5 text-emerald-300">
            <span className="w-2.5 h-2.5 rounded bg-emerald-500/30 border border-emerald-500/60"></span>
            New / Active
          </span>
          <span className="flex items-center gap-1.5 text-amber-300">
            <span className="w-2.5 h-2.5 rounded bg-amber-500/30 border border-amber-500/60"></span>
            Inconsistency Flag
          </span>
        </div>
      </div>

      {/* Section Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
        {sections.map((sec, idx) => (
          <button
            key={idx}
            onClick={() => setSelectedSection(sec)}
            className={`px-3 py-1.5 rounded-xl text-xs font-medium shrink-0 transition-all ${
              selectedSection === sec
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/25 border border-indigo-500/40 font-semibold'
                : 'bg-slate-900/80 text-slate-400 hover:text-slate-200 hover:bg-slate-800 border border-slate-800'
            }`}
          >
            {sec}
          </button>
        ))}
      </div>

      {/* Comparative Diff Cards */}
      <div className="space-y-4">
        {filteredBlocks.map((block, idx) => {
          const matchedIssue = issues.find(i => i.id === block.issueId);

          return (
            <div
              key={idx}
              className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800/80 backdrop-blur-md shadow-xl hover:border-indigo-500/40 transition-all"
            >
              {/* Diff Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 mb-4 border-b border-slate-800/80 gap-2">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                      {block.category}
                    </span>
                    <h3 className="text-sm font-bold text-white">
                      {block.sectionTitle}
                    </h3>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {matchedIssue && (
                    <button
                      onClick={() => setSelectedIssue(matchedIssue)}
                      className="px-2.5 py-1 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/40 text-[11px] font-semibold text-rose-300 flex items-center gap-1.5 transition-all"
                    >
                      <AlertCircle className="w-3.5 h-3.5" />
                      <span>{matchedIssue.id}: {matchedIssue.severity} Severity</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Side-by-Side Split View */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                {/* Left: Old Version */}
                <div className="p-4 rounded-xl bg-slate-950/70 border border-rose-500/30 space-y-3 relative overflow-hidden">
                  <div className="absolute top-0 left-0 w-1.5 h-full bg-rose-500/70"></div>
                  <div className="flex items-center justify-between pl-2">
                    <span className="text-xs font-bold text-rose-300 flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-rose-400"></span>
                      Old: {block.oldContent.version}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">
                      {oldDoc.name}
                    </span>
                  </div>

                  <p className="text-xs font-semibold text-slate-200 pl-2">
                    {block.oldContent.title}
                  </p>

                  <div className="relative group">
                    <pre className="p-3 rounded-lg bg-slate-900/90 text-rose-200/90 text-[11px] font-mono overflow-x-auto border border-rose-900/40">
                      {block.oldContent.code}
                    </pre>
                  </div>

                  <ul className="space-y-1 text-xs text-slate-300 pl-2">
                    {block.oldContent.items.map((it, i) => (
                      <li key={i} className="flex items-start gap-1.5">
                        <span className="text-rose-400 font-bold shrink-0">-</span>
                        <span className="line-through decoration-rose-400/60 text-slate-400">{it}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Right: New Version */}
                <div className="p-4 rounded-xl bg-slate-950/70 border border-emerald-500/30 space-y-3 relative overflow-hidden">
                  <div className="absolute top-0 left-0 w-1.5 h-full bg-emerald-500/70"></div>
                  <div className="flex items-center justify-between pl-2">
                    <span className="text-xs font-bold text-emerald-300 flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                      New: {block.newContent.version}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">
                      {newDoc.name}
                    </span>
                  </div>

                  <p className="text-xs font-semibold text-slate-200 pl-2">
                    {block.newContent.title}
                  </p>

                  <div className="relative group">
                    <pre className="p-3 rounded-lg bg-slate-900/90 text-emerald-200/90 text-[11px] font-mono overflow-x-auto border border-emerald-900/40">
                      {block.newContent.code}
                    </pre>
                    <button
                      onClick={() => handleCopy(`new-${idx}`, block.newContent.code)}
                      className="absolute top-2 right-2 p-1.5 rounded-md bg-slate-800 text-slate-300 hover:text-white opacity-0 group-hover:opacity-100 transition-opacity"
                      title="Copy code"
                    >
                      {copiedId === `new-${idx}` ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>

                  <ul className="space-y-1 text-xs text-slate-300 pl-2">
                    {block.newContent.items.map((it, i) => (
                      <li key={i} className="flex items-start gap-1.5">
                        <span className="text-emerald-400 font-bold shrink-0">+</span>
                        <span className="text-emerald-200/90 font-medium">{it}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
