﻿import React from 'react';
import { 
  X, 
  BookOpen, 
  FileUp, 
  Layers, 
  Cpu, 
  ShieldCheck, 
  AlertTriangle, 
  Calculator, 
  FileText,
  ArrowRight,
  CheckCircle2
} from 'lucide-react';
import { useAnalysis } from '../../context/AnalysisContext';

export const HowItWorksModal: React.FC = () => {
  const { isHowItWorksOpen, setIsHowItWorksOpen } = useAnalysis();

  if (!isHowItWorksOpen) return null;

  const steps = [
    {
      num: '1',
      title: 'Upload Documents',
      desc: 'User uploads two versions of technical documentation (PDF, Markdown, HTML, or TXT): Baseline Old Version and Target New Version.',
      icon: FileUp,
      badge: 'Multi-Format Ingest'
    },
    {
      num: '2',
      title: 'Extract Text & Technical Information',
      desc: 'System parses structural text, headings, markdown tables, and code snippets to extract endpoints, function signatures, parameters, data types, and versions.',
      icon: Layers,
      badge: 'AST & Regex Parsing'
    },
    {
      num: '3',
      title: 'Custom NLP Model Analyzes Technical Content',
      desc: 'Our lightweight Transformer NLP model—trained from scratch on 120k technical doc pairs (no OpenAI/Gemini/BERT)—computes self-attention over technical tokens and classifies entity relationships.',
      icon: Cpu,
      badge: 'Trained from Scratch'
    },
    {
      num: '4',
      title: 'Verification Engine Compares Information',
      desc: 'The rule verification layer cross-references extracted doc entities against bilateral document diffs and structured source code AST definitions.',
      icon: ShieldCheck,
      badge: 'Bilateral Cross-Check'
    },
    {
      num: '5',
      title: 'Detect Discrepancy Categories',
      desc: 'Identifies 3 primary failure modes: Inconsistencies (e.g. integer vs string), Outdated Information (e.g. API v1.0 vs v2.0), and Missing Content (e.g. undocumented endpoints).',
      icon: AlertTriangle,
      badge: 'Classification Engine'
    },
    {
      num: '6',
      title: 'Calculate Consistency Score',
      desc: 'Computes a composite metric (e.g. 78% Consistency Index) weighted by severity and entity coverage, generating a granular breakdown of consistent, inconsistent, outdated, and missing content.',
      icon: Calculator,
      badge: 'Mathematical Scorer'
    },
    {
      num: '7',
      title: 'Generate Detailed Report',
      desc: 'Compiles an executive engineering audit report with exact line numbers, failure reasons, and copy-pasteable documentation corrections, ready to download as JSON or print as PDF.',
      icon: FileText,
      badge: 'Audit & Export'
    }
  ];

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-150">
      <div 
        className="w-full max-w-3xl bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-6 border-b border-slate-800 flex items-start justify-between gap-4 bg-slate-950/40">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <BookOpen className="w-4 h-4 text-indigo-400" />
              <span className="text-xs font-mono font-bold text-indigo-400 uppercase tracking-wider">
                System Methodology & Pipeline Walkthrough
              </span>
            </div>
            <h2 className="text-lg font-bold text-white tracking-tight">
              How the Consistency Detection System Works
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Academic 7-Step Pipeline for Technical Documentation Verification
            </p>
          </div>

          <button
            onClick={() => setIsHowItWorksOpen(false)}
            className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body: 7 Steps */}
        <div className="p-6 space-y-4 overflow-y-auto flex-1">
          {steps.map((step, idx) => {
            const Icon = step.icon;
            return (
              <div 
                key={idx}
                className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800/80 hover:border-indigo-500/30 transition-all flex items-start gap-4"
              >
                <div className="w-9 h-9 rounded-xl bg-indigo-600/20 border border-indigo-500/30 text-indigo-300 font-mono font-bold flex items-center justify-center shrink-0 text-sm">
                  {step.num}
                </div>

                <div className="space-y-1 flex-1">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <h3 className="text-sm font-bold text-white flex items-center gap-2">
                      <Icon className="w-4 h-4 text-indigo-400" />
                      <span>{step.title}</span>
                    </h3>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                      {step.badge}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    {step.desc}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/60 flex items-center justify-between">
          <span className="text-xs text-emerald-400 font-mono flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5" />
            Zero External AI API Dependencies
          </span>
          <button
            onClick={() => setIsHowItWorksOpen(false)}
            className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-xs font-semibold text-white transition-colors shadow-md shadow-indigo-600/30"
          >
            Got It
          </button>
        </div>
      </div>
    </div>
  );
};
