﻿import React from 'react';
import { 
  X, 
  Workflow, 
  CheckCircle2, 
  Loader2, 
  Sparkles, 
  FileUp, 
  FileText, 
  Layers, 
  Cpu, 
  Network, 
  ShieldCheck, 
  AlertTriangle, 
  FileCheck,
  Play
} from 'lucide-react';
import { useAnalysis, PIPELINE_STAGES } from '../../context/AnalysisContext';

export const PipelineModal: React.FC = () => {
  const { 
    isPipelineModalOpen, 
    setIsPipelineModalOpen, 
    pipelineProgress, 
    currentPipelineStage, 
    isAnalyzing, 
    runAnalysisSimulation 
  } = useAnalysis();

  if (!isPipelineModalOpen) return null;

  const stageIcons = [
    FileUp,
    FileText,
    Layers,
    Cpu,
    Network,
    ShieldCheck,
    AlertTriangle,
    FileCheck
  ];

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-150">
      <div 
        className="w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-6 border-b border-slate-800 flex items-start justify-between gap-4 bg-slate-950/40">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Workflow className="w-4 h-4 text-indigo-400" />
              <span className="text-xs font-mono font-bold text-indigo-400 uppercase tracking-wider">
                End-to-End Execution Trace
              </span>
            </div>
            <h2 className="text-lg font-bold text-white tracking-tight">
              8-Stage Consistency Verification Pipeline
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Live progression from document ingestion through Custom NLP model to report compilation
            </p>
          </div>

          <button
            onClick={() => setIsPipelineModalOpen(false)}
            className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Progress Ribbon */}
        <div className="px-6 py-3 bg-slate-950/70 border-b border-slate-800 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <span className="text-slate-400">Total Execution Progress:</span>
            <span className="font-mono font-bold text-emerald-400">{pipelineProgress}%</span>
          </div>
          <span className="text-[11px] font-mono text-slate-400">
            {isAnalyzing ? `Processing Stage ${currentPipelineStage} of 8...` : 'All Stages Completed Successfully'}
          </span>
        </div>

        {/* Stages List */}
        <div className="p-6 space-y-3 overflow-y-auto flex-1">
          {PIPELINE_STAGES.map((stage, idx) => {
            const Icon = stageIcons[idx] || Workflow;
            const isCompleted = currentPipelineStage > stage.id || (!isAnalyzing && pipelineProgress === 100);
            const isCurrent = isAnalyzing && currentPipelineStage === stage.id;

            return (
              <div
                key={stage.id}
                className={`p-3.5 rounded-2xl border transition-all flex items-start gap-3.5 ${
                  isCurrent
                    ? 'bg-indigo-950/40 border-indigo-500 shadow-lg shadow-indigo-500/10'
                    : isCompleted
                    ? 'bg-slate-950/60 border-slate-800/90'
                    : 'bg-slate-950/20 border-slate-900 opacity-50'
                }`}
              >
                <div className="mt-0.5 shrink-0">
                  {isCurrent ? (
                    <Loader2 className="w-5 h-5 text-indigo-400 animate-spin" />
                  ) : isCompleted ? (
                    <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                  ) : (
                    <div className="w-5 h-5 rounded-full border border-slate-700 flex items-center justify-center text-[10px] font-mono text-slate-500">
                      {stage.id}
                    </div>
                  )}
                </div>

                <div className="flex-1 space-y-0.5">
                  <div className="flex items-center justify-between">
                    <h3 className={`text-xs font-bold ${isCurrent ? 'text-indigo-300' : 'text-slate-200'}`}>
                      Stage {stage.id}: {stage.title}
                    </h3>
                    {isCurrent && (
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 animate-pulse">
                        RUNNING
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-400">
                    {stage.description}
                  </p>
                  <span className="text-[10px] font-mono text-emerald-400/90 block pt-0.5">
                    → {stage.extractedDetail}
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/60 flex items-center justify-between">
          <button
            onClick={runAnalysisSimulation}
            disabled={isAnalyzing}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300 hover:text-white flex items-center gap-1.5 transition-colors"
          >
            <Play className="w-3 h-3 fill-current" />
            <span>Re-run Pipeline</span>
          </button>

          <button
            onClick={() => setIsPipelineModalOpen(false)}
            className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-xs font-semibold text-white transition-colors shadow-md shadow-indigo-600/30"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
