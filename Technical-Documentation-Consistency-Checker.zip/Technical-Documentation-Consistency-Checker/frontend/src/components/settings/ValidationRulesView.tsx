﻿import React, { useState } from 'react';
import { 
  SlidersHorizontal, 
  ShieldCheck, 
  CheckCircle2, 
  AlertTriangle, 
  Cpu, 
  HardDrive, 
  Lock,
  Save
} from 'lucide-react';
import { useAnalysis } from '../../context/AnalysisContext';

export const ValidationRulesView: React.FC = () => {
  const { rules, toggleRule } = useAnalysis();
  const [saveSuccess, setSaveSuccess] = useState(false);

  const [cpuThreads, setCpuThreads] = useState(4);
  const [attnThreshold, setAttnThreshold] = useState(0.75);
  const [strictTypes, setStrictTypes] = useState(true);

  const handleSaveSettings = () => {
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2000);
  };

  const getSeverityBadge = (sev: string) => {
    switch (sev) {
      case 'High':
        return 'bg-rose-500/15 text-rose-300 border-rose-500/30';
      case 'Medium':
        return 'bg-amber-500/15 text-amber-300 border-amber-500/30';
      default:
        return 'bg-slate-500/15 text-slate-300 border-slate-500/30';
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <SlidersHorizontal className="w-5 h-5 text-indigo-400" />
            <span>Consistency Engine Rules & Local Model Settings</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Configure automated consistency validation rules and local CPU inference parameters
          </p>
        </div>

        <button
          onClick={handleSaveSettings}
          className="px-4 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-xs font-semibold text-white flex items-center gap-1.5 shadow-md shadow-indigo-600/30 transition-all"
        >
          {saveSuccess ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> : <Save className="w-3.5 h-3.5" />}
          <span>{saveSuccess ? 'Preferences Saved!' : 'Save Rule Config'}</span>
        </button>
      </div>

      {/* Validation Rules List */}
      <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800/80 backdrop-blur-md shadow-xl space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              Predefined Consistency Verification Rules
            </h3>
            <p className="text-xs text-slate-400">
              Active heuristic and neural rules evaluated during cross-document parsing
            </p>
          </div>
          <span className="text-xs font-mono text-indigo-400 font-bold">
            {rules.filter(r => r.enabled).length} of {rules.length} Rules Enabled
          </span>
        </div>

        <div className="space-y-3 pt-2">
          {rules.map((rule) => (
            <div
              key={rule.id}
              className={`p-4 rounded-xl border transition-all flex flex-col md:flex-row md:items-center justify-between gap-4 ${
                rule.enabled 
                  ? 'bg-slate-950/70 border-slate-800 hover:border-slate-700' 
                  : 'bg-slate-950/30 border-slate-900 opacity-60'
              }`}
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-xs font-bold text-indigo-300">
                    {rule.id}
                  </span>
                  <span className="text-xs font-bold text-white">
                    {rule.name}
                  </span>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${getSeverityBadge(rule.severity)}`}>
                    {rule.severity}
                  </span>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed max-w-2xl">
                  {rule.description}
                </p>
                <div className="text-[10px] text-slate-500 font-mono">
                  Target Entity: <span className="text-slate-300">{rule.targetEntity}</span>
                </div>
              </div>

              {/* Toggle Switch */}
              <div className="flex items-center gap-3 shrink-0">
                <span className="text-xs font-medium text-slate-400">
                  {rule.enabled ? 'Active' : 'Disabled'}
                </span>
                <button
                  type="button"
                  onClick={() => toggleRule(rule.id)}
                  className={`w-11 h-6 rounded-full transition-colors relative focus:outline-none ${
                    rule.enabled ? 'bg-indigo-600' : 'bg-slate-800'
                  }`}
                >
                  <span
                    className={`block w-4 h-4 rounded-full bg-white transition-transform transform ${
                      rule.enabled ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Local Model Inference & Hardware Config */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Model Execution Settings */}
        <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800/80 backdrop-blur-md shadow-xl space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-800">
            <Cpu className="w-4 h-4 text-indigo-400" />
            <h3 className="text-sm font-bold text-white">
              Local Model Runtime Parameters
            </h3>
          </div>

          <div className="space-y-4 text-xs">
            <div>
              <div className="flex justify-between mb-1">
                <span className="text-slate-300 font-medium">CPU Parallel Workers</span>
                <span className="font-mono text-indigo-400 font-bold">{cpuThreads} Threads</span>
              </div>
              <input
                type="range"
                min={1}
                max={16}
                value={cpuThreads}
                onChange={(e) => setCpuThreads(Number(e.target.value))}
                className="w-full accent-indigo-500"
              />
            </div>

            <div>
              <div className="flex justify-between mb-1">
                <span className="text-slate-300 font-medium">Self-Attention Decision Threshold</span>
                <span className="font-mono text-emerald-400 font-bold">{attnThreshold}</span>
              </div>
              <input
                type="range"
                min={0.5}
                max={0.95}
                step={0.05}
                value={attnThreshold}
                onChange={(e) => setAttnThreshold(Number(e.target.value))}
                className="w-full accent-emerald-500"
              />
            </div>

            <div className="pt-2 flex items-center justify-between">
              <div>
                <span className="text-slate-200 font-medium block">Strict Parameter Type Casting</span>
                <span className="text-[11px] text-slate-500">Flag implicit casts (e.g., int to float) as discrepancies</span>
              </div>
              <button
                type="button"
                onClick={() => setStrictTypes(!strictTypes)}
                className={`w-11 h-6 rounded-full transition-colors relative ${strictTypes ? 'bg-emerald-600' : 'bg-slate-800'}`}
              >
                <span
                  className={`block w-4 h-4 rounded-full bg-white transition-transform transform ${
                    strictTypes ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>
          </div>
        </div>

        {/* Security & Offline Compliance Card */}
        <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800/80 backdrop-blur-md shadow-xl space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-800">
            <Lock className="w-4 h-4 text-emerald-400" />
            <h3 className="text-sm font-bold text-white">
              Strict Project Constraints Verification
            </h3>
          </div>

          <div className="space-y-3 text-xs">
            <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center justify-between">
              <span className="text-slate-300">External AI APIs (OpenAI/Gemini/Claude)</span>
              <span className="text-emerald-400 font-mono font-bold flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> 0% Network Outbound
              </span>
            </div>

            <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center justify-between">
              <span className="text-slate-300">Pre-trained Checkpoints</span>
              <span className="text-emerald-400 font-mono font-bold flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> 0% (Trained from scratch)
              </span>
            </div>

            <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center justify-between">
              <span className="text-slate-300">Local Weight Store</span>
              <span className="text-indigo-400 font-mono font-bold">
                ./ml/weights/transformer_v1.pt
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
