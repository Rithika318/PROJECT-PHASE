﻿import React, { useState } from 'react';
import { 
  Code2, 
  CheckCircle2, 
  AlertTriangle, 
  HelpCircle, 
  Clock, 
  Terminal, 
  ArrowRight,
  GitBranch,
  Search
} from 'lucide-react';
import { useAnalysis } from '../../context/AnalysisContext';

export const AstVerificationView: React.FC = () => {
  const { astDefinitions, setActiveTab } = useAnalysis();
  const [filterStatus, setFilterStatus] = useState<string>('All');
  const [searchTerm, setSearchTerm] = useState<string>('');

  const filteredAst = astDefinitions.filter((item) => {
    const matchesSearch = !searchTerm || 
      item.functionName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.endpoint.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.apiVersion.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = filterStatus === 'All' || item.docStatus === filterStatus;
    return matchesSearch && matchesStatus;
  });

  const getDocStatusBadge = (status: string) => {
    switch (status) {
      case 'Consistent':
        return 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30';
      case 'Mismatch':
        return 'bg-rose-500/15 text-rose-300 border-rose-500/30';
      case 'Outdated':
        return 'bg-amber-500/15 text-amber-300 border-amber-500/30';
      case 'Missing':
        return 'bg-blue-500/15 text-blue-300 border-blue-500/30';
      default:
        return 'bg-slate-500/15 text-slate-300 border-slate-500/30';
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <Code2 className="w-5 h-5 text-indigo-400" />
            <span>Source Code / AST Verification Engine</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Compares live codebase Abstract Syntax Tree (AST) definitions against technical documentation specifications
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <span className="px-2.5 py-1 rounded-lg bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 font-medium">
            1 Consistent
          </span>
          <span className="px-2.5 py-1 rounded-lg bg-rose-500/15 border border-rose-500/30 text-rose-300 font-medium">
            4 Mismatches
          </span>
          <span className="px-2.5 py-1 rounded-lg bg-amber-500/15 border border-amber-500/30 text-amber-300 font-medium">
            2 Outdated
          </span>
          <span className="px-2.5 py-1 rounded-lg bg-blue-500/15 border border-blue-500/30 text-blue-300 font-medium">
            1 Missing
          </span>
        </div>
      </div>

      {/* AST Parser Concept Callout */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-slate-900 via-indigo-950/30 to-slate-900 border border-slate-800/80 backdrop-blur-md shadow-md flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <GitBranch className="w-4 h-4 text-emerald-400" />
            <h3 className="text-xs font-bold text-white uppercase tracking-wider">
              Bilateral Verification: Source AST vs Document Extracted Entities
            </h3>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            The system parses source code files (TypeScript/Python/Go) into Abstract Syntax Trees, extracting declared parameters, types, and return models. It then validates whether documentation guarantees match the actual code reality.
          </p>
        </div>

        <div className="px-4 py-2.5 rounded-xl bg-slate-950/70 border border-slate-800 text-[11px] font-mono text-slate-300 shrink-0">
          <span>Git Branch: <span className="text-emerald-400 font-bold">main @ v2.0.1</span></span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-4 rounded-2xl bg-slate-900/80 border border-slate-800/80">
        <div className="relative w-full sm:w-80">
          <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search function, endpoint, or version..."
            className="w-full pl-9 pr-3 py-1.5 rounded-xl bg-slate-950/60 border border-slate-800 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500"
          />
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto">
          {['All', 'Consistent', 'Mismatch', 'Outdated', 'Missing'].map((status) => (
            <button
              key={status}
              onClick={() => setFilterStatus(status)}
              className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all ${
                filterStatus === status
                  ? 'bg-indigo-600 text-white font-semibold shadow-md shadow-indigo-600/20'
                  : 'bg-slate-800/60 text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              {status}
            </button>
          ))}
        </div>
      </div>

      {/* AST Verification Table */}
      <div className="rounded-2xl bg-slate-900/80 border border-slate-800/80 backdrop-blur-md shadow-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950/60 text-slate-400 text-[11px] uppercase tracking-wider font-semibold border-b border-slate-800">
              <tr>
                <th className="py-3.5 px-4">Function / AST Signature</th>
                <th className="py-3.5 px-4">API Endpoint</th>
                <th className="py-3.5 px-4">Parameters & Data Type</th>
                <th className="py-3.5 px-4">API Version</th>
                <th className="py-3.5 px-4">Code Status</th>
                <th className="py-3.5 px-4">Doc Verification</th>
                <th className="py-3.5 px-4">AST Mismatch Analysis</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/50">
              {filteredAst.map((ast) => (
                <tr key={ast.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-3.5 px-4 font-mono font-bold text-indigo-300">
                    <div className="flex items-center gap-1.5">
                      <Terminal className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                      <span>{ast.functionName}</span>
                    </div>
                  </td>
                  <td className="py-3.5 px-4 font-mono text-slate-200">
                    <span className="px-1.5 py-0.5 rounded bg-slate-800 text-[10px] text-indigo-300 font-bold mr-1.5">
                      {ast.httpMethod}
                    </span>
                    {ast.endpoint}
                  </td>
                  <td className="py-3.5 px-4">
                    <div className="space-y-1">
                      {ast.parameters.length === 0 ? (
                        <span className="text-slate-500 italic">None</span>
                      ) : (
                        ast.parameters.map((p, idx) => (
                          <div key={idx} className="font-mono text-[11px]">
                            <span className="text-white font-semibold">{p.name}: </span>
                            <span className="text-emerald-400">{p.type}</span>
                            {p.required && <span className="text-rose-400 ml-1 text-[10px]">*</span>}
                          </div>
                        ))
                      )}
                    </div>
                  </td>
                  <td className="py-3.5 px-4 font-mono font-bold text-slate-300">
                    {ast.apiVersion}
                  </td>
                  <td className="py-3.5 px-4">
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                      {ast.codeStatus}
                    </span>
                  </td>
                  <td className="py-3.5 px-4">
                    <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${getDocStatusBadge(ast.docStatus)}`}>
                      {ast.docStatus}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-slate-300 max-w-xs leading-relaxed text-[11px]">
                    {ast.docMismatchReason}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
