﻿import React from 'react';
import { 
  ArrowRight, 
  AlertTriangle, 
  CheckCircle2, 
  Clock, 
  Sparkles,
  GitCompare,
  FileUp,
  Activity,
  Workflow
} from 'lucide-react';
import { useAnalysis } from '../../context/AnalysisContext';
import { MetricCards } from './MetricCards';
import { ConsistencyScoreGauge } from './ConsistencyScoreGauge';
import { PipelineStatusWidget } from './PipelineStatusWidget';

export const DashboardOverview: React.FC = () => {
  const { issues, setActiveTab, setSelectedIssue, setIsPipelineModalOpen } = useAnalysis();

  const topIssues = issues.slice(0, 5);

  const getSeverityBadge = (sev: string) => {
    switch (sev) {
      case 'High':
        return 'bg-rose-500/15 text-rose-300 border-rose-500/30';
      case 'Medium':
        return 'bg-amber-500/15 text-amber-300 border-amber-500/30';
      default:
        return 'bg-slate-500/15 text-slate-300 border-slate-500/30';
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-white tracking-tight">
              Dashboard Overview
            </h1>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              Live Audit Active
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Real-time consistency audit comparing <span className="text-slate-200 font-mono">CloudCore_Platform_API_v1.0.md</span> vs <span className="text-slate-200 font-mono">v2.0.md</span>
          </p>
        </div>

        {/* Quick Shortcut Buttons */}
        <div className="flex items-center gap-2.5">
          <button
            onClick={() => setActiveTab('documents')}
            className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700/80 border border-slate-700/80 text-xs font-semibold text-slate-200 hover:text-white flex items-center gap-1.5 transition-all shadow-sm"
          >
            <FileUp className="w-3.5 h-3.5 text-indigo-400" />
            <span>Upload Docs</span>
          </button>
          <button
            onClick={() => setActiveTab('compare')}
            className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700/80 border border-slate-700/80 text-xs font-semibold text-slate-200 hover:text-white flex items-center gap-1.5 transition-all shadow-sm"
          >
            <GitCompare className="w-3.5 h-3.5 text-emerald-400" />
            <span>Side-by-Side Diff</span>
          </button>
          <button
            onClick={() => setIsPipelineModalOpen(true)}
            className="px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-xs font-semibold text-white flex items-center gap-1.5 shadow-md shadow-indigo-600/30 transition-all"
          >
            <Workflow className="w-3.5 h-3.5" />
            <span>View Pipeline</span>
          </button>
        </div>
      </div>

      {/* Metric Cards */}
      <MetricCards />

      {/* Main Row: Consistency Score Gauge & Model Architecture Widget */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <ConsistencyScoreGauge />
        <PipelineStatusWidget />
      </div>

      {/* Pipeline 8-Stage Architecture Flow Ribbon */}
      <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800/80 backdrop-blur-md shadow-md">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Activity className="w-4 h-4 text-indigo-400" />
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">
              End-to-End Processing Pipeline Architecture
            </h4>
          </div>
          <button
            onClick={() => setIsPipelineModalOpen(true)}
            className="text-[11px] text-indigo-400 hover:underline flex items-center gap-1"
          >
            <span>Stage Diagnostics</span>
            <ArrowRight className="w-3 h-3" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2">
          {[
            { step: '01', name: 'Document Upload', sub: 'PDF, MD, HTML' },
            { step: '02', name: 'Text Extraction', sub: 'Multi-format' },
            { step: '03', name: 'AST Parsing', sub: 'Code & Params' },
            { step: '04', name: 'NLP Model', sub: 'Custom Transformer' },
            { step: '05', name: 'Tech Info Extract', sub: 'Entities & Types' },
            { step: '06', name: 'Consistency Engine', sub: 'Rule Verification' },
            { step: '07', name: 'Issue Detection', sub: '37 Discrepancies' },
            { step: '08', name: 'Report & Score', sub: '78% Index' },
          ].map((item, idx) => (
            <div
              key={idx}
              className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800/90 text-center relative overflow-hidden group hover:border-indigo-500/40 transition-colors"
            >
              <span className="text-[9px] font-mono font-bold text-indigo-400 block mb-0.5">
                {item.step}
              </span>
              <p className="text-[11px] font-semibold text-slate-200 leading-tight">
                {item.name}
              </p>
              <span className="text-[9px] text-slate-500 mt-0.5 block truncate">
                {item.sub}
              </span>
              <div className="mt-1.5 flex items-center justify-center">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Critical Detected Issues Preview Table */}
      <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800/80 backdrop-blur-md shadow-xl">
        <div className="flex items-center justify-between pb-4 border-b border-slate-800/60">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-400" />
              Highest Priority Detected Discrepancies
            </h3>
            <p className="text-xs text-slate-400">
              Sample of breaking changes detected by the Custom NLP Transformer Model
            </p>
          </div>
          <button
            onClick={() => setActiveTab('issues')}
            className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 flex items-center gap-1 transition-colors"
          >
            <span>View All {issues.length} Issues</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="mt-4 overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-800/80 text-slate-400 text-[11px] uppercase tracking-wider font-semibold">
                <th className="pb-3 font-semibold">Issue ID</th>
                <th className="pb-3 font-semibold">Section</th>
                <th className="pb-3 font-semibold">Type</th>
                <th className="pb-3 font-semibold">Severity</th>
                <th className="pb-3 font-semibold">Old Value</th>
                <th className="pb-3 font-semibold">New Value</th>
                <th className="pb-3 font-semibold text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/50">
              {topIssues.map((issue) => (
                <tr
                  key={issue.id}
                  className="hover:bg-slate-800/40 transition-colors group cursor-pointer"
                  onClick={() => setSelectedIssue(issue)}
                >
                  <td className="py-3 font-mono text-indigo-300 font-semibold">
                    {issue.id}
                  </td>
                  <td className="py-3 font-medium text-slate-200">
                    {issue.section}
                  </td>
                  <td className="py-3 text-slate-300">
                    {issue.type}
                  </td>
                  <td className="py-3">
                    <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold border ${getSeverityBadge(issue.severity)}`}>
                      {issue.severity}
                    </span>
                  </td>
                  <td className="py-3 font-mono text-rose-400/90 max-w-[120px] truncate">
                    {issue.oldValue}
                  </td>
                  <td className="py-3 font-mono text-emerald-400/90 max-w-[120px] truncate">
                    {issue.newValue}
                  </td>
                  <td className="py-3 text-right">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedIssue(issue);
                      }}
                      className="px-2.5 py-1 rounded-md bg-indigo-600/20 hover:bg-indigo-600 text-indigo-300 hover:text-white border border-indigo-500/30 text-[11px] font-medium transition-all"
                    >
                      Inspect
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
