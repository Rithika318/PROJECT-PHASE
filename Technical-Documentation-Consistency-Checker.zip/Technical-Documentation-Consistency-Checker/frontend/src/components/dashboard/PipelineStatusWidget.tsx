﻿import React from 'react';
import { 
  Cpu, 
  Database, 
  Workflow, 
  ShieldCheck, 
  Play, 
  ArrowRight,
  CheckCircle2
} from 'lucide-react';
import { useAnalysis } from '../../context/AnalysisContext';

export const PipelineStatusWidget: React.FC = () => {
  const { runAnalysisSimulation, isAnalyzing, setActiveTab } = useAnalysis();

  return (
    <div className="p-6 rounded-2xl bg-gradient-to-br from-slate-900/90 via-indigo-950/30 to-slate-900/90 border border-slate-800/80 backdrop-blur-md shadow-xl flex flex-col justify-between">
      <div>
        <div className="flex items-center justify-between pb-4 border-b border-slate-800/60">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center">
              <Cpu className="w-4 h-4 text-indigo-400" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">
                Custom NLP Transformer Engine
              </h3>
              <p className="text-xs text-slate-400">
                Lightweight model trained from scratch on technical documentation
              </p>
            </div>
          </div>
          <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
            OFFLINE READY
          </span>
        </div>

        {/* Technical Highlights */}
        <div className="grid grid-cols-2 gap-3 my-4">
          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 text-xs">
            <span className="text-[10px] text-slate-400 font-medium">Training Paradigm</span>
            <p className="text-slate-200 font-semibold mt-0.5">Trained from Scratch</p>
            <span className="text-[10px] text-emerald-400 flex items-center gap-1 mt-1">
              <CheckCircle2 className="w-3 h-3 inline" /> Zero Pre-trained Weights
            </span>
          </div>

          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 text-xs">
            <span className="text-[10px] text-slate-400 font-medium">Dataset Composition</span>
            <p className="text-slate-200 font-semibold mt-0.5">Technical Specs Corpus</p>
            <span className="text-[10px] text-indigo-400 font-mono mt-1 block">
              120,000 Pairwise Tokens
            </span>
          </div>

          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 text-xs">
            <span className="text-[10px] text-slate-400 font-medium">Layer Stack</span>
            <p className="text-slate-200 font-semibold mt-0.5">4-Layer Multi-Head Self-Attn</p>
            <span className="text-[10px] text-slate-400 font-mono mt-1 block">
              dim: 128 | heads: 4
            </span>
          </div>

          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 text-xs">
            <span className="text-[10px] text-slate-400 font-medium">Cloud Dependencies</span>
            <p className="text-emerald-400 font-semibold mt-0.5">0% (Strictly Offline)</p>
            <span className="text-[10px] text-slate-400 font-mono mt-1 block">
              Local CPU & AST Evaluator
            </span>
          </div>
        </div>
      </div>

      <div className="pt-4 border-t border-slate-800/60 flex items-center justify-between">
        <button
          onClick={() => setActiveTab('ai-analysis')}
          className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 flex items-center gap-1.5 transition-colors"
        >
          <span>Inspect Architecture & Attention</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>

        <button
          onClick={runAnalysisSimulation}
          disabled={isAnalyzing}
          className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center gap-1.5 shadow-md shadow-indigo-600/30 transition-all"
        >
          <Play className="w-3 h-3 fill-current" />
          <span>Simulate Pipeline</span>
        </button>
      </div>
    </div>
  );
};
