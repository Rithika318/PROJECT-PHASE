﻿import React from 'react';
import { 
  FileText, 
  AlertTriangle, 
  ShieldAlert, 
  AlertCircle, 
  Info, 
  Clock,
  CheckCircle,
  TrendingDown
} from 'lucide-react';
import { useAnalysis } from '../../context/AnalysisContext';

export const MetricCards: React.FC = () => {
  const { issues } = useAnalysis();

  const totalAnalyzed = 24;
  const totalIssues = issues.length;
  const highCount = issues.filter(i => i.severity === 'High').length;
  const medCount = issues.filter(i => i.severity === 'Medium').length;
  const lowCount = issues.filter(i => i.severity === 'Low').length;
  const lastDate = 'Sep 15, 2026 • 10:15 AM';

  const cards = [
    {
      title: 'Total Docs Analyzed',
      value: totalAnalyzed,
      subtext: 'API Specs, Markdown & PDFs',
      icon: FileText,
      color: 'from-blue-500/20 to-blue-600/10 border-blue-500/30 text-blue-400',
      badge: '+3 today'
    },
    {
      title: 'Total Issues Detected',
      value: totalIssues,
      subtext: 'Inconsistencies & gaps',
      icon: AlertTriangle,
      color: 'from-amber-500/20 to-amber-600/10 border-amber-500/30 text-amber-400',
      badge: 'Needs Review'
    },
    {
      title: 'High Severity Issues',
      value: highCount,
      subtext: 'Breaking contract changes',
      icon: ShieldAlert,
      color: 'from-rose-500/20 to-rose-600/10 border-rose-500/30 text-rose-400',
      badge: 'Critical',
      highlight: true
    },
    {
      title: 'Medium Severity',
      value: medCount,
      subtext: 'Missing & outdated params',
      icon: AlertCircle,
      color: 'from-orange-500/20 to-orange-600/10 border-orange-500/30 text-orange-400',
      badge: 'Moderate'
    },
    {
      title: 'Low Severity',
      value: lowCount,
      subtext: 'Terminology & formatting',
      icon: Info,
      color: 'from-slate-500/20 to-slate-600/10 border-slate-500/30 text-slate-400',
      badge: 'Minor'
    },
    {
      title: 'Last Analysis Date',
      value: lastDate,
      subtext: 'Auto-triggered by AST pipeline',
      icon: Clock,
      color: 'from-indigo-500/20 to-indigo-600/10 border-indigo-500/30 text-indigo-400',
      isDate: true
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-3.5">
      {cards.map((card, idx) => {
        const Icon = card.icon;
        return (
          <div
            key={idx}
            className={`p-4 rounded-2xl bg-gradient-to-br ${card.color} border backdrop-blur-md transition-all duration-200 hover:-translate-y-0.5 hover:shadow-lg`}
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] font-medium text-slate-400 truncate">
                {card.title}
              </span>
              <Icon className="w-4 h-4 shrink-0" />
            </div>

            <div className="flex items-baseline gap-2">
              <span className={`${card.isDate ? 'text-xs font-semibold text-slate-200 pt-1' : 'text-2xl font-bold tracking-tight text-white'}`}>
                {card.value}
              </span>
              {card.badge && (
                <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-full ${
                  card.highlight ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40' : 'bg-slate-800 text-slate-300'
                }`}>
                  {card.badge}
                </span>
              )}
            </div>

            <p className="text-[10px] text-slate-400 mt-1 truncate">
              {card.subtext}
            </p>
          </div>
        );
      })}
    </div>
  );
};
