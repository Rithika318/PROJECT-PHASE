﻿import React from 'react';
import { CheckCircle2, AlertTriangle, Clock, HelpCircle, ShieldCheck } from 'lucide-react';

export const ConsistencyScoreGauge: React.FC = () => {
  const score = 78;
  const radius = 68;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (score / 100) * circumference;

  const breakdown = [
    { label: 'Consistent Content', value: 78, color: 'bg-emerald-500', textColor: 'text-emerald-400', icon: CheckCircle2 },
    { label: 'Inconsistent Content', value: 12, color: 'bg-rose-500', textColor: 'text-rose-400', icon: AlertTriangle },
    { label: 'Outdated Information', value: 6, color: 'bg-amber-500', textColor: 'text-amber-400', icon: Clock },
    { label: 'Missing Content', value: 4, color: 'bg-blue-500', textColor: 'text-blue-400', icon: HelpCircle },
  ];

  return (
    <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800/80 backdrop-blur-md shadow-xl flex flex-col justify-between">
      <div className="flex items-center justify-between pb-4 border-b border-slate-800/60">
        <div>
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            Consistency Verification Index
          </h3>
          <p className="text-xs text-slate-400">
            Calculated by Custom NLP Model & Rule Engine
          </p>
        </div>
        <span className="px-2.5 py-1 rounded-full text-[11px] font-semibold bg-emerald-500/10 text-emerald-300 border border-emerald-500/30">
          Grade: B+ (Good)
        </span>
      </div>

      <div className="py-6 flex flex-col sm:flex-row items-center justify-around gap-6">
        {/* Large Circular Gauge */}
        <div className="relative flex items-center justify-center shrink-0">
          <svg className="w-44 h-44 -rotate-90 transform" viewBox="0 0 160 160">
            {/* Background Circle */}
            <circle
              cx="80"
              cy="80"
              r={radius}
              stroke="currentColor"
              strokeWidth="12"
              className="text-slate-800"
              fill="transparent"
            />
            {/* Progress Circle */}
            <circle
              cx="80"
              cy="80"
              r={radius}
              stroke="url(#scoreGradient)"
              strokeWidth="12"
              strokeDasharray={circumference}
              strokeDashoffset={strokeDashoffset}
              strokeLinecap="round"
              fill="transparent"
              className="transition-all duration-1000 ease-out"
            />
            <defs>
              <linearGradient id="scoreGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#10b981" />
                <stop offset="60%" stopColor="#6366f1" />
                <stop offset="100%" stopColor="#8b5cf6" />
              </linearGradient>
            </defs>
          </svg>

          {/* Center Text */}
          <div className="absolute flex flex-col items-center justify-center text-center">
            <span className="text-4xl font-extrabold text-white tracking-tight">
              {score}<span className="text-2xl text-indigo-400 font-semibold">%</span>
            </span>
            <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 mt-0.5">
              Overall Score
            </span>
          </div>
        </div>

        {/* Breakdown bars */}
        <div className="w-full max-w-xs space-y-3">
          {breakdown.map((item, idx) => {
            const Icon = item.icon;
            return (
              <div key={idx} className="space-y-1">
                <div className="flex items-center justify-between text-xs font-medium">
                  <span className="text-slate-300 flex items-center gap-1.5">
                    <Icon className={`w-3.5 h-3.5 ${item.textColor}`} />
                    {item.label}
                  </span>
                  <span className={`font-mono font-bold ${item.textColor}`}>
                    {item.value}%
                  </span>
                </div>
                <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
                  <div
                    className={`h-full rounded-full ${item.color} transition-all duration-700`}
                    style={{ width: `${item.value}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="pt-3 border-t border-slate-800/60 flex items-center justify-between text-[11px] text-slate-400">
        <span>Dataset Baseline: 120,000 Technical Pairs</span>
        <span className="text-indigo-400 font-mono">Formula: (Valid Tokens / Total Entities) * 100</span>
      </div>
    </div>
  );
};
