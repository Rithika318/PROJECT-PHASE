﻿import React, { useState } from 'react';
import { 
  Network, 
  Layers, 
  ArrowRight, 
  CheckCircle2, 
  AlertTriangle, 
  Clock, 
  HelpCircle,
  Sparkles,
  Search,
  Filter
} from 'lucide-react';

interface GraphBranch {
  api: string;
  endpoints: {
    name: string;
    method: string;
    status: 'consistent' | 'inconsistent' | 'outdated' | 'missing';
    parameters: {
      name: string;
      dataType: string;
      version: string;
      status: 'consistent' | 'inconsistent' | 'outdated' | 'missing';
      note: string;
    }[];
  }[];
}

export const KnowledgeGraphView: React.FC = () => {
  const [selectedBranchIdx, setSelectedBranchIdx] = useState(0);
  const [activeNode, setActiveNode] = useState<any>(null);

  const graphData: GraphBranch[] = [
    {
      api: 'CloudCore User & Identity API',
      endpoints: [
        {
          name: '/api/v2/users/{id}',
          method: 'GET',
          status: 'inconsistent',
          parameters: [
            { name: 'id', dataType: 'string (UUIDv4)', version: 'v2.0', status: 'inconsistent', note: 'Documented as integer in v1.0, requires string in v2.0' },
            { name: 'profile_image_url', dataType: 'string (URL)', version: 'v2.0', status: 'outdated', note: 'Renamed from avatar_url in v1.0' }
          ]
        },
        {
          name: '/api/v2/users/{user_id}',
          method: 'DELETE',
          status: 'missing',
          parameters: [
            { name: 'user_id', dataType: 'string', version: 'v2.0', status: 'missing', note: 'Endpoint completely missing from public v1.0 documentation' }
          ]
        },
        {
          name: '/v2/auth/token',
          method: 'POST',
          status: 'outdated',
          parameters: [
            { name: 'grant_type', dataType: 'string', version: 'v2.0', status: 'consistent', note: 'Validated JWT token exchange' },
            { name: 'Authorization', dataType: 'Bearer JWT', version: 'v2.0', status: 'outdated', note: 'Docs reference deprecated OAuth 1.0 handshake' }
          ]
        }
      ]
    },
    {
      api: 'CloudCore Payment & Billing API',
      endpoints: [
        {
          name: '/api/v2/charges',
          method: 'POST',
          status: 'inconsistent',
          parameters: [
            { name: 'currency', dataType: 'ISO-4217 code', version: 'v2.0', status: 'inconsistent', note: 'Docs claim USD only, AST accepts multicurrency' },
            { name: 'Idempotency-Key', dataType: 'UUID string', version: 'v2.0', status: 'inconsistent', note: 'Mandatory in backend, documented as optional' }
          ]
        },
        {
          name: '/v2/webhooks/listener',
          method: 'POST',
          status: 'outdated',
          parameters: [
            { name: 'X-Signature', dataType: 'HMAC-SHA256 hex', version: 'v2.0', status: 'outdated', note: 'Upgraded to SHA-256; docs still describe MD5' }
          ]
        }
      ]
    },
    {
      api: 'CloudCore Search & Catalog API',
      endpoints: [
        {
          name: '/api/v2/search',
          method: 'GET',
          status: 'inconsistent',
          parameters: [
            { name: 'query', dataType: 'string', version: 'v2.0', status: 'inconsistent', note: 'Renamed from q to query' },
            { name: 'limit', dataType: 'integer (default 25)', version: 'v2.0', status: 'consistent', note: 'Aligned with UI card grid' },
            { name: 'sort_dir', dataType: 'asc | desc', version: 'v2.0', status: 'consistent', note: 'Sorting direction parameter' }
          ]
        }
      ]
    }
  ];

  const currentApi = graphData[selectedBranchIdx];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'consistent':
        return 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40';
      case 'inconsistent':
        return 'bg-rose-500/20 text-rose-300 border-rose-500/40';
      case 'outdated':
        return 'bg-amber-500/20 text-amber-300 border-amber-500/40';
      case 'missing':
        return 'bg-blue-500/20 text-blue-300 border-blue-500/40';
      default:
        return 'bg-slate-500/20 text-slate-300 border-slate-500/40';
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <Network className="w-5 h-5 text-indigo-400" />
            <span>Knowledge Graph & Structured Information Architecture</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Visual relational entity hierarchy: <span className="text-indigo-300 font-mono">API ➔ Endpoint ➔ Parameter ➔ Data Type ➔ Version</span>
          </p>
        </div>

        {/* Legend */}
        <div className="flex items-center gap-3 text-xs font-mono">
          <span className="flex items-center gap-1.5 text-emerald-300">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400"></span> Consistent
          </span>
          <span className="flex items-center gap-1.5 text-rose-300">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-400"></span> Mismatch
          </span>
          <span className="flex items-center gap-1.5 text-amber-300">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-400"></span> Outdated
          </span>
          <span className="flex items-center gap-1.5 text-blue-300">
            <span className="w-2.5 h-2.5 rounded-full bg-blue-400"></span> Missing
          </span>
        </div>
      </div>

      {/* API Branch Selector Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2">
        {graphData.map((branch, idx) => (
          <button
            key={idx}
            onClick={() => setSelectedBranchIdx(idx)}
            className={`px-3.5 py-2 rounded-xl text-xs font-medium transition-all ${
              selectedBranchIdx === idx
                ? 'bg-indigo-600 text-white font-semibold shadow-md shadow-indigo-600/30'
                : 'bg-slate-900/80 text-slate-400 hover:text-white hover:bg-slate-800 border border-slate-800'
            }`}
          >
            {branch.api}
          </button>
        ))}
      </div>

      {/* Relational Graph Canvas / Flow View */}
      <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800/80 backdrop-blur-md shadow-xl">
        <div className="flex items-center justify-between pb-4 mb-6 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-indigo-500 animate-ping"></div>
            <h2 className="text-sm font-bold text-white">
              Root Node: {currentApi.api}
            </h2>
          </div>
          <span className="text-xs text-slate-400 font-mono">
            {currentApi.endpoints.length} Endpoints Mapped
          </span>
        </div>

        {/* Hierarchy Tree */}
        <div className="space-y-6">
          {currentApi.endpoints.map((ep, epIdx) => (
            <div
              key={epIdx}
              className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 hover:border-indigo-500/40 transition-all space-y-4"
            >
              {/* Endpoint Level Node */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <span className="px-2 py-1 rounded bg-slate-800 font-mono font-bold text-xs text-indigo-300">
                    {ep.method}
                  </span>
                  <span className="font-mono text-sm font-bold text-white">
                    {ep.name}
                  </span>
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${getStatusColor(ep.status)}`}>
                    {ep.status}
                  </span>
                </div>

                <span className="text-[11px] text-slate-500 font-mono">
                  {ep.parameters.length} Parameters Associated
                </span>
              </div>

              {/* Connected Parameters -> Types -> Version Flow */}
              <div className="pl-4 border-l-2 border-slate-800 space-y-3">
                {ep.parameters.map((param, pIdx) => (
                  <div
                    key={pIdx}
                    onClick={() => setActiveNode(param)}
                    className="p-3 rounded-lg bg-slate-900/90 border border-slate-800/80 hover:border-slate-700 cursor-pointer transition-all flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs"
                  >
                    {/* Node Connection Flow Chain */}
                    <div className="flex items-center flex-wrap gap-2 font-mono">
                      <span className="text-slate-400">Parameter:</span>
                      <span className="font-bold text-white bg-slate-800 px-2 py-0.5 rounded">
                        {param.name}
                      </span>
                      <ArrowRight className="w-3.5 h-3.5 text-indigo-400" />
                      
                      <span className="text-slate-400">Data Type:</span>
                      <span className="font-bold text-emerald-300 bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-900/40">
                        {param.dataType}
                      </span>
                      <ArrowRight className="w-3.5 h-3.5 text-indigo-400" />

                      <span className="text-slate-400">Version:</span>
                      <span className="font-bold text-indigo-300 bg-indigo-950/40 px-2 py-0.5 rounded border border-indigo-900/40">
                        {param.version}
                      </span>
                    </div>

                    {/* Status Pill & Note */}
                    <div className="flex items-center gap-2 shrink-0">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${getStatusColor(param.status)}`}>
                        {param.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Selected Node Inspector Drawer */}
      {activeNode && (
        <div className="p-5 rounded-2xl bg-indigo-950/30 border border-indigo-500/40 backdrop-blur-md shadow-xl flex items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-indigo-400" />
              <span className="text-xs font-bold text-white uppercase tracking-wider">
                Active Node Context: {activeNode.name}
              </span>
              <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${getStatusColor(activeNode.status)}`}>
                {activeNode.status}
              </span>
            </div>
            <p className="text-xs text-slate-300">
              {activeNode.note}
            </p>
          </div>

          <button
            onClick={() => setActiveNode(null)}
            className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300 hover:text-white transition-colors shrink-0"
          >
            Dismiss
          </button>
        </div>
      )}
    </div>
  );
};
