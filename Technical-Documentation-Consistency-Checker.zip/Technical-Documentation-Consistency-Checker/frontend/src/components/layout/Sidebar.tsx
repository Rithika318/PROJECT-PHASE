import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import {
  LayoutDashboard,
  GitCompare,
  History,
  CheckSquare,
  FileCheck2,
  Settings,
  LogOut,
  FolderKanban,
  BrainCircuit,
  Cpu,
  HelpCircle,
  ChevronLeft,
  ChevronRight,
  Sparkles
} from 'lucide-react';

interface SidebarProps {
  collapsed: boolean;
  onToggle: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ collapsed, onToggle }) => {
  const { logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  // The 6 Primary Navigation items requested in PPT & project spec
  const primaryNavItems = [
    { name: 'Dashboard', path: '/', icon: LayoutDashboard },
    { name: 'New Comparison', path: '/new-analysis', icon: GitCompare, highlight: true },
    { name: 'Comparison History', path: '/history', icon: History },
    { name: 'Issues and Reviews', path: '/reviews', icon: CheckSquare },
    { name: 'Reports', path: '/reports', icon: FileCheck2 },
    { name: 'Settings', path: '/settings', icon: Settings },
  ];

  // Secondary Tools
  const secondaryNavItems = [
    { name: 'Document Library', path: '/documents', icon: FolderKanban },
    { name: 'Model Status', path: '/model-status', icon: Cpu },
    { name: 'Training & Eval', path: '/training', icon: BrainCircuit },
    { name: 'Help', path: '/help', icon: HelpCircle },
  ];

  return (
    <aside
      className={`bg-white/90 backdrop-blur-md border-r border-slate-200/80 h-[calc(100vh-4rem)] sticky top-16 transition-all duration-300 z-20 flex flex-col justify-between ${
        collapsed ? 'w-20' : 'w-64'
      }`}
    >
      {/* Navigation List */}
      <div className="py-4 px-3 space-y-4 overflow-y-auto">
        {/* Core Nav */}
        <div className="space-y-1">
          {!collapsed && (
            <p className="px-3 text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">
              Main Navigation
            </p>
          )}
          {primaryNavItems.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.path}
                to={item.path}
                end={item.path === '/'}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-3.5 py-2.5 rounded-xl font-medium text-xs sm:text-sm transition-all group ${
                    isActive
                      ? 'bg-gradient-to-r from-indigo-600 to-violet-600 text-white shadow-md shadow-indigo-500/25'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/80'
                  }`
                }
                title={collapsed ? item.name : undefined}
              >
                {({ isActive }) => (
                  <>
                    <Icon
                      className={`w-4 h-4 shrink-0 transition-transform group-hover:scale-110 ${
                        isActive ? 'text-white' : item.highlight ? 'text-indigo-600' : 'text-slate-500'
                      }`}
                    />
                    {!collapsed && <span className="truncate">{item.name}</span>}
                    {!collapsed && item.highlight && !isActive && (
                      <span className="ml-auto text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-indigo-100 text-indigo-700">
                        NEW
                      </span>
                    )}
                  </>
                )}
              </NavLink>
            );
          })}
        </div>

        {/* System & Tools */}
        <div className="space-y-1 pt-2 border-t border-slate-100">
          {!collapsed && (
            <p className="px-3 text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">
              Tools & Diagnostics
            </p>
          )}
          {secondaryNavItems.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.path}
                to={item.path}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-3.5 py-2 rounded-xl font-medium text-xs transition-all group ${
                    isActive
                      ? 'bg-indigo-50 text-indigo-700 font-semibold'
                      : 'text-slate-500 hover:text-slate-900 hover:bg-slate-100/60'
                  }`
                }
                title={collapsed ? item.name : undefined}
              >
                <Icon className="w-3.5 h-3.5 shrink-0 text-slate-400 group-hover:text-slate-600" />
                {!collapsed && <span className="truncate">{item.name}</span>}
              </NavLink>
            );
          })}
        </div>

        {/* Item 7: Dedicated Logout Action */}
        <div className="pt-2 border-t border-slate-100">
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-rose-600 hover:text-rose-700 hover:bg-rose-50 transition-colors text-xs sm:text-sm font-semibold group"
            title={collapsed ? 'Logout' : undefined}
          >
            <LogOut className="w-4 h-4 shrink-0 text-rose-500 group-hover:scale-110 transition-transform" />
            {!collapsed && <span>Logout</span>}
          </button>
        </div>
      </div>

      {/* Footer Info / Toggle Button */}
      <div className="p-3 border-t border-slate-200/60 bg-slate-50/50">
        {!collapsed && (
          <div className="p-3 rounded-xl bg-gradient-to-tr from-indigo-50 via-indigo-50/40 to-cyan-50 border border-indigo-100/70 mb-3 text-xs">
            <div className="flex items-center gap-1.5 text-indigo-900 font-semibold mb-1">
              <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
              <span>Final Year Project</span>
            </div>
            <p className="text-slate-600 text-[11px] leading-relaxed">
              B.Tech Major Project • Fully Local & Offline AI Pipeline
            </p>
          </div>
        )}

        <button
          onClick={onToggle}
          className="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-xl text-slate-500 hover:text-slate-800 hover:bg-slate-200/60 transition-colors text-xs font-medium"
          aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          {collapsed ? <ChevronRight className="w-4 h-4" /> : <><ChevronLeft className="w-4 h-4" /><span>Collapse Sidebar</span></>}
        </button>
      </div>
    </aside>
  );
};
