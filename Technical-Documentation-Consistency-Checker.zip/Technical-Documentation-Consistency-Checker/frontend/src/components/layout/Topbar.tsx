import React, { useState } from 'react';
import { 
  Search, 
  Bell, 
  Play, 
  BookOpen, 
  AlertCircle,
  CheckCircle2,
  UserCheck,
  FolderDown
} from 'lucide-react';
import { useAnalysis } from '../../context/AnalysisContext';

export const Topbar: React.FC = () => {
  const { 
    searchQuery, 
    setSearchQuery, 
    setIsHowItWorksOpen, 
    setIsDownloadModalOpen,
    runAnalysisSimulation, 
    isAnalyzing,
    issues 
  } = useAnalysis();

  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const highIssues = issues.filter(i => i.severity === 'High');

  return (
    <header className="h-16 bg-slate-900/80 backdrop-blur-md border-b border-slate-800/80 px-6 flex items-center justify-between sticky top-0 z-20">
      {/* Left: Project Title & Breadcrumb */}
      <div className="flex items-center gap-4 min-w-0">
        <div>
          <h2 className="text-sm font-semibold text-slate-100 truncate tracking-tight flex items-center gap-2">
            <span>AI-Based Technical Documentation Consistency Detection and Analysis System</span>
          </h2>
          <p className="text-[11px] text-slate-400 truncate">
            Automated Consistency, Completeness & Source-Code AST Verification Platform
          </p>
        </div>
      </div>

      {/* Right Controls */}
      <div className="flex items-center gap-3 shrink-0">
        {/* Search Bar */}
        <div className="relative w-64">
          <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search parameters, endpoints, rules..."
            className="w-full pl-9 pr-3 py-1.5 rounded-lg bg-slate-950/60 border border-slate-800 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all"
          />
        </div>

        {/* How The System Works Button */}
        <button
          onClick={() => setIsHowItWorksOpen(true)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700/60 text-xs font-medium text-slate-200 hover:text-white transition-all shadow-sm"
        >
          <BookOpen className="w-3.5 h-3.5 text-indigo-400" />
          <span>How It Works</span>
        </button>

        {/* Download Project Package (.zip) Button */}
        <button
          onClick={() => setIsDownloadModalOpen(true)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-950/60 hover:bg-emerald-900/60 border border-emerald-500/30 text-xs font-semibold text-emerald-300 hover:text-emerald-200 transition-all shadow-sm"
          title="Download Full Project Source Code, Docs and PyTorch Model"
        >
          <FolderDown className="w-3.5 h-3.5 text-emerald-400" />
          <span>Download Package (.zip)</span>
        </button>

        {/* Run Full Analysis Action */}
        <button
          onClick={runAnalysisSimulation}
          disabled={isAnalyzing}
          className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold shadow-md transition-all ${
            isAnalyzing
              ? 'bg-indigo-900/60 text-indigo-300 border border-indigo-700 cursor-wait'
              : 'bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-500 hover:to-indigo-600 text-white shadow-indigo-600/25 border border-indigo-400/30'
          }`}
        >
          <Play className={`w-3.5 h-3.5 ${isAnalyzing ? 'animate-spin' : 'fill-current'}`} />
          <span>{isAnalyzing ? 'Analyzing...' : 'Run Analysis'}</span>
        </button>

        {/* Notification Bell */}
        <div className="relative">
          <button
            onClick={() => setIsNotificationsOpen(!isNotificationsOpen)}
            className="p-2 rounded-lg bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 text-slate-300 hover:text-white relative transition-all"
            aria-label="Notifications"
          >
            <Bell className="w-4 h-4" />
            <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-rose-500 text-[10px] font-bold text-white flex items-center justify-center">
              {highIssues.length}
            </span>
          </button>

          {/* Notifications Dropdown */}
          {isNotificationsOpen && (
            <div className="absolute right-0 mt-2 w-80 rounded-xl bg-slate-900 border border-slate-800 shadow-2xl p-3 z-50 animate-in fade-in slide-in-from-top-2 duration-150">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                <span className="text-xs font-semibold text-white flex items-center gap-1.5">
                  <AlertCircle className="w-3.5 h-3.5 text-rose-400" />
                  High Severity Alerts ({highIssues.length})
                </span>
                <span className="text-[10px] text-slate-400 font-mono">Local Verification Engine</span>
              </div>
              <div className="mt-2 space-y-2 max-h-60 overflow-y-auto pr-1">
                {highIssues.slice(0, 4).map((issue) => (
                  <div key={issue.id} className="p-2 rounded-lg bg-slate-950/60 border border-rose-500/20 text-[11px]">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-rose-300">{issue.section}</span>
                      <span className="text-[9px] font-mono px-1 rounded bg-rose-950 text-rose-300 border border-rose-800/50">{issue.id}</span>
                    </div>
                    <p className="text-slate-300 text-[10px] mt-0.5 line-clamp-1">{issue.reason}</p>
                    <div className="mt-1 text-[9px] text-slate-400 flex gap-2 font-mono">
                      <span>Old: <span className="text-rose-400 line-through">{issue.oldValue}</span></span>
                      <span>New: <span className="text-emerald-400">{issue.newValue}</span></span>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-2 pt-2 border-t border-slate-800 flex justify-between items-center text-[10px] text-indigo-400">
                <button onClick={() => setIsNotificationsOpen(false)} className="hover:underline">
                  Close
                </button>
                <span className="flex items-center gap-1 text-slate-500">
                  <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                  AST Sync Active
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Reviewer / Evaluator Profile Badge */}
        <div className="flex items-center gap-2 pl-3 border-l border-slate-800">
          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-indigo-500 to-violet-600 flex items-center justify-center text-xs font-bold text-white border border-indigo-400/40">
            FY
          </div>
          <div className="text-left hidden lg:block">
            <div className="text-xs font-semibold text-slate-200 leading-tight flex items-center gap-1">
              <span>Academic Reviewer</span>
              <UserCheck className="w-3 h-3 text-emerald-400 inline" />
            </div>
            <span className="text-[10px] text-slate-400">Final-Year Project Panel</span>
          </div>
        </div>
      </div>
    </header>
  );
};
