import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../services/api';
import {
  FileText,
  Shield,
  Activity,
  LogOut,
  Bell,
  Cpu,
  ChevronDown,
  ExternalLink
} from 'lucide-react';

export const Navbar: React.FC<{ sidebarCollapsed: boolean; onToggleSidebar: () => void }> = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [modelStatus, setModelStatus] = useState<any>(null);
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);

  useEffect(() => {
    const fetchStatus = async () => {
      try {
        const res = await api.getModelStatus();
        setModelStatus(res);
      } catch (err) {
        console.warn('Could not retrieve model health status', err);
      }
    };
    fetchStatus();
    const interval = setInterval(fetchStatus, 30000);
    return () => clearInterval(interval);
  }, []);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const isLlamaReady = modelStatus?.ollama_service?.status === 'Ready' && modelStatus?.llama31_model?.status === 'Ready';

  return (
    <header className="h-16 bg-white/80 backdrop-blur-md border-b border-slate-200/80 sticky top-0 z-30 px-4 lg:px-6 flex items-center justify-between shadow-sm">
      {/* Brand Title & Logo */}
      <div className="flex items-center gap-3">
        <Link to="/" className="flex items-center gap-2.5 group">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-violet-600 to-cyan-400 flex items-center justify-center text-white shadow-md shadow-indigo-500/20 group-hover:scale-105 transition-transform">
            <Shield className="w-5 h-5" />
          </div>
          <div>
            <span className="font-bold text-slate-900 tracking-tight text-base sm:text-lg flex items-center gap-1.5">
              Doc<span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-violet-600">Consistency</span>
              <span className="text-xs px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 font-semibold border border-indigo-200/60 ml-1">AI</span>
            </span>
            <p className="text-[11px] text-slate-500 hidden sm:block -mt-0.5">LLM Technical Documentation Consistency Checker</p>
          </div>
        </Link>
      </div>

      {/* Right Controls: Model Pill, Notifications, User */}
      <div className="flex items-center gap-3">
        {/* Model Status Pill */}
        <Link
          to="/model-status"
          className="flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-medium border transition-all hover:shadow-sm"
          style={{
            backgroundColor: isLlamaReady ? '#ECFDF5' : '#FFFBEB',
            borderColor: isLlamaReady ? '#A7F3D0' : '#FDE68A',
            color: isLlamaReady ? '#065F46' : '#92400E'
          }}
          title={isLlamaReady ? "Local Ollama Llama 3.1 8B Ready" : "Click to view AI Model setup status"}
        >
          <span className={`w-2 h-2 rounded-full ${isLlamaReady ? 'bg-emerald-500 animate-pulse' : 'bg-amber-500'}`} />
          <Cpu className="w-3.5 h-3.5 hidden sm:inline" />
          <span className="truncate max-w-[140px] sm:max-w-none">
            {isLlamaReady ? 'Llama 3.1 8B: Ready' : (modelStatus?.current_inference_mode ? 'Hybrid Engine Active' : 'Model Status')}
          </span>
        </Link>

        {/* Notifications */}
        <div className="relative">
          <button
            onClick={() => setShowNotifications(!showNotifications)}
            className="p-2 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors relative"
            aria-label="Notifications"
          >
            <Bell className="w-4 h-4" />
            <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-indigo-600 rounded-full" />
          </button>

          {showNotifications && (
            <div className="absolute right-0 mt-2 w-80 bg-white rounded-xl shadow-xl border border-slate-200 py-3 z-50">
              <div className="px-4 pb-2 border-b border-slate-100 flex items-center justify-between">
                <span className="font-semibold text-xs text-slate-900 uppercase tracking-wider">System Alerts</span>
                <span className="text-[11px] text-indigo-600 font-medium">Live</span>
              </div>
              <div className="py-2 px-3 space-y-2">
                <div className="text-xs p-2 rounded-lg bg-indigo-50/70 border border-indigo-100">
                  <p className="font-medium text-indigo-900">Sentence-BERT & DeBERTa Loaded</p>
                  <p className="text-indigo-700 text-[11px] mt-0.5">Semantic embedding and NLI verification ready for local document comparison.</p>
                </div>
                <div className="text-xs p-2 rounded-lg bg-slate-50 border border-slate-100">
                  <p className="font-medium text-slate-900">5-Category Taxonomy Enabled</p>
                  <p className="text-slate-600 text-[11px] mt-0.5">Consistent, Contradiction, Outdated, Missing, and Terminology Inconsistency active.</p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* User Profile Dropdown */}
        <div className="relative">
          <button
            onClick={() => setShowProfileMenu(!showProfileMenu)}
            className="flex items-center gap-2 p-1.5 rounded-lg hover:bg-slate-100 transition-colors"
          >
            <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-indigo-600 to-violet-600 text-white flex items-center justify-center font-semibold text-xs shadow-sm">
              {user?.full_name ? user.full_name[0].toUpperCase() : 'U'}
            </div>
            <div className="hidden md:block text-left">
              <p className="text-xs font-semibold text-slate-800 leading-none">{user?.full_name || 'User'}</p>
              <p className="text-[10px] text-slate-500 font-mono mt-0.5 capitalize">{user?.role || 'Developer'}</p>
            </div>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400 hidden sm:block" />
          </button>

          {showProfileMenu && (
            <div className="absolute right-0 mt-2 w-52 bg-white rounded-xl shadow-xl border border-slate-200 py-1.5 z-50">
              <div className="px-4 py-2 border-b border-slate-100">
                <p className="text-xs font-medium text-slate-900">{user?.full_name}</p>
                <p className="text-[11px] text-slate-500 truncate">{user?.email}</p>
              </div>
              <Link
                to="/settings"
                onClick={() => setShowProfileMenu(false)}
                className="flex items-center gap-2 px-4 py-2 text-xs text-slate-700 hover:bg-slate-50 hover:text-indigo-600"
              >
                Account Settings
              </Link>
              <Link
                to="/help"
                onClick={() => setShowProfileMenu(false)}
                className="flex items-center gap-2 px-4 py-2 text-xs text-slate-700 hover:bg-slate-50 hover:text-indigo-600"
              >
                User Guide & FAQ
              </Link>
              <div className="border-t border-slate-100 my-1" />
              <button
                onClick={handleLogout}
                className="w-full flex items-center gap-2 px-4 py-2 text-xs text-red-600 hover:bg-red-50 text-left transition-colors"
              >
                <LogOut className="w-3.5 h-3.5" />
                Sign Out
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
