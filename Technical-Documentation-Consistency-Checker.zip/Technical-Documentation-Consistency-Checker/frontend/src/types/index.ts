﻿export type Severity = 'High' | 'Medium' | 'Low';

export type IssueType = 
  | 'Inconsistency' 
  | 'Outdated Information' 
  | 'Missing Content' 
  | 'Contradiction' 
  | 'Terminology Inconsistency';

export interface Issue {
  id: string;
  section: string;
  type: IssueType;
  severity: Severity;
  oldValue: string;
  newValue: string;
  reason: string;
  suggestedCorrection: string;
  endpoint?: string;
  parameter?: string;
  resolved?: boolean;
  confidenceScore?: number;
  ruleId?: string;
  lineRange?: string;
}

export interface DocumentFile {
  id: string;
  name: string;
  version: string;
  type: 'PDF' | 'Markdown' | 'HTML' | 'TXT';
  size: string;
  uploadDate: string;
  status: 'Ready' | 'Parsed' | 'Analyzing';
  content?: string;
}

export interface ASTParameter {
  name: string;
  type: string;
  required: boolean;
  description?: string;
}

export interface ASTDefinition {
  id: string;
  functionName: string;
  endpoint: string;
  httpMethod: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';
  parameters: ASTParameter[];
  returnType: string;
  apiVersion: string;
  codeStatus: 'Active' | 'Deprecated' | 'Updated';
  docStatus: 'Consistent' | 'Mismatch' | 'Outdated' | 'Missing';
  docMismatchReason?: string;
}

export interface KnowledgeNode {
  id: string;
  label: string;
  category: 'API' | 'Endpoint' | 'Parameter' | 'Data Type' | 'Version';
  status: 'consistent' | 'inconsistent' | 'outdated' | 'missing';
  parentId?: string;
  description?: string;
}

export interface ValidationRule {
  id: string;
  name: string;
  category: string;
  description: string;
  enabled: boolean;
  severity: Severity;
  targetEntity: string;
}

export interface AuditSession {
  id: string;
  docOldName: string;
  docNewName: string;
  date: string;
  consistencyScore: number;
  totalIssues: number;
  highSeverity: number;
  mediumSeverity: number;
  lowSeverity: number;
  status: 'Completed' | 'Review Needed';
}

export interface PipelineStage {
  id: number;
  title: string;
  description: string;
  status: 'pending' | 'running' | 'completed';
  extractedDetail?: string;
}
