import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { ProtectedRoute } from './components/common/ProtectedRoute';
import { DashboardLayout } from './layouts/DashboardLayout';

import { LoginPage } from './pages/LoginPage';
import { DashboardPage } from './pages/DashboardPage';
import { NewAnalysisPage } from './pages/NewAnalysisPage';
import { ResultsPage } from './pages/ResultsPage';
import { DocumentLibraryPage } from './pages/DocumentLibraryPage';
import { ComparisonHistoryPage } from './pages/ComparisonHistoryPage';
import { IssuesReviewsPage } from './pages/IssuesReviewsPage';
import { TrainingEvaluationPage } from './pages/TrainingEvaluationPage';
import { ModelStatusPage } from './pages/ModelStatusPage';
import { SettingsPage } from './pages/SettingsPage';
import { HelpPage } from './pages/HelpPage';

export function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          {/* Public Auth Route */}
          <Route path="/login" element={<LoginPage />} />

          {/* Protected Application Routes */}
          <Route
            path="/"
            element={
              <ProtectedRoute>
                <DashboardLayout />
              </ProtectedRoute>
            }
          >
            <Route index element={<DashboardPage />} />
            <Route path="new-analysis" element={<NewAnalysisPage />} />
            <Route path="compare" element={<NewAnalysisPage />} />
            <Route path="results" element={<ResultsPage />} />
            <Route path="results/:id" element={<ResultsPage />} />
            <Route path="reports" element={<ResultsPage />} />
            <Route path="reports/:id" element={<ResultsPage />} />
            <Route path="reviews" element={<IssuesReviewsPage />} />
            <Route path="documents" element={<DocumentLibraryPage />} />
            <Route path="history" element={<ComparisonHistoryPage />} />
            <Route path="training" element={<TrainingEvaluationPage />} />
            <Route path="model-status" element={<ModelStatusPage />} />
            <Route path="settings" element={<SettingsPage />} />
            <Route path="help" element={<HelpPage />} />
          </Route>

          {/* Catch-all */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}

export default App;
