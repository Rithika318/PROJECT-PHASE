// API service for Technical Documentation Consistency Checker backend

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || '/api';

function getAuthHeader(): Record<string, string> {
  const token = localStorage.getItem('token');
  return token ? { Authorization: `Bearer ${token}` } : {};
}

async function handleResponse<T>(res: Response): Promise<T> {
  if (!res.ok) {
    let errorDetail = 'An unexpected error occurred.';
    try {
      const errorData = await res.json();
      errorDetail = errorData.detail || errorDetail;
    } catch {
      errorDetail = res.statusText || errorDetail;
    }
    throw new Error(errorDetail);
  }
  return res.json();
}

export const api = {
  // Auth
  async register(data: { full_name: string; email: string; password: string }) {
    const res = await fetch(`${API_BASE_URL}/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    return handleResponse<{ access_token: string; token_type: string; user: any }>(res);
  },

  async login(data: { email: string; password: string }) {
    const res = await fetch(`${API_BASE_URL}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    return handleResponse<{ access_token: string; token_type: string; user: any }>(res);
  },

  async getMe() {
    const res = await fetch(`${API_BASE_URL}/auth/me`, {
      headers: { ...getAuthHeader() },
    });
    return handleResponse<any>(res);
  },

  async changePassword(data: { current_password: string; new_password: string }) {
    const res = await fetch(`${API_BASE_URL}/auth/change-password`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...getAuthHeader() },
      body: JSON.stringify(data),
    });
    return handleResponse<{ message: string }>(res);
  },

  // Documents
  async uploadDocument(file: File) {
    const formData = new FormData();
    formData.append('file', file);
    const res = await fetch(`${API_BASE_URL}/documents/upload`, {
      method: 'POST',
      headers: { ...getAuthHeader() },
      body: formData,
    });
    return handleResponse<any>(res);
  },

  async getDocuments() {
    const res = await fetch(`${API_BASE_URL}/documents`, {
      headers: { ...getAuthHeader() },
    });
    return handleResponse<any[]>(res);
  },

  async getDocument(id: string) {
    const res = await fetch(`${API_BASE_URL}/documents/${id}`, {
      headers: { ...getAuthHeader() },
    });
    return handleResponse<any>(res);
  },

  async deleteDocument(id: string) {
    const res = await fetch(`${API_BASE_URL}/documents/${id}`, {
      method: 'DELETE',
      headers: { ...getAuthHeader() },
    });
    return handleResponse<{ message: string }>(res);
  },

  async loadSampleDocuments() {
    const res = await fetch(`${API_BASE_URL}/documents/load-sample`, {
      method: 'POST',
      headers: { ...getAuthHeader() },
    });
    return handleResponse<any[]>(res);
  },

  // Analyses
  async createAnalysis(data: { title: string; description?: string; old_doc_id: string; new_doc_id: string }) {
    const res = await fetch(`${API_BASE_URL}/analyses`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...getAuthHeader() },
      body: JSON.stringify(data),
    });
    return handleResponse<any>(res);
  },

  async getAnalyses() {
    const res = await fetch(`${API_BASE_URL}/analyses`, {
      headers: { ...getAuthHeader() },
    });
    return handleResponse<any[]>(res);
  },

  async getAnalysis(id: string) {
    const res = await fetch(`${API_BASE_URL}/analyses/${id}`, {
      headers: { ...getAuthHeader() },
    });
    return handleResponse<any>(res);
  },

  async getAnalysisStatus(id: string) {
    const res = await fetch(`${API_BASE_URL}/analyses/${id}/status`, {
      headers: { ...getAuthHeader() },
    });
    return handleResponse<{
      id: string;
      status: string;
      progress_stage: number;
      stage_name: string;
      progress_percent: number;
      error_message: string | null;
      consistency_score: number | null;
      is_completed: boolean;
    }>(res);
  },

  async deleteAnalysis(id: string) {
    const res = await fetch(`${API_BASE_URL}/analyses/${id}`, {
      method: 'DELETE',
      headers: { ...getAuthHeader() },
    });
    return handleResponse<{ message: string }>(res);
  },

  // Issue Review
  async getIssues(params?: { analysis_id?: string; category?: string; severity?: string; verification_status?: string }) {
    const query = new URLSearchParams();
    if (params?.analysis_id) query.append('analysis_id', params.analysis_id);
    if (params?.category) query.append('category', params.category);
    if (params?.severity) query.append('severity', params.severity);
    if (params?.verification_status) query.append('verification_status', params.verification_status);
    const queryString = query.toString() ? `?${query.toString()}` : '';

    const res = await fetch(`${API_BASE_URL}/issues${queryString}`, {
      headers: { ...getAuthHeader() },
    });
    return handleResponse<any[]>(res);
  },

  async getIssue(issueId: string) {
    const res = await fetch(`${API_BASE_URL}/issues/${issueId}`, {
      headers: { ...getAuthHeader() },
    });
    return handleResponse<any>(res);
  },

  async reviewIssue(issueId: string, data: { verification_status: string; reviewer_notes?: string }) {
    const res = await fetch(`${API_BASE_URL}/issues/${issueId}/review`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', ...getAuthHeader() },
      body: JSON.stringify(data),
    });
    return handleResponse<any>(res);
  },

  async updateCorrection(issueId: string, suggested_correction: string) {
    const res = await fetch(`${API_BASE_URL}/issues/${issueId}/correction`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', ...getAuthHeader() },
      body: JSON.stringify({ suggested_correction }),
    });
    return handleResponse<any>(res);
  },

  async addComment(issueId: string, comment: string) {
    const res = await fetch(`${API_BASE_URL}/issues/${issueId}/comments`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...getAuthHeader() },
      body: JSON.stringify({ comment }),
    });
    return handleResponse<any>(res);
  },

  // Reports
  getPdfReportUrl(analysisId: string): string {
    return `${API_BASE_URL}/analyses/${analysisId}/report/pdf`;
  },

  getCsvReportUrl(analysisId: string): string {
    return `${API_BASE_URL}/analyses/${analysisId}/report/csv`;
  },

  async downloadPdf(analysisId: string, filename: string) {
    const res = await fetch(this.getPdfReportUrl(analysisId), {
      headers: { ...getAuthHeader() },
    });
    const blob = await res.blob();
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename || `report_${analysisId}.pdf`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  },

  async downloadCsv(analysisId: string, filename: string) {
    const res = await fetch(this.getCsvReportUrl(analysisId), {
      headers: { ...getAuthHeader() },
    });
    const blob = await res.blob();
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename || `issues_${analysisId}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  },

  // Datasets & Training
  async uploadDataset(file: File) {
    const formData = new FormData();
    formData.append('file', file);
    const res = await fetch(`${API_BASE_URL}/datasets/upload`, {
      method: 'POST',
      headers: { ...getAuthHeader() },
      body: formData,
    });
    return handleResponse<any>(res);
  },

  async getDatasets() {
    const res = await fetch(`${API_BASE_URL}/datasets`, {
      headers: { ...getAuthHeader() },
    });
    return handleResponse<any[]>(res);
  },

  getSampleDatasetUrl(): string {
    return `${API_BASE_URL}/datasets/sample/download`;
  },

  getTemplateDatasetUrl(): string {
    return `${API_BASE_URL}/datasets/template/download`;
  },

  async createTrainingJob(config: any) {
    const res = await fetch(`${API_BASE_URL}/training/jobs`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...getAuthHeader() },
      body: JSON.stringify(config),
    });
    return handleResponse<any>(res);
  },

  async getTrainingJob(jobId: string) {
    const res = await fetch(`${API_BASE_URL}/training/jobs/${jobId}`, {
      headers: { ...getAuthHeader() },
    });
    return handleResponse<any>(res);
  },

  async runEvaluation(data: { dataset_id: string; model_name: string; use_adapter: boolean }) {
    const res = await fetch(`${API_BASE_URL}/training/evaluations`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...getAuthHeader() },
      body: JSON.stringify(data),
    });
    return handleResponse<any>(res);
  },

  async getEvaluations() {
    const res = await fetch(`${API_BASE_URL}/training/evaluations`, {
      headers: { ...getAuthHeader() },
    });
    return handleResponse<any[]>(res);
  },

  // System & Dashboard
  async getModelStatus() {
    const res = await fetch(`${API_BASE_URL}/models/status`, {
      headers: { ...getAuthHeader() },
    });
    return handleResponse<any>(res);
  },

  async getDashboardSummary() {
    const res = await fetch(`${API_BASE_URL}/dashboard/summary`, {
      headers: { ...getAuthHeader() },
    });
    return handleResponse<any>(res);
  },

  async getDashboardCharts() {
    const res = await fetch(`${API_BASE_URL}/dashboard/charts`, {
      headers: { ...getAuthHeader() },
    });
    return handleResponse<any>(res);
  },

  // Settings
  async getSettings() {
    const res = await fetch(`${API_BASE_URL}/settings`, {
      headers: { ...getAuthHeader() },
    });
    return handleResponse<any>(res);
  },

  async updateSettings(data: any) {
    const res = await fetch(`${API_BASE_URL}/settings`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', ...getAuthHeader() },
      body: JSON.stringify(data),
    });
    return handleResponse<any>(res);
  },
};
