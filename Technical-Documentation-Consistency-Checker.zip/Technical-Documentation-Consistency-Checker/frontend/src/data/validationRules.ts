﻿import { ValidationRule } from '../types';

export const DEFAULT_VALIDATION_RULES: ValidationRule[] = [
  {
    id: 'RULE-TYPE-01',
    name: 'Parameter Type Consistency Validation',
    category: 'Type Verification',
    description: 'Enforces strict equivalence between documentation parameter data types and AST / version definitions (e.g. integer vs string).',
    enabled: true,
    severity: 'High',
    targetEntity: 'Function & Endpoint Parameters'
  },
  {
    id: 'RULE-VER-01',
    name: 'API Version Deprecation & Path Consistency',
    category: 'Version Control',
    description: 'Detects superseded API versions (e.g. v1.0 vs v2.0), obsolete URL prefixes, and deprecated protocol handshakes.',
    enabled: true,
    severity: 'High',
    targetEntity: 'Global Headers & Endpoints'
  },
  {
    id: 'RULE-MISSING-01',
    name: 'Missing Endpoint & Action Detection',
    category: 'Completeness',
    description: 'Flags endpoints or functions present in structured AST definitions or new doc versions that are absent or marked unavailable.',
    enabled: true,
    severity: 'Medium',
    targetEntity: 'Endpoints & Methods'
  },
  {
    id: 'RULE-TERM-01',
    name: 'Deprecated Terminology & Glossary Alignment',
    category: 'Terminology',
    description: 'Scans technical prose for deprecated jargon, outdated field naming (e.g. avatar vs profile picture), and naming drift.',
    enabled: true,
    severity: 'Low',
    targetEntity: 'Prose & Schema Labels'
  },
  {
    id: 'RULE-RESP-01',
    name: 'HTTP Response Code & Header Verification',
    category: 'Protocol Conformance',
    description: 'Verifies documented status codes (e.g. 400 vs 401) and ensures mandatory headers (e.g. Content-MD5, Idempotency-Key) are listed.',
    enabled: true,
    severity: 'High',
    targetEntity: 'HTTP Responses & Headers'
  },
  {
    id: 'RULE-LIMIT-01',
    name: 'Quota, Sizing & Rate Limit Boundary Check',
    category: 'Operational Limits',
    description: 'Compares numerical limits, file size ceilings (5MB vs 10MB), and SLA rate throttle thresholds for deviations.',
    enabled: true,
    severity: 'Medium',
    targetEntity: 'Operational Constraints'
  }
];
