﻿import { ASTDefinition } from '../types';

export const SAMPLE_AST_DEFINITIONS: ASTDefinition[] = [
  {
    id: 'AST-001',
    functionName: 'getUser(userId: string): Promise<UserRecord>',
    endpoint: '/api/v2/users/{id}',
    httpMethod: 'GET',
    parameters: [
      { name: 'userId', type: 'string (UUIDv4)', required: true, description: 'Unique customer identifier' },
      { name: 'expand', type: 'string[]', required: false, description: 'Optional relation expansions' }
    ],
    returnType: 'UserRecord { id: string, username: string, profile_image_url: string }',
    apiVersion: 'v2.0',
    codeStatus: 'Active',
    docStatus: 'Mismatch',
    docMismatchReason: 'Documentation lists "id: integer" while AST parser extracts "userId: string (UUIDv4)".'
  },
  {
    id: 'AST-002',
    functionName: 'authenticate(token: string, realm: string): AuthSession',
    endpoint: '/v2/auth/token',
    httpMethod: 'POST',
    parameters: [
      { name: 'token', type: 'string (JWT)', required: true, description: 'Cryptographic bearer token' },
      { name: 'realm', type: 'string', required: true, description: 'Authentication domain boundary' }
    ],
    returnType: 'AuthSession { token: string, expires_in: number }',
    apiVersion: 'v2.0',
    codeStatus: 'Active',
    docStatus: 'Outdated',
    docMismatchReason: 'Documentation documents OAuth1 legacy handshake; AST shows Bearer JWT validation.'
  },
  {
    id: 'AST-003',
    functionName: 'deleteUser(userId: string): Promise<DeletionAudit>',
    endpoint: '/api/v2/users/{user_id}',
    httpMethod: 'DELETE',
    parameters: [
      { name: 'userId', type: 'string (UUIDv4)', required: true, description: 'Target user to soft-delete' },
      { name: 'cascade', type: 'boolean', required: false, description: 'Soft-delete associated API keys' }
    ],
    returnType: 'DeletionAudit { deleted: boolean, purged_at: number }',
    apiVersion: 'v2.0',
    codeStatus: 'Active',
    docStatus: 'Missing',
    docMismatchReason: 'Source code exports DELETE /users/{user_id}, but public documentation states deleteUser() unavailable.'
  },
  {
    id: 'AST-004',
    functionName: 'search(query: string, limit?: number, sortDir?: string): SearchResultSet',
    endpoint: '/api/v2/search',
    httpMethod: 'GET',
    parameters: [
      { name: 'query', type: 'string', required: true, description: 'Text keyword query' },
      { name: 'limit', type: 'number', required: false, description: 'Default is 25 in AST' },
      { name: 'sortDir', type: '"asc" | "desc"', required: false, description: 'Sort direction' }
    ],
    returnType: 'SearchResultSet { total: number, items: Record[] }',
    apiVersion: 'v2.0',
    codeStatus: 'Active',
    docStatus: 'Mismatch',
    docMismatchReason: 'AST requires query string parameter "query"; documentation specifies legacy "q".'
  },
  {
    id: 'AST-005',
    functionName: 'uploadAttachment(payload: Stream, md5Checksum: string): UploadReceipt',
    endpoint: '/api/v2/files/upload',
    httpMethod: 'POST',
    parameters: [
      { name: 'payload', type: 'MultipartStream (max 10MB)', required: true, description: 'Binary payload' },
      { name: 'md5Checksum', type: 'string', required: true, description: 'Content-MD5 header verification' }
    ],
    returnType: 'UploadReceipt { fileId: string, bytes: number, url: string }',
    apiVersion: 'v2.0',
    codeStatus: 'Active',
    docStatus: 'Outdated',
    docMismatchReason: 'AST limits byte buffer to 10 MB and mandates Content-MD5; docs mention 5 MB without checksum.'
  },
  {
    id: 'AST-006',
    functionName: 'createPayment(amount: number, currency: CurrencyCode, idempotencyKey: string): Charge',
    endpoint: '/api/v2/charges',
    httpMethod: 'POST',
    parameters: [
      { name: 'amount', type: 'number (cents)', required: true, description: 'Transaction amount' },
      { name: 'currency', type: 'CurrencyCode (ISO-4217)', required: true, description: 'Multicurrency code' },
      { name: 'idempotencyKey', type: 'string (UUID)', required: true, description: 'Mandatory header in AST' }
    ],
    returnType: 'Charge { id: string, paid: boolean, status: string }',
    apiVersion: 'v2.0',
    codeStatus: 'Active',
    docStatus: 'Mismatch',
    docMismatchReason: 'AST requires ISO-4217 code and mandatory Idempotency-Key; docs specify USD only and optional key.'
  },
  {
    id: 'AST-007',
    functionName: 'dispatchWebhook(event: WebhookEvent, secret: string): Promise<WebhookAck>',
    endpoint: '/v2/webhooks/listener',
    httpMethod: 'POST',
    parameters: [
      { name: 'event', type: 'DomainEvent', required: true, description: 'Event payload object' },
      { name: 'secret', type: 'string', required: true, description: 'HMAC-SHA256 signing secret' }
    ],
    returnType: 'WebhookAck { status: number, latencyMs: number }',
    apiVersion: 'v2.0',
    codeStatus: 'Active',
    docStatus: 'Outdated',
    docMismatchReason: 'AST signs using HMAC-SHA256 with exponential backoff; docs indicate legacy HMAC-MD5.'
  },
  {
    id: 'AST-008',
    functionName: 'checkLiveness(): HealthState',
    endpoint: '/health/live',
    httpMethod: 'GET',
    parameters: [],
    returnType: 'HealthState { healthy: boolean, uptime: number }',
    apiVersion: 'v2.0',
    codeStatus: 'Active',
    docStatus: 'Consistent',
    docMismatchReason: 'Source definition perfectly aligns with documentation specification.'
  }
];
