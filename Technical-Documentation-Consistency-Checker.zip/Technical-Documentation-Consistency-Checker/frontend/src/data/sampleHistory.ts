﻿import { AuditSession } from '../types';

export const SAMPLE_HISTORY: AuditSession[] = [
  {
    id: 'SESSION-0915',
    docOldName: 'CloudCore_Platform_API_v1.0.md',
    docNewName: 'CloudCore_Platform_API_v2.0.md',
    date: '2026-09-15 10:15 AM',
    consistencyScore: 78,
    totalIssues: 37,
    highSeverity: 8,
    mediumSeverity: 17,
    lowSeverity: 12,
    status: 'Completed'
  },
  {
    id: 'SESSION-0908',
    docOldName: 'Billing_Engine_Spec_2025.pdf',
    docNewName: 'Billing_Engine_Spec_2026.pdf',
    date: '2026-09-08 04:30 PM',
    consistencyScore: 84,
    totalIssues: 19,
    highSeverity: 3,
    mediumSeverity: 9,
    lowSeverity: 7,
    status: 'Completed'
  },
  {
    id: 'SESSION-0902',
    docOldName: 'Auth_Identity_Whitepaper_v2.html',
    docNewName: 'Auth_Identity_Whitepaper_v3.html',
    date: '2026-09-02 02:10 PM',
    consistencyScore: 71,
    totalIssues: 42,
    highSeverity: 11,
    mediumSeverity: 20,
    lowSeverity: 11,
    status: 'Review Needed'
  },
  {
    id: 'SESSION-0828',
    docOldName: 'Event_Stream_Kafka_v1.txt',
    docNewName: 'Event_Stream_Kafka_v2.txt',
    date: '2026-08-28 11:45 AM',
    consistencyScore: 92,
    totalIssues: 8,
    highSeverity: 1,
    mediumSeverity: 3,
    lowSeverity: 4,
    status: 'Completed'
  },
  {
    id: 'SESSION-0814',
    docOldName: 'Storage_Microservice_v1.md',
    docNewName: 'Storage_Microservice_v2.md',
    date: '2026-08-14 09:20 AM',
    consistencyScore: 68,
    totalIssues: 49,
    highSeverity: 14,
    mediumSeverity: 22,
    lowSeverity: 13,
    status: 'Review Needed'
  },
  {
    id: 'SESSION-0801',
    docOldName: 'Telemetry_Collector_Spec_v1.pdf',
    docNewName: 'Telemetry_Collector_Spec_v1.2.pdf',
    date: '2026-08-01 01:00 PM',
    consistencyScore: 88,
    totalIssues: 14,
    highSeverity: 2,
    mediumSeverity: 6,
    lowSeverity: 6,
    status: 'Completed'
  }
];
