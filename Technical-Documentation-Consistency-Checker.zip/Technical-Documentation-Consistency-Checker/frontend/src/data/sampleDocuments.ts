﻿import { DocumentFile } from '../types';

export const SAMPLE_OLD_DOCUMENT: DocumentFile = {
  id: 'DOC-OLD-01',
  name: 'CloudCore_Platform_API_v1.0.md',
  version: 'v1.0.4',
  type: 'Markdown',
  size: '142 KB',
  uploadDate: '2026-08-20',
  status: 'Ready',
  content: `# CloudCore Platform API Specification (v1.0)

## 1. Overview & Architecture
Base URL: \`https://sandbox-api.example.com\`
Protocol: HTTP/1.1 over TLS 1.2
Supported SDK Runtimes: Node.js >= 14, Python >= 3.8

## 2. Authentication & Headers
Authentication is handled via OAuth 1.0 or API Key in headers:
\`\`\`http
Accept-Version: 1.0
Authorization: Bearer <oauth_token>
Content-Type: application/json
\`\`\`
Global Rate Limit: 100 req/min per tenant.
Session state is tracked via \`Cookie: session_id=<val>\`.

## 3. User API
Retrieve user details by numeric ID:
\`\`\`http
GET /api/v1/users/{id}
\`\`\`

### Parameters
| Name | Type | Required | Description |
| :--- | :--- | :--- | :--- |
| id | integer | Yes | Numeric auto-increment user ID |
| avatar_url | string | No | Link to user avatar image |

Response (200 OK):
\`\`\`json
{
  "id": 1042,
  "username": "alex_dev",
  "avatar_url": "https://cdn.example.com/a/1042.jpg",
  "status": "active"
}
\`\`\`

User Management actions:
- Create user: \`POST /api/v1/users\`
- Note: \`deleteUser() unavailable\` via public REST API.

## 4. Search API
Search query endpoint:
\`\`\`http
GET /api/v1/search?q={query}&limit=20
\`\`\`

### Parameters
| Parameter | Type | Default | Description |
| :--- | :--- | :--- | :--- |
| q | string | "" | Free text query keyword |
| limit | integer | 20 | Results per page |
| order | string | asc | Sort direction: asc or desc |

## 5. Storage & File Upload
Upload media assets:
\`\`\`http
POST /api/v1/files/upload
Content-Type: multipart/form-data
\`\`\`
- Maximum size: 5 MB
- Checksum: No checksum verification required.

## 6. Payment Gateway
Process customer charges:
\`\`\`http
POST /api/v1/charges
\`\`\`
- Idempotency: Optional Idempotency-Key header.
- Currency: USD only.
\`\`\`json
{
  "amount": 4900,
  "currency": "USD"
}
\`\`\`

## 7. Webhook Configuration
Webhook delivery standard:
- Signatures computed with: HMAC-MD5 Signature
- Retries: 3 retries linear (1m interval)
- Billing Event: \`invoice.created\`
`
};

export const SAMPLE_NEW_DOCUMENT: DocumentFile = {
  id: 'DOC-NEW-01',
  name: 'CloudCore_Platform_API_v2.0.md',
  version: 'v2.0.1',
  type: 'Markdown',
  size: '178 KB',
  uploadDate: '2026-09-12',
  status: 'Ready',
  content: `# CloudCore Platform API Specification (v2.0)

## 1. Overview & Architecture
Base URL: \`https://staging-api.example.io/v2\`
Protocol: HTTP/2 over TLS 1.3 enforced (TLS 1.0/1.1 disabled)
Supported SDK Runtimes: Node.js >= 18 LTS, Python >= 3.10

## 2. Authentication & Headers
Authentication is strictly JWT Bearer token with URI prefixing:
\`\`\`http
Authorization: Bearer <jwt_token>
Content-Type: application/json; charset=utf-8
X-Session-Token: <session_uuid>
\`\`\`
Global Rate Limit: 60 req/min with Tier Bursting (X-RateLimit-Reset).
Auth failures return \`HTTP 401 Unauthorized\`.

## 3. User API
Retrieve user details by UUID string:
\`\`\`http
GET /api/v2/users/{id}
\`\`\`

### Parameters
| Name | Type | Required | Description |
| :--- | :--- | :--- | :--- |
| id | string | Yes | UUIDv4 identifier string |
| profile_image_url | string | No | Link to user profile picture |

Response (200 OK):
\`\`\`json
{
  "id": "usr_9f81a4e2",
  "username": "alex_dev",
  "profile_image_url": "https://cdn.example.com/p/9f81.jpg",
  "status": "active"
}
\`\`\`

User Management actions:
- Create user: \`POST /api/v2/users\`
- Delete user: \`DELETE /api/v2/users/{user_id}\` (Soft-deletion with audit trail)

## 4. Search API
Search query endpoint:
\`\`\`http
GET /api/v2/search?query={keyword}&limit=25
\`\`\`

### Parameters
| Parameter | Type | Default | Description |
| :--- | :--- | :--- | :--- |
| query | string | "" | Search term string |
| limit | integer | 25 | Results per page |
| sort_dir | string | asc | Sort direction: asc or desc |

## 5. Storage & File Upload
Upload media assets:
\`\`\`http
POST /api/v2/files/upload
Content-Type: multipart/form-data
Content-MD5: <base64_digest>
\`\`\`
- Maximum size: 10 MB
- Checksum: Content-MD5 header mandatory for PUT/POST.

## 6. Payment Gateway
Process customer charges:
\`\`\`http
POST /api/v2/charges
\`\`\`
- Idempotency: Mandatory Idempotency-Key on POST /charges.
- Currency: ISO-4217 (multi-currency: USD, EUR, GBP, JPY).
\`\`\`json
{
  "amount": 4900,
  "currency": "EUR"
}
\`\`\`

## 7. Webhook Configuration
Webhook delivery standard:
- Signatures computed with: HMAC-SHA256 Signature
- Retries: 5 retries exponential backoff (2s, 4s, 8s, 16s, 32s)
- Billing Event: \`billing.invoice.generated\`
`
};
