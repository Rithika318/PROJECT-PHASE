import React from 'react';
import {
  HelpCircle,
  BookOpen,
  Cpu,
  Layers,
  Scale,
  Terminal,
  CheckCircle2,
  AlertTriangle,
  GitCompare,
  FileText
} from 'lucide-react';

export const HelpPage: React.FC = () => {
  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Header */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-indigo-900 via-indigo-800 to-violet-900 text-white shadow-lg">
        <div className="flex items-center gap-2 text-indigo-300 text-xs font-semibold uppercase tracking-wider mb-1">
          <BookOpen className="w-4 h-4 text-cyan-400" />
          <span>Documentation & Architecture Guide</span>
        </div>
        <h1 className="text-2xl font-black text-white">System Architecture & User Manual</h1>
        <p className="text-xs sm:text-sm text-indigo-200 mt-1">
          Comprehensive operational guide for the LLM-Based Technical Documentation Consistency Checker.
        </p>
      </div>

      {/* Section 1: The 5 Issue Categories */}
      <div className="glass-card-light rounded-2xl p-6 space-y-4">
        <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
          <Layers className="w-4 h-4 text-indigo-600" />
          <span>The 5 Canonical Discrepancy Categories</span>
        </h3>
        <p className="text-xs text-slate-600 leading-relaxed">
          The consistency checker evaluates document pairs across five formalized semantic categories:
        </p>

        <div className="space-y-3 text-xs">
          <div className="p-3.5 rounded-xl bg-emerald-50/70 border border-emerald-200">
            <span className="font-bold text-emerald-800 text-xs flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" /> A. Consistent
            </span>
            <p className="text-emerald-950 mt-1 leading-relaxed">
              Both versions express compatible requirements, behavior, and configurations. Even if exact phrasing differs, the semantic propositions agree.
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-rose-50/70 border border-rose-200">
            <span className="font-bold text-rose-800 text-xs flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4 text-rose-600" /> B. Contradiction
            </span>
            <p className="text-rose-950 mt-1 leading-relaxed">
              Two sections describe mutually incompatible requirements, such as conflicting network port bindings (e.g., port 8080 vs port 9090), different memory minimums, or altered boolean configurations without migration warnings.
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-amber-50/70 border border-amber-200">
            <span className="font-bold text-amber-800 text-xs flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4 text-amber-600" /> C. Outdated Information
            </span>
            <p className="text-amber-950 mt-1 leading-relaxed">
              An instruction or parameter in the older document is superseded, removed, or marked as deprecated by newer specifications.
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-blue-50/70 border border-blue-200">
            <span className="font-bold text-blue-800 text-xs flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4 text-blue-600" /> D. Missing Content
            </span>
            <p className="text-blue-950 mt-1 leading-relaxed">
              An essential requirement, security step, parameter, or diagnostic section present in the baseline document has no corresponding coverage in the target document.
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-purple-50/70 border border-purple-200">
            <span className="font-bold text-purple-800 text-xs flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4 text-purple-600" /> E. Terminology Inconsistency
            </span>
            <p className="text-purple-950 mt-1 leading-relaxed">
              Different names are used for the same technical concept without synonym clarification (e.g. <code>api_key</code> vs <code>auth_token</code>, <code>master</code> vs <code>main</code>, <code>account_id</code> vs <code>tenant_id</code>).
            </p>
          </div>
        </div>
      </div>

      {/* Section 2: Mathematical Consistency Formula */}
      <div className="glass-card-light rounded-2xl p-6 space-y-4">
        <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
          <Scale className="w-4 h-4 text-violet-600" />
          <span>Mathematical Consistency Score Calculation</span>
        </h3>
        <p className="text-xs text-slate-600 leading-relaxed">
          The consistency rating (0 to 100) is a transparent, deterministic mathematical function:
        </p>

        <div className="p-4 rounded-xl bg-slate-900 text-slate-100 font-mono text-xs space-y-2">
          <p className="text-cyan-300 font-bold">Total Weighted Penalty = Σ ( SeverityWeight(issue) × Confidence(issue) )</p>
          <p className="text-slate-400">Baseline Capacity = Max( Total Matched Pairs × 15.0, 50.0 )</p>
          <p className="text-emerald-400 font-bold">Consistency Score = Max( 0.0, 100.0 - ( Total Penalty / Baseline Capacity × 100.0 ) )</p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-xs">
          <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200">
            <span className="font-bold text-emerald-800 block">90 - 100</span>
            <span className="text-[10px] text-slate-500">Excellent consistency</span>
          </div>
          <div className="p-2.5 rounded-xl bg-indigo-50 border border-indigo-200">
            <span className="font-bold text-indigo-800 block">75 - 89</span>
            <span className="text-[10px] text-slate-500">Good consistency</span>
          </div>
          <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-200">
            <span className="font-bold text-amber-800 block">55 - 74</span>
            <span className="text-[10px] text-slate-500">Needs review</span>
          </div>
          <div className="p-2.5 rounded-xl bg-rose-50 border border-rose-200">
            <span className="font-bold text-rose-800 block">0 - 54</span>
            <span className="text-[10px] text-slate-500">Significant inconsistencies</span>
          </div>
        </div>
      </div>

      {/* Section 3: Ollama & Local Llama 3.1 Setup */}
      <div className="glass-card-light rounded-2xl p-6 space-y-4">
        <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
          <Cpu className="w-4 h-4 text-cyan-600" />
          <span>Setting Up Ollama & Llama 3.1 8B Locally</span>
        </h3>
        <p className="text-xs text-slate-600 leading-relaxed">
          The system runs 100% locally with zero cloud API keys or fees. Follow these simple steps to run Llama 3.1 locally:
        </p>

        <div className="space-y-3 text-xs">
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5">
            <span className="font-bold text-slate-900">Step 1: Install Ollama</span>
            <p className="text-slate-500 text-[11px]">Download and install the Windows installer from the official website:</p>
            <a href="https://ollama.com" target="_blank" rel="noreferrer" className="text-indigo-600 font-semibold hover:underline">
              https://ollama.com
            </a>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5">
            <span className="font-bold text-slate-900">Step 2: Pull the Llama 3.1 8B Instruct Model</span>
            <p className="text-slate-500 text-[11px]">Open PowerShell or Command Prompt and run:</p>
            <div className="p-2.5 rounded-lg bg-slate-900 text-cyan-300 font-mono text-xs">
              ollama pull llama3.1:8b
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5">
            <span className="font-bold text-slate-900">Step 3: Verify Model Status</span>
            <p className="text-slate-500 text-[11px]">
              Navigate to the <b>Model Status</b> page in this application. The Llama 3.1 8B indicator will automatically reflect a green <b>Ready</b> status.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
