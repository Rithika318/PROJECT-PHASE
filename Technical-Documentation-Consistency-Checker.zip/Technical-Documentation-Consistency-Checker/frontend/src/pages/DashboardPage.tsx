import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api } from '../services/api';
import {
  FileText,
  AlertTriangle,
  CheckCircle2,
  TrendingUp,
  FileCheck2,
  ArrowRight,
  Sparkles,
  GitCompare,
  BarChart2,
  Clock,
  Layers,
  ShieldAlert,
  Loader2
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid
} from 'recharts';

export const DashboardPage: React.FC = () => {
  const navigate = useNavigate();
  const [summary, setSummary] = useState<any>(null);
  const [charts, setCharts] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadDashboardData = async () => {
      try {
        setLoading(true);
        const [summaryData, chartsData] = await Promise.all([
          api.getDashboardSummary(),
          api.getDashboardCharts()
        ]);
        setSummary(summaryData);
        setCharts(chartsData);
      } catch (err: any) {
        console.error('Failed to load dashboard statistics', err);
        setError(err.message || 'Could not load analytics data.');
      } finally {
        setLoading(false);
      }
    };
    loadDashboardData();
  }, []);

  const CATEGORY_COLORS: Record<string, string> = {
    'Consistent': '#10B981',
    'Contradiction': '#EF4444',
    'Outdated Information': '#F59E0B',
    'Missing Content': '#3B82F6',
    'Terminology Inconsistency': '#8B5CF6'
  };

  const SEVERITY_COLORS: Record<string, string> = {
    'Critical': '#EF4444',
    'High': '#F97316',
    'Medium': '#F59E0B',
    'Low': '#10B981',
    'Informational': '#6366F1'
  };

  if (loading) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center gap-3">
        <Loader2 className="w-8 h-8 text-indigo-600 animate-spin" />
        <p className="text-sm text-slate-500 font-medium">Aggregating documentation consistency analytics...</p>
      </div>
    );
  }

  const hasData = summary && summary.total_analyses > 0;

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-6 rounded-2xl bg-gradient-to-r from-indigo-900 via-indigo-800 to-violet-900 text-white shadow-lg relative overflow-hidden">
        {/* Subtle decorative circles */}
        <div className="absolute -right-10 -bottom-10 w-48 h-48 bg-cyan-400/10 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute left-1/3 -top-10 w-40 h-40 bg-indigo-500/20 rounded-full blur-xl pointer-events-none" />

        <div className="relative z-10">
          <div className="flex items-center gap-2 text-indigo-200 text-xs font-semibold uppercase tracking-wider mb-1">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span>AI Verification Dashboard</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
            Technical Documentation Consistency Audit
          </h1>
          <p className="text-sm text-indigo-200/90 max-w-2xl mt-1">
            Local semantic comparison powered by Sentence-BERT, DeBERTa-v3 NLI, and local Llama 3.1 8B Instruct.
          </p>
        </div>

        <div className="relative z-10 shrink-0">
          <Link
            to="/new-analysis"
            className="inline-flex items-center gap-2.5 px-5 py-3 rounded-xl bg-gradient-to-r from-teal-400 to-cyan-400 hover:from-teal-300 hover:to-cyan-300 text-slate-950 font-bold text-sm shadow-md shadow-cyan-500/20 transition-all hover:scale-[1.02] active:scale-[0.98]"
          >
            <GitCompare className="w-4 h-4" />
            <span>Start New Analysis</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </div>

      {/* Top 6 Summary Metric Cards as specified in PPT & project requirements */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {/* Total Comparisons Performed */}
        <div className="glass-card-light rounded-2xl p-4 transition-all hover:-translate-y-0.5">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold">Comparisons</span>
            <div className="w-7 h-7 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <Layers className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-slate-900">{summary?.total_analyses || 0}</p>
          <p className="text-[11px] text-slate-500 mt-0.5">Total performed</p>
        </div>

        {/* Total Issues Detected */}
        <div className="glass-card-light rounded-2xl p-4 transition-all hover:-translate-y-0.5">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold">Issues Detected</span>
            <div className="w-7 h-7 rounded-lg bg-rose-50 text-rose-600 flex items-center justify-center">
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-rose-600">{summary?.total_issues || 0}</p>
          <p className="text-[11px] text-slate-500 mt-0.5">Discrepancies found</p>
        </div>

        {/* Avg Consistency Score */}
        <div className="glass-card-light rounded-2xl p-4 transition-all hover:-translate-y-0.5">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold">Consistency Score</span>
            <div className="w-7 h-7 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-emerald-600">
            {summary?.average_consistency_score !== undefined ? `${summary.average_consistency_score}%` : '100%'}
          </p>
          <p className="text-[11px] text-slate-500 mt-0.5">Normalized benchmark</p>
        </div>

        {/* Pending Reviews */}
        <div
          onClick={() => navigate('/reviews?verification_status=pending')}
          className="cursor-pointer glass-card-light rounded-2xl p-4 transition-all hover:-translate-y-0.5"
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold">Pending Reviews</span>
            <div className="w-7 h-7 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-amber-600">{summary?.pending_reviews || 0}</p>
          <p className="text-[11px] text-slate-500 mt-0.5">Awaiting review</p>
        </div>

        {/* Approved Findings */}
        <div
          onClick={() => navigate('/reviews?verification_status=confirmed')}
          className="cursor-pointer glass-card-light rounded-2xl p-4 transition-all hover:-translate-y-0.5"
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold">Approved</span>
            <div className="w-7 h-7 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-emerald-700">{summary?.approved_findings || 0}</p>
          <p className="text-[11px] text-slate-500 mt-0.5">Confirmed findings</p>
        </div>

        {/* Corrected Findings */}
        <div
          onClick={() => navigate('/reviews?verification_status=corrected')}
          className="cursor-pointer glass-card-light rounded-2xl p-4 transition-all hover:-translate-y-0.5"
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold">Corrected</span>
            <div className="w-7 h-7 rounded-lg bg-cyan-50 text-cyan-600 flex items-center justify-center">
              <FileCheck2 className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-cyan-700">{summary?.corrected_findings || 0}</p>
          <p className="text-[11px] text-slate-500 mt-0.5">Rectified in docs</p>
        </div>
      </div>

      {/* Main Charts Section */}
      {hasData ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Chart 1: Consistency Score Trend */}
          <div className="glass-card-light rounded-2xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="font-bold text-sm text-slate-900">Consistency Score Progression</h3>
                <p className="text-xs text-slate-500">Historical documentation consistency score trend over time</p>
              </div>
              <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700">0 - 100 Index</span>
            </div>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={charts?.score_trends || []} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <defs>
                    <linearGradient id="scoreGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#4F46E5" stopOpacity={0.4} />
                      <stop offset="95%" stopColor="#4F46E5" stopOpacity={0.0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
                  <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                  <YAxis domain={[0, 100]} tick={{ fontSize: 11 }} />
                  <Tooltip contentStyle={{ backgroundColor: '#1E293B', color: '#FFF', borderRadius: '8px', fontSize: '12px' }} />
                  <Area type="monotone" dataKey="score" stroke="#4F46E5" strokeWidth={2.5} fillOpacity={1} fill="url(#scoreGradient)" name="Consistency Score" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Chart 2: Category Distribution */}
          <div className="glass-card-light rounded-2xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="font-bold text-sm text-slate-900">Issue Category Distribution</h3>
                <p className="text-xs text-slate-500">Proportion across the 5 canonical discrepancy classes</p>
              </div>
              <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700">5 Categories</span>
            </div>
            <div className="h-64 flex items-center justify-center">
              {charts?.category_distribution?.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={charts.category_distribution}
                      dataKey="value"
                      nameKey="name"
                      cx="50%"
                      cy="50%"
                      innerRadius={55}
                      outerRadius={85}
                      paddingAngle={3}
                    >
                      {charts.category_distribution.map((entry: any, index: number) => (
                        <Cell key={`cell-${index}`} fill={CATEGORY_COLORS[entry.name] || '#6366F1'} />
                      ))}
                    </Pie>
                    <Tooltip contentStyle={{ backgroundColor: '#1E293B', color: '#FFF', borderRadius: '8px', fontSize: '12px' }} />
                    <Legend wrapperStyle={{ fontSize: '11px' }} />
                  </PieChart>
                </ResponsiveContainer>
              ) : (
                <p className="text-xs text-slate-400">No category discrepancies recorded yet.</p>
              )}
            </div>
          </div>

          {/* Chart 3: Severity Distribution */}
          <div className="glass-card-light rounded-2xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="font-bold text-sm text-slate-900">Severity Breakdown</h3>
                <p className="text-xs text-slate-500">Classification from Critical conflicts down to Informational</p>
              </div>
            </div>
            <div className="h-60">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={charts?.severity_distribution || []} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
                  <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 11 }} />
                  <Tooltip contentStyle={{ backgroundColor: '#1E293B', color: '#FFF', borderRadius: '8px', fontSize: '12px' }} />
                  <Bar dataKey="count" radius={[6, 6, 0, 0]} name="Issues">
                    {(charts?.severity_distribution || []).map((entry: any, index: number) => (
                      <Cell key={`sev-${index}`} fill={SEVERITY_COLORS[entry.name] || '#6366F1'} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Chart 4: Confidence Score Distribution */}
          <div className="glass-card-light rounded-2xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="font-bold text-sm text-slate-900">AI Confidence Calibration</h3>
                <p className="text-xs text-slate-500">Distribution of model confidence scores for detected issues</p>
              </div>
            </div>
            <div className="h-60">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={charts?.confidence_distribution || []} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
                  <XAxis dataKey="range" tick={{ fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 11 }} />
                  <Tooltip contentStyle={{ backgroundColor: '#1E293B', color: '#FFF', borderRadius: '8px', fontSize: '12px' }} />
                  <Bar dataKey="count" fill="#7C3AED" radius={[6, 6, 0, 0]} name="Issue Count" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      ) : (
        /* Empty State */
        <div className="glass-card-light rounded-3xl p-10 text-center space-y-4 border border-dashed border-indigo-200">
          <div className="w-16 h-16 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center mx-auto shadow-inner">
            <GitCompare className="w-8 h-8" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-slate-900">No Documentation Analyses Yet</h3>
            <p className="text-xs sm:text-sm text-slate-500 max-w-md mx-auto mt-1">
              Upload two versions of your technical documentation (e.g. API specification v1.0 vs v2.0)
              to start your first automated consistency audit.
            </p>
          </div>
          <div className="pt-2">
            <Link
              to="/new-analysis"
              className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs sm:text-sm shadow-md shadow-indigo-500/20 transition-all"
            >
              Start New Analysis
            </Link>
          </div>
        </div>
      )}

      {/* Recent Analyses Table */}
      {hasData && (
        <div className="glass-card-light rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h3 className="font-bold text-sm text-slate-900">Recent Documentation Audits</h3>
              <p className="text-xs text-slate-500">Latest comparative analysis runs and consistency status</p>
            </div>
            <Link to="/history" className="text-xs text-indigo-600 hover:text-indigo-800 font-semibold flex items-center gap-1">
              View All History <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 font-semibold uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="py-2.5 px-3 rounded-l-lg">Title</th>
                  <th className="py-2.5 px-3">Documents Compared</th>
                  <th className="py-2.5 px-3">Date</th>
                  <th className="py-2.5 px-3">Score</th>
                  <th className="py-2.5 px-3">Issues</th>
                  <th className="py-2.5 px-3">Model Engine</th>
                  <th className="py-2.5 px-3 rounded-r-lg text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {summary.recent_analyses.map((a: any) => (
                  <tr key={a.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3 px-3 font-semibold text-slate-900">{a.title}</td>
                    <td className="py-3 px-3 text-slate-600">
                      <div className="flex items-center gap-1.5 font-mono text-[11px]">
                        <span className="text-slate-700 truncate max-w-[120px]">{a.old_doc_name || 'Old Doc'}</span>
                        <span className="text-slate-400">vs</span>
                        <span className="text-indigo-700 truncate max-w-[120px]">{a.new_doc_name || 'New Doc'}</span>
                      </div>
                    </td>
                    <td className="py-3 px-3 text-slate-500">
                      {new Date(a.created_at).toLocaleDateString()}
                    </td>
                    <td className="py-3 px-3">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded-full font-bold text-[11px] ${
                        a.consistency_score >= 85 ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' :
                        a.consistency_score >= 70 ? 'bg-amber-50 text-amber-700 border border-amber-200' :
                        'bg-rose-50 text-rose-700 border border-rose-200'
                      }`}>
                        {a.consistency_score}%
                      </span>
                    </td>
                    <td className="py-3 px-3">
                      <span className="font-semibold text-slate-800">{a.confirmed_issues_count}</span>
                      <span className="text-slate-400 text-[10px] ml-1">issues</span>
                    </td>
                    <td className="py-3 px-3 text-[11px] text-slate-500 truncate max-w-[140px]">
                      {a.model_used}
                    </td>
                    <td className="py-3 px-3 text-right">
                      <button
                        onClick={() => navigate(`/results/${a.id}`)}
                        className="px-2.5 py-1 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-semibold text-xs transition-colors"
                      >
                        View Report
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
