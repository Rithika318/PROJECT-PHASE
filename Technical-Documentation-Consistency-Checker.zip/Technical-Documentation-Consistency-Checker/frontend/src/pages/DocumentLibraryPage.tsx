import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import {
  FolderKanban,
  FileText,
  Upload,
  Trash2,
  Eye,
  Search,
  CheckCircle2,
  AlertCircle,
  X,
  Loader2,
  Layers
} from 'lucide-react';

export const DocumentLibraryPage: React.FC = () => {
  const [documents, setDocuments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState<string>('All');
  const [activeDocDetail, setActiveDocDetail] = useState<any>(null);
  const [isDeleting, setIsDeleting] = useState<string | null>(null);

  const fetchDocs = async () => {
    try {
      setLoading(true);
      const res = await api.getDocuments();
      setDocuments(res);
    } catch (err: any) {
      console.error('Failed to load documents', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDocs();
  }, []);

  const handleDelete = async (id: string, name: string) => {
    if (!window.confirm(`Are you sure you want to delete '${name}'? This will remove its chunks and local storage.`)) {
      return;
    }
    try {
      setIsDeleting(id);
      await api.deleteDocument(id);
      setDocuments((prev) => prev.filter((d) => d.id !== id));
      if (activeDocDetail?.id === id) {
        setActiveDocDetail(null);
      }
    } catch (err: any) {
      alert(`Delete failed: ${err.message}`);
    } finally {
      setIsDeleting(null);
    }
  };

  const handleInspectDoc = async (id: string) => {
    try {
      const detail = await api.getDocument(id);
      setActiveDocDetail(detail);
    } catch (err: any) {
      alert(`Could not load document details: ${err.message}`);
    }
  };

  const filteredDocs = documents.filter((doc) => {
    const matchesSearch = doc.filename.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = selectedType === 'All' || doc.file_type.toLowerCase() === selectedType.toLowerCase();
    return matchesSearch && matchesType;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-2xl bg-gradient-to-r from-indigo-900 via-indigo-800 to-violet-950 text-white shadow-lg">
        <div>
          <div className="flex items-center gap-2 text-indigo-300 text-xs font-semibold uppercase tracking-wider mb-1">
            <FolderKanban className="w-4 h-4 text-cyan-400" />
            <span>Document Repository</span>
          </div>
          <h1 className="text-2xl font-black text-white">Technical Document Library</h1>
          <p className="text-xs sm:text-sm text-indigo-200 mt-1">
            Browse, inspect semantic chunks, and manage stored PDF, DOCX, and TXT specifications.
          </p>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="glass-card-light rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative flex-1 w-full sm:w-auto">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search documents by filename..."
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
          <span className="text-xs font-semibold text-slate-500">Format:</span>
          <select
            value={selectedType}
            onChange={(e) => setSelectedType(e.target.value)}
            className="px-3 py-1.5 rounded-xl border border-slate-300 text-xs font-semibold text-slate-700 bg-white"
          >
            <option value="All">All Formats</option>
            <option value="pdf">PDF</option>
            <option value="docx">DOCX</option>
            <option value="txt">TXT</option>
          </select>
        </div>
      </div>

      {/* Documents Table */}
      {loading ? (
        <div className="min-h-[40vh] flex flex-col items-center justify-center gap-3">
          <Loader2 className="w-8 h-8 text-indigo-600 animate-spin" />
          <p className="text-xs text-slate-500 font-medium">Loading document library records...</p>
        </div>
      ) : filteredDocs.length === 0 ? (
        <div className="glass-card-light rounded-3xl p-10 text-center space-y-3">
          <FileText className="w-12 h-12 text-slate-300 mx-auto" />
          <p className="font-bold text-sm text-slate-700">No Documents Found</p>
          <p className="text-xs text-slate-400">Upload documents via the New Document Analysis page to populate your library.</p>
        </div>
      ) : (
        <div className="glass-card-light rounded-2xl overflow-hidden shadow-sm">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 font-semibold uppercase tracking-wider text-[10px]">
              <tr>
                <th className="py-3 px-4">Document Name</th>
                <th className="py-3 px-4">Format</th>
                <th className="py-3 px-4">File Size</th>
                <th className="py-3 px-4">Word Count</th>
                <th className="py-3 px-4">Chunks</th>
                <th className="py-3 px-4">Upload Date</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredDocs.map((doc) => (
                <tr key={doc.id} className="hover:bg-slate-50/80 transition-colors">
                  <td className="py-3 px-4 font-bold text-slate-900 flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center shrink-0">
                      <FileText className="w-4 h-4" />
                    </div>
                    <span className="truncate max-w-xs">{doc.filename}</span>
                  </td>
                  <td className="py-3 px-4">
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase bg-slate-100 text-slate-700">
                      {doc.file_type}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-slate-600 font-mono">
                    {(doc.file_size / 1024).toFixed(1)} KB
                  </td>
                  <td className="py-3 px-4 text-slate-600 font-mono">
                    {doc.word_count.toLocaleString()}
                  </td>
                  <td className="py-3 px-4 font-semibold text-indigo-700">
                    {doc.chunk_count}
                  </td>
                  <td className="py-3 px-4 text-slate-500">
                    {new Date(doc.created_at).toLocaleDateString()}
                  </td>
                  <td className="py-3 px-4">
                    <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-600">
                      <CheckCircle2 className="w-3.5 h-3.5" /> Ready
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        onClick={() => handleInspectDoc(doc.id)}
                        className="p-1.5 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-700 transition-colors"
                        title="Inspect parsed chunks"
                      >
                        <Eye className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDelete(doc.id, doc.filename)}
                        disabled={isDeleting === doc.id}
                        className="p-1.5 rounded-lg bg-slate-100 hover:bg-red-50 text-slate-500 hover:text-red-600 transition-colors"
                        title="Delete document"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Chunk Inspection Modal */}
      {activeDocDetail && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-3xl w-full max-h-[85vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden">
            <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50/60">
              <div>
                <span className="text-[10px] font-mono font-bold text-indigo-600 uppercase">Document Inspection</span>
                <h3 className="text-base font-bold text-slate-900 truncate max-w-md">{activeDocDetail.filename}</h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  {activeDocDetail.chunk_count} semantic chunks • {activeDocDetail.section_count} headings detected
                </p>
              </div>
              <button
                onClick={() => setActiveDocDetail(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 overflow-y-auto space-y-3 divide-y divide-slate-100 flex-1">
              {(activeDocDetail.chunks || []).map((chunk: any) => (
                <div key={chunk.id} className="pt-3 first:pt-0 space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-indigo-900">
                      Chunk #{chunk.chunk_index + 1}: {chunk.section_heading || 'General Section'}
                    </span>
                    <span className="text-[10px] font-mono text-slate-400">
                      {chunk.token_count} words {chunk.page_number ? `• Page ${chunk.page_number}` : ''}
                    </span>
                  </div>
                  <p className="text-xs text-slate-700 font-mono bg-slate-50 p-3 rounded-xl border border-slate-200/80 leading-relaxed whitespace-pre-wrap">
                    {chunk.content}
                  </p>
                </div>
              ))}
            </div>

            <div className="p-4 border-t border-slate-100 bg-slate-50/50 text-right">
              <button
                onClick={() => setActiveDocDetail(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-900 text-white font-semibold text-xs transition-colors"
              >
                Close Preview
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
