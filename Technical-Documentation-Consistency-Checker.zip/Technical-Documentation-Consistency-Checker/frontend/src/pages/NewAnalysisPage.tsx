import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../services/api';
import {
  Upload,
  FileText,
  CheckCircle2,
  AlertCircle,
  X,
  Sparkles,
  ArrowRight,
  GitCompare,
  Loader2,
  FileCheck,
  Brain,
  Search,
  Scale,
  Cpu
} from 'lucide-react';

export const NewAnalysisPage: React.FC = () => {
  const navigate = useNavigate();

  // Document states
  const [oldFile, setOldFile] = useState<File | null>(null);
  const [newFile, setNewFile] = useState<File | null>(null);
  const [oldDocRecord, setOldDocRecord] = useState<any>(null);
  const [newDocRecord, setNewDocRecord] = useState<any>(null);

  // Form states
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisId, setAnalysisId] = useState<string | null>(null);
  const [currentStage, setCurrentStage] = useState<number>(1);
  const [stageName, setStageName] = useState<string>('Preparing pipeline');
  const [progressPercent, setProgressPercent] = useState<number>(0);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Poll analysis status when in analyzing state
  useEffect(() => {
    let timer: any;
    if (isAnalyzing && analysisId) {
      timer = setInterval(async () => {
        try {
          const statusRes = await api.getAnalysisStatus(analysisId);
          setCurrentStage(statusRes.progress_stage);
          setStageName(statusRes.stage_name);
          setProgressPercent(statusRes.progress_percent);

          if (statusRes.is_completed) {
            clearInterval(timer);
            setIsAnalyzing(false);
            if (statusRes.status === 'completed') {
              navigate(`/results/${analysisId}`);
            } else {
              setErrorMessage(statusRes.error_message || 'Analysis processing failed.');
            }
          }
        } catch (err: any) {
          console.warn('Failed to poll status', err);
        }
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [isAnalyzing, analysisId, navigate]);

  // Handle file drop / select
  const handleFileUpload = async (file: File, type: 'old' | 'new') => {
    setErrorMessage(null);
    const ext = file.name.split('.').pop()?.toLowerCase();
    if (ext !== 'pdf' && ext !== 'docx' && ext !== 'txt') {
      setErrorMessage(`Invalid file format '.${ext}'. Please upload a PDF, DOCX, or TXT file.`);
      return;
    }
    if (file.size === 0) {
      setErrorMessage('The selected file is empty (0 bytes).');
      return;
    }
    if (file.size > 50 * 1024 * 1024) {
      setErrorMessage('File size exceeds the 50MB maximum upload limit.');
      return;
    }

    try {
      setIsUploading(true);
      const uploadedDoc = await api.uploadDocument(file);
      if (type === 'old') {
        setOldFile(file);
        setOldDocRecord(uploadedDoc);
        if (!title) {
          setTitle(`Audit: ${file.name.replace(/\.[^/.]+$/, '')}`);
        }
      } else {
        setNewFile(file);
        setNewDocRecord(uploadedDoc);
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to upload document.');
    } finally {
      setIsUploading(false);
    }
  };

  // Quick One-Click Demo Loader
  const handleLoadSampleDocs = async () => {
    setErrorMessage(null);
    setIsUploading(true);
    try {
      const sampleDocs = await api.loadSampleDocuments();
      if (sampleDocs.length >= 2) {
        setOldDocRecord(sampleDocs[0]);
        setNewDocRecord(sampleDocs[1]);
        setOldFile(new File([''], sampleDocs[0].filename, { type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' }));
        setNewFile(new File([''], sampleDocs[1].filename, { type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' }));
        setTitle('Comparative Audit: Cloud Core API v1.0 vs v2.0 Specification');
        setDescription('Demonstration audit checking consistency between Cloud API baseline and major v2.0 release.');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to load sample documents.');
    } finally {
      setIsUploading(false);
    }
  };

  const handleStartAnalysis = async () => {
    if (!oldDocRecord || !newDocRecord) {
      setErrorMessage('Please upload both the Old Version and New Version documents before starting.');
      return;
    }
    if (!title.trim()) {
      setErrorMessage('Please enter an analysis project title.');
      return;
    }

    setIsAnalyzing(true);
    setCurrentStage(1);
    setProgressPercent(10);
    setStageName('Dispatching analysis job...');
    setErrorMessage(null);

    try {
      const res = await api.createAnalysis({
        title,
        description,
        old_doc_id: oldDocRecord.id,
        new_doc_id: newDocRecord.id,
      });
      setAnalysisId(res.id);
    } catch (err: any) {
      setIsAnalyzing(false);
      setErrorMessage(err.message || 'Failed to initiate comparative analysis.');
    }
  };

  const STAGES = [
    { num: 1, name: 'Uploading & validating documents', icon: Upload },
    { num: 2, name: 'Extracting text & preserving headings', icon: FileText },
    { num: 3, name: 'Preprocessing & semantic chunking', icon: FileCheck },
    { num: 4, name: 'Generating Sentence-BERT embeddings', icon: Brain },
    { num: 5, name: 'Retrieving related sections via cosine similarity', icon: Search },
    { num: 6, name: 'Evaluating candidate discrepancies with DeBERTa-v3 NLI', icon: Scale },
    { num: 7, name: 'Verifying evidence & severity using local Llama 3.1 8B', icon: Cpu },
    { num: 8, name: 'Calculating consistency score and compiling report', icon: CheckCircle2 },
  ];

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-2xl bg-gradient-to-r from-indigo-900 via-violet-900 to-indigo-950 text-white shadow-lg">
        <div>
          <div className="flex items-center gap-2 text-indigo-300 text-xs font-semibold uppercase tracking-wider mb-1">
            <GitCompare className="w-4 h-4 text-cyan-400" />
            <span>Dual-Document Comparison Engine</span>
          </div>
          <h1 className="text-2xl font-black text-white">New Documentation Consistency Analysis</h1>
          <p className="text-xs sm:text-sm text-indigo-200 mt-1 max-w-2xl">
            Upload two versions of technical documentation. The AI pipeline will parse, embed, classify, and verify all discrepancies.
          </p>
        </div>

        <button
          type="button"
          onClick={handleLoadSampleDocs}
          disabled={isUploading || isAnalyzing}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 border border-white/20 text-white text-xs font-semibold transition-all hover:scale-[1.02] shadow-sm disabled:opacity-50"
        >
          <Sparkles className="w-3.5 h-3.5 text-cyan-300" />
          <span>Load Demo Documents (v1.0 & v2.0)</span>
        </button>
      </div>

      {/* Error Alert */}
      {errorMessage && (
        <div className="p-4 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs flex items-center justify-between gap-3 shadow-sm">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-red-500 shrink-0" />
            <span>{errorMessage}</span>
          </div>
          <button onClick={() => setErrorMessage(null)} className="text-red-400 hover:text-red-600">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Upload Panels (Side-by-Side) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Old Version Panel */}
        <div className="glass-card-light rounded-2xl p-6 space-y-4 border-2 border-dashed border-indigo-200 hover:border-indigo-400 transition-colors">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-slate-100 text-slate-700 font-bold text-xs flex items-center justify-center">1</span>
              <h3 className="font-bold text-sm text-slate-900">Baseline Document (Old Version)</h3>
            </div>
            <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-slate-100 text-slate-600">PDF / DOCX / TXT</span>
          </div>

          {oldDocRecord ? (
            <div className="p-4 rounded-xl bg-indigo-50/70 border border-indigo-200 flex items-start justify-between gap-3">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-lg bg-indigo-600 text-white flex items-center justify-center shrink-0 shadow-sm">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <p className="font-bold text-xs text-slate-900 truncate max-w-[200px] sm:max-w-xs">{oldDocRecord.filename}</p>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    {(oldDocRecord.file_size / 1024).toFixed(1)} KB • {oldDocRecord.word_count} words • {oldDocRecord.section_count} sections
                  </p>
                  <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-emerald-600 mt-1">
                    <CheckCircle2 className="w-3 h-3" /> Successfully Extracted
                  </span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => { setOldFile(null); setOldDocRecord(null); }}
                className="text-slate-400 hover:text-red-500 transition-colors p-1"
                title="Remove file"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <label className="flex flex-col items-center justify-center p-8 rounded-xl bg-slate-50/80 hover:bg-slate-100/80 cursor-pointer transition-colors group">
              <Upload className="w-10 h-10 text-indigo-400 group-hover:scale-110 transition-transform mb-3" />
              <p className="text-xs font-semibold text-slate-700">Click to upload or drag & drop</p>
              <p className="text-[11px] text-slate-400 mt-1">Technical specification, API reference, or user manual</p>
              <input
                type="file"
                accept=".pdf,.docx,.txt"
                className="hidden"
                disabled={isUploading || isAnalyzing}
                onChange={(e) => e.target.files?.[0] && handleFileUpload(e.target.files[0], 'old')}
              />
            </label>
          )}
        </div>

        {/* New Version Panel */}
        <div className="glass-card-light rounded-2xl p-6 space-y-4 border-2 border-dashed border-violet-200 hover:border-violet-400 transition-colors">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-indigo-100 text-indigo-700 font-bold text-xs flex items-center justify-center">2</span>
              <h3 className="font-bold text-sm text-slate-900">Updated Document (New Version)</h3>
            </div>
            <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-violet-100 text-violet-700">Target Release</span>
          </div>

          {newDocRecord ? (
            <div className="p-4 rounded-xl bg-violet-50/70 border border-violet-200 flex items-start justify-between gap-3">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-lg bg-violet-600 text-white flex items-center justify-center shrink-0 shadow-sm">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <p className="font-bold text-xs text-slate-900 truncate max-w-[200px] sm:max-w-xs">{newDocRecord.filename}</p>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    {(newDocRecord.file_size / 1024).toFixed(1)} KB • {newDocRecord.word_count} words • {newDocRecord.section_count} sections
                  </p>
                  <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-emerald-600 mt-1">
                    <CheckCircle2 className="w-3 h-3" /> Successfully Extracted
                  </span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => { setNewFile(null); setNewDocRecord(null); }}
                className="text-slate-400 hover:text-red-500 transition-colors p-1"
                title="Remove file"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <label className="flex flex-col items-center justify-center p-8 rounded-xl bg-slate-50/80 hover:bg-slate-100/80 cursor-pointer transition-colors group">
              <Upload className="w-10 h-10 text-violet-400 group-hover:scale-110 transition-transform mb-3" />
              <p className="text-xs font-semibold text-slate-700">Click to upload or drag & drop</p>
              <p className="text-[11px] text-slate-400 mt-1">New version to check for contradictions & regressions</p>
              <input
                type="file"
                accept=".pdf,.docx,.txt"
                className="hidden"
                disabled={isUploading || isAnalyzing}
                onChange={(e) => e.target.files?.[0] && handleFileUpload(e.target.files[0], 'new')}
              />
            </label>
          )}
        </div>
      </div>

      {/* Comparison Details & Trigger Form */}
      <div className="glass-card-light rounded-2xl p-6 space-y-4">
        <h3 className="font-bold text-sm text-slate-900">Analysis Project Metadata</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Project / Comparison Title *</label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Cloud API v1.0 to v2.0 Architecture Consistency Review"
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs sm:text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Scope or Release Notes (Optional)</label>
            <input
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="e.g. Evaluates deprecated parameters and updated network ports"
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs sm:text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>
        </div>

        {/* Start Analysis Button */}
        <div className="pt-2">
          <button
            type="button"
            onClick={handleStartAnalysis}
            disabled={!oldDocRecord || !newDocRecord || !title || isUploading || isAnalyzing}
            className="w-full py-3.5 px-6 rounded-xl bg-gradient-to-r from-indigo-600 via-violet-600 to-cyan-500 hover:from-indigo-700 hover:to-cyan-600 text-white font-bold text-sm shadow-lg shadow-indigo-600/25 flex items-center justify-center gap-2 transition-all disabled:opacity-50 disabled:cursor-not-allowed group"
          >
            {isAnalyzing ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                <span>Running Comparative Analysis Pipeline...</span>
              </>
            ) : (
              <>
                <GitCompare className="w-5 h-5" />
                <span>Run End-to-End Consistency Analysis</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </>
            )}
          </button>
        </div>
      </div>

      {/* Animated 8-Stage Pipeline Progress Tracker */}
      {isAnalyzing && (
        <div className="glass-card-light rounded-3xl p-6 sm:p-8 space-y-6 border border-indigo-200 shadow-xl animate-fade-in">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-indigo-600 animate-ping" />
                <h3 className="font-extrabold text-base text-slate-900">
                  Executing Pipeline: Stage {currentStage} of 8
                </h3>
              </div>
              <p className="text-xs text-indigo-700 font-semibold mt-0.5">{stageName}</p>
            </div>
            <div className="text-right">
              <span className="text-2xl font-black text-indigo-600">{progressPercent}%</span>
              <p className="text-[10px] text-slate-500 uppercase tracking-wider">Overall Progress</p>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="w-full h-3 rounded-full bg-slate-100 overflow-hidden shadow-inner">
            <div
              className="h-full bg-gradient-to-r from-indigo-600 via-violet-600 to-cyan-400 rounded-full transition-all duration-500 ease-out"
              style={{ width: `${progressPercent}%` }}
            />
          </div>

          {/* 8 Distinct Pipeline Stages Visualizer */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 pt-2">
            {STAGES.map((s) => {
              const StageIcon = s.icon;
              const isPast = s.num < currentStage;
              const isCurrent = s.num === currentStage;
              return (
                <div
                  key={s.num}
                  className={`p-3 rounded-xl border text-xs transition-all ${
                    isCurrent
                      ? 'bg-indigo-50/90 border-indigo-500 text-indigo-900 font-bold shadow-md shadow-indigo-500/10 scale-[1.02]'
                      : isPast
                      ? 'bg-emerald-50/70 border-emerald-200 text-emerald-800'
                      : 'bg-slate-50/60 border-slate-200/70 text-slate-400 opacity-60'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-[10px] font-mono">Stage 0{s.num}</span>
                    {isPast ? (
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    ) : isCurrent ? (
                      <Loader2 className="w-3.5 h-3.5 text-indigo-600 animate-spin" />
                    ) : (
                      <StageIcon className="w-3.5 h-3.5 text-slate-400" />
                    )}
                  </div>
                  <p className="leading-snug line-clamp-2">{s.name}</p>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
