import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { api } from '../services/api';
import {
  History,
  FileText,
  Download,
  Trash2,
  ExternalLink,
  Search,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  GitCompare,
  Loader2,
  CheckSquare,
  Clock,
  ArrowUpDown,
  Filter
} from 'lucide-react';

export const ComparisonHistoryPage: React.FC = () => {
  const navigate = useNavigate();
  const [analyses, setAnalyses] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [sortBy, setSortBy] = useState<'date_desc' | 'date_asc' | 'score_desc' | 'score_asc'>('date_desc');
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const fetchHistory = async () => {
    try {
      setLoading(true);
      const res = await api.getAnalyses();
      setAnalyses(res);
    } catch (err: any) {
      console.error('Failed to load history', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchHistory();
  }, []);

  const handleDelete = async (id: string, title: string) => {
    if (!window.confirm(`Are you sure you want to delete audit '${title}'? This action cannot be undone.`)) {
      return;
    }
    try {
      setDeletingId(id);
      await api.deleteAnalysis(id);
      setAnalyses((prev) => prev.filter((a) => a.id !== id));
    } catch (err: any) {
      alert(`Deletion failed: ${err.message}`);
    } finally {
      setDeletingId(null);
    }
  };

  const filteredAnalyses = analyses
    .filter((a) => {
      const q = searchQuery.toLowerCase();
      const matchesQuery =
        a.title.toLowerCase().includes(q) ||
        (a.old_doc_name && a.old_doc_name.toLowerCase().includes(q)) ||
        (a.new_doc_name && a.new_doc_name.toLowerCase().includes(q)) ||
        a.id.toLowerCase().includes(q);

      const matchesStatus =
        statusFilter === 'All' ||
        (statusFilter === 'completed' && a.status === 'completed') ||
        (statusFilter === 'failed' && a.status === 'failed') ||
        (statusFilter === 'in_progress' && a.status !== 'completed' && a.status !== 'failed');

      return matchesQuery && matchesStatus;
    })
    .sort((a, b) => {
      if (sortBy === 'date_desc') return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
      if (sortBy === 'date_asc') return new Date(a.created_at).getTime() - new Date(b.created_at).getTime();
      if (sortBy === 'score_desc') return (b.consistency_score || 0) - (a.consistency_score || 0);
      if (sortBy === 'score_asc') return (a.consistency_score || 0) - (b.consistency_score || 0);
      return 0;
    });

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-2xl bg-gradient-to-r from-indigo-900 via-indigo-800 to-violet-950 text-white shadow-lg">
        <div>
          <div className="flex items-center gap-2 text-indigo-300 text-xs font-semibold uppercase tracking-wider mb-1">
            <History className="w-4 h-4 text-cyan-400" />
            <span>Audit Records & Archives</span>
          </div>
          <h1 className="text-2xl font-black text-white">Comparison & Audit History</h1>
          <p className="text-xs sm:text-sm text-indigo-200 mt-1 max-w-2xl">
            Retrieve past documentation audits, review human sign-off counts, inspect findings, and download executive PDF reports.
          </p>
        </div>

        <Link
          to="/new-analysis"
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-teal-400 hover:bg-teal-300 text-slate-950 text-xs font-bold shadow-md shadow-teal-500/20 transition-all self-start sm:self-auto"
        >
          <GitCompare className="w-4 h-4" />
          <span>New Comparison</span>
        </Link>
      </div>

      {/* Filter and Search Bar */}
      <div className="glass-card-light rounded-2xl p-4 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        {/* Search */}
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search audits by title, document name, or comparison ID..."
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>

        {/* Status Filter */}
        <div className="flex items-center gap-2">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 rounded-xl border border-slate-300 text-xs font-semibold text-slate-700 bg-white"
          >
            <option value="All">All Statuses</option>
            <option value="completed">Completed</option>
            <option value="in_progress">In Progress</option>
            <option value="failed">Failed</option>
          </select>

          {/* Sort By */}
          <select
            value={sortBy}
            onChange={(e: any) => setSortBy(e.target.value)}
            className="px-3 py-2 rounded-xl border border-slate-300 text-xs font-semibold text-slate-700 bg-white"
          >
            <option value="date_desc">Newest First</option>
            <option value="date_asc">Oldest First</option>
            <option value="score_desc">Highest Score</option>
            <option value="score_asc">Lowest Score</option>
          </select>
        </div>
      </div>

      {/* History Table */}
      {loading ? (
        <div className="min-h-[40vh] flex flex-col items-center justify-center gap-3">
          <Loader2 className="w-8 h-8 text-indigo-600 animate-spin" />
          <p className="text-xs text-slate-500 font-medium">Loading audit history...</p>
        </div>
      ) : filteredAnalyses.length === 0 ? (
        <div className="glass-card-light rounded-3xl p-12 text-center space-y-3">
          <History className="w-12 h-12 text-slate-300 mx-auto" />
          <p className="font-bold text-sm text-slate-700">No Historical Records Found</p>
          <p className="text-xs text-slate-400">Run an analysis to generate persistent documentation audits.</p>
        </div>
      ) : (
        <div className="glass-card-light rounded-2xl overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 font-semibold uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="py-3 px-4">Audit Title & ID</th>
                  <th className="py-3 px-4">Documents (Old vs New)</th>
                  <th className="py-3 px-4">Date & Time</th>
                  <th className="py-3 px-4">Consistency Score</th>
                  <th className="py-3 px-4">Review Status Breakdown</th>
                  <th className="py-3 px-4">Model Engine</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredAnalyses.map((a) => (
                  <tr key={a.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3.5 px-4">
                      <p className="font-bold text-slate-900">{a.title}</p>
                      <span className="text-[10px] font-mono text-slate-400">ID: {a.id.slice(0, 8)}</span>
                    </td>
                    <td className="py-3.5 px-4">
                      <div className="font-mono text-[11px] space-y-0.5">
                        <p className="text-slate-600 truncate max-w-[150px]">
                          <span className="text-slate-400 mr-1">Baseline:</span> {a.old_doc_name || 'Document A'}
                        </p>
                        <p className="text-indigo-700 font-semibold truncate max-w-[150px]">
                          <span className="text-indigo-400 mr-1">Updated:</span> {a.new_doc_name || 'Document B'}
                        </p>
                      </div>
                    </td>
                    <td className="py-3.5 px-4 text-slate-500">
                      {new Date(a.created_at).toLocaleString()}
                    </td>
                    <td className="py-3.5 px-4">
                      <div className="space-y-1">
                        <span className={`inline-flex items-center px-2 py-0.5 rounded-full font-black text-xs ${
                          a.consistency_score >= 85 ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' :
                          a.consistency_score >= 70 ? 'bg-amber-50 text-amber-700 border border-amber-200' :
                          'bg-rose-50 text-rose-700 border border-rose-200'
                        }`}>
                          {a.consistency_score}%
                        </span>
                        <p className="text-[10px] text-slate-400">{a.status_label}</p>
                      </div>
                    </td>
                    <td className="py-3.5 px-4">
                      <div className="flex flex-wrap items-center gap-1.5 text-[10px] font-semibold">
                        <span className="px-1.5 py-0.5 rounded bg-amber-50 text-amber-700 border border-amber-200" title="Pending">
                          {a.pending_count || 0} Pending
                        </span>
                        <span className="px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200" title="Approved">
                          {a.approved_count || 0} Approved
                        </span>
                        <span className="px-1.5 py-0.5 rounded bg-cyan-50 text-cyan-700 border border-cyan-200" title="Corrected">
                          {a.corrected_count || 0} Corrected
                        </span>
                        <span className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 border border-slate-200" title="Rejected">
                          {a.rejected_count || 0} Rejected
                        </span>
                      </div>
                    </td>
                    <td className="py-3.5 px-4 text-slate-500 text-[11px] truncate max-w-[140px]">
                      {a.model_used}
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => navigate(`/reviews?analysis_id=${a.id}`)}
                          className="px-2.5 py-1 rounded-lg bg-teal-50 hover:bg-teal-100 text-teal-800 font-semibold text-xs transition-colors flex items-center gap-1"
                          title="Open Human Review Workspace"
                        >
                          <CheckSquare className="w-3 h-3 text-teal-600" />
                          <span>Review</span>
                        </button>
                        <button
                          onClick={() => navigate(`/results/${a.id}`)}
                          className="px-2.5 py-1 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-semibold text-xs transition-colors flex items-center gap-1"
                          title="View Results Dashboard"
                        >
                          <ExternalLink className="w-3 h-3" />
                          <span>Results</span>
                        </button>
                        <button
                          onClick={() => api.downloadPdf(a.id, `Report_${a.id.slice(0, 8)}.pdf`)}
                          className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 transition-colors"
                          title="Download Executive PDF Report"
                        >
                          <Download className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDelete(a.id, a.title)}
                          disabled={deletingId === a.id}
                          className="p-1.5 rounded-lg bg-slate-100 hover:bg-red-50 text-slate-400 hover:text-red-600 transition-colors"
                          title="Delete audit"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
