import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { api } from '../services/api';
import {
  Settings,
  User,
  Lock,
  Sliders,
  CheckCircle2,
  AlertCircle,
  Save,
  Shield,
  Loader2
} from 'lucide-react';

export const SettingsPage: React.FC = () => {
  const { user } = useAuth();

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [notification, setNotification] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Settings
  const [similarityThreshold, setSimilarityThreshold] = useState<number>(0.55);
  const [confidenceThreshold, setConfidenceThreshold] = useState<number>(0.50);
  const [criticalWeight, setCriticalWeight] = useState<number>(25.0);
  const [highWeight, setHighWeight] = useState<number>(15.0);
  const [mediumWeight, setMediumWeight] = useState<number>(8.0);
  const [lowWeight, setLowWeight] = useState<number>(3.0);
  const [selectedModel, setSelectedModel] = useState<string>('llama3.1:8b');
  const [useAdapter, setUseAdapter] = useState<boolean>(false);
  const [inferenceMode, setInferenceMode] = useState<string>('ollama');

  // Password Change
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [pwdLoading, setPwdLoading] = useState(false);
  const [pwdMessage, setPwdMessage] = useState<string | null>(null);

  useEffect(() => {
    const fetchSettings = async () => {
      try {
        setLoading(true);
        const res = await api.getSettings();
        setSimilarityThreshold(res.similarity_threshold);
        setConfidenceThreshold(res.confidence_threshold);
        setCriticalWeight(res.critical_weight);
        setHighWeight(res.high_weight);
        setMediumWeight(res.medium_weight);
        setLowWeight(res.low_weight);
        setSelectedModel(res.selected_model);
        setUseAdapter(res.use_adapter);
        setInferenceMode(res.inference_mode);
      } catch (err: any) {
        console.warn('Using default settings', err);
      } finally {
        setLoading(false);
      }
    };
    fetchSettings();
  }, []);

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setError(null);
    setNotification(null);
    try {
      await api.updateSettings({
        similarity_threshold: similarityThreshold,
        confidence_threshold: confidenceThreshold,
        critical_weight: criticalWeight,
        high_weight: highWeight,
        medium_weight: mediumWeight,
        low_weight: lowWeight,
        selected_model: selectedModel,
        use_adapter: useAdapter,
        inference_mode: inferenceMode
      });
      setNotification('Application settings and threshold weights saved successfully!');
      setTimeout(() => setNotification(null), 4000);
    } catch (err: any) {
      setError(err.message || 'Failed to update settings.');
    } finally {
      setSaving(false);
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPwdMessage(null);
    if (newPassword !== confirmPassword) {
      alert('New password and confirm password do not match.');
      return;
    }
    setPwdLoading(true);
    try {
      await api.changePassword({ current_password: currentPassword, new_password: newPassword });
      setPwdMessage('Password updated successfully.');
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      setTimeout(() => setPwdMessage(null), 4000);
    } catch (err: any) {
      alert(`Password change failed: ${err.message}`);
    } finally {
      setPwdLoading(false);
    }
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Header */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-indigo-900 to-slate-900 text-white shadow-lg">
        <div className="flex items-center gap-2 text-indigo-300 text-xs font-semibold uppercase tracking-wider mb-1">
          <Settings className="w-4 h-4 text-cyan-400" />
          <span>System Preferences</span>
        </div>
        <h1 className="text-2xl font-black text-white">Application Configuration & Account</h1>
        <p className="text-xs sm:text-sm text-slate-300 mt-1">
          Tune semantic thresholds, calibrate severity penalty weights, and manage credentials.
        </p>
      </div>

      {notification && (
        <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold flex items-center gap-2 shadow-sm">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{notification}</span>
        </div>
      )}

      {error && (
        <div className="p-3.5 rounded-xl bg-red-50 border border-red-200 text-red-800 text-xs font-semibold flex items-center gap-2 shadow-sm">
          <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Main Settings Form */}
      <form onSubmit={handleSaveSettings} className="space-y-6">
        {/* Pipeline & Scoring Weights */}
        <div className="glass-card-light rounded-2xl p-6 space-y-5">
          <div className="border-b border-slate-100 pb-3">
            <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
              <Sliders className="w-4 h-4 text-indigo-600" />
              <span>Semantic Thresholds & Consistency Weights</span>
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Control the sensitivity of Sentence-BERT cosine alignment and scoring penalties.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 text-xs">
            {/* Similarity Threshold Slider */}
            <div className="space-y-2">
              <div className="flex justify-between font-semibold">
                <span className="text-slate-700">Similarity Cutoff (Cosine)</span>
                <span className="text-indigo-600 font-mono font-bold">{(similarityThreshold * 100).toFixed(0)}%</span>
              </div>
              <input
                type="range"
                min="0.30"
                max="0.85"
                step="0.05"
                value={similarityThreshold}
                onChange={(e) => setSimilarityThreshold(parseFloat(e.target.value))}
                className="w-full accent-indigo-600"
              />
              <p className="text-[11px] text-slate-400">Sections with similarity below this are treated as unmatched.</p>
            </div>

            {/* Confidence Threshold Slider */}
            <div className="space-y-2">
              <div className="flex justify-between font-semibold">
                <span className="text-slate-700">Confidence Flagging Threshold</span>
                <span className="text-indigo-600 font-mono font-bold">{(confidenceThreshold * 100).toFixed(0)}%</span>
              </div>
              <input
                type="range"
                min="0.40"
                max="0.90"
                step="0.05"
                value={confidenceThreshold}
                onChange={(e) => setConfidenceThreshold(parseFloat(e.target.value))}
                className="w-full accent-indigo-600"
              />
              <p className="text-[11px] text-slate-400">Issues with confidence below this threshold are flagged for human review.</p>
            </div>
          </div>

          {/* Severity Penalty Weights */}
          <div className="pt-2 border-t border-slate-100">
            <span className="text-xs font-bold text-slate-800 block mb-3">Severity Penalty Weights in Consistency Formula</span>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              <div>
                <label className="block text-slate-500 font-semibold mb-1">Critical Weight</label>
                <input
                  type="number"
                  value={criticalWeight}
                  onChange={(e) => setCriticalWeight(parseFloat(e.target.value) || 25.0)}
                  className="w-full px-3 py-1.5 rounded-xl border border-slate-300 text-slate-900 font-mono font-bold"
                />
              </div>
              <div>
                <label className="block text-slate-500 font-semibold mb-1">High Weight</label>
                <input
                  type="number"
                  value={highWeight}
                  onChange={(e) => setHighWeight(parseFloat(e.target.value) || 15.0)}
                  className="w-full px-3 py-1.5 rounded-xl border border-slate-300 text-slate-900 font-mono font-bold"
                />
              </div>
              <div>
                <label className="block text-slate-500 font-semibold mb-1">Medium Weight</label>
                <input
                  type="number"
                  value={mediumWeight}
                  onChange={(e) => setMediumWeight(parseFloat(e.target.value) || 8.0)}
                  className="w-full px-3 py-1.5 rounded-xl border border-slate-300 text-slate-900 font-mono font-bold"
                />
              </div>
              <div>
                <label className="block text-slate-500 font-semibold mb-1">Low Weight</label>
                <input
                  type="number"
                  value={lowWeight}
                  onChange={(e) => setLowWeight(parseFloat(e.target.value) || 3.0)}
                  className="w-full px-3 py-1.5 rounded-xl border border-slate-300 text-slate-900 font-mono font-bold"
                />
              </div>
            </div>
          </div>

          {/* Inference Engine Selection */}
          <div className="pt-2 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Primary LLM Model</label>
              <select
                value={selectedModel}
                onChange={(e) => setSelectedModel(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-slate-900 font-semibold"
              >
                <option value="llama3.1:8b">Llama 3.1 8B Instruct (Local Ollama)</option>
              </select>
            </div>
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Inference Engine Mode</label>
              <select
                value={inferenceMode}
                onChange={(e) => setInferenceMode(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-slate-900 font-semibold"
              >
                <option value="ollama">Local Ollama (llama3.1:8b) [Default]</option>
                <option value="local_nli_hybrid">Hybrid NLI + Semantic Engine (Local Offline)</option>
              </select>
            </div>
          </div>

          <div className="text-right pt-2">
            <button
              type="submit"
              disabled={saving}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md shadow-indigo-500/20 transition-all disabled:opacity-50"
            >
              {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
              <span>Save Configuration</span>
            </button>
          </div>
        </div>
      </form>

      {/* Account & Password Management */}
      <div className="glass-card-light rounded-2xl p-6 space-y-5">
        <div className="border-b border-slate-100 pb-3">
          <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
            <User className="w-4 h-4 text-violet-600" />
            <span>Developer Account & Security</span>
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Signed in as <span className="font-semibold text-slate-800">{user?.full_name}</span> ({user?.email})
          </p>
        </div>

        {pwdMessage && (
          <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{pwdMessage}</span>
          </div>
        )}

        <form onSubmit={handleChangePassword} className="space-y-4 max-w-md text-xs">
          <div>
            <label className="block text-slate-600 font-semibold mb-1">Current Password</label>
            <input
              type="password"
              required
              value={currentPassword}
              onChange={(e) => setCurrentPassword(e.target.value)}
              placeholder="••••••••••••"
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-slate-900"
            />
          </div>
          <div>
            <label className="block text-slate-600 font-semibold mb-1">New Password</label>
            <input
              type="password"
              required
              minLength={6}
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              placeholder="••••••••••••"
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-slate-900"
            />
          </div>
          <div>
            <label className="block text-slate-600 font-semibold mb-1">Confirm New Password</label>
            <input
              type="password"
              required
              minLength={6}
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              placeholder="••••••••••••"
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-slate-900"
            />
          </div>

          <button
            type="submit"
            disabled={pwdLoading}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs transition-colors disabled:opacity-50"
          >
            {pwdLoading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Lock className="w-3.5 h-3.5" />}
            <span>Update Password</span>
          </button>
        </form>
      </div>
    </div>
  );
};
