import React, { useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { api } from '../services/api';
import {
  CheckSquare,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  RotateCcw,
  Edit3,
  Save,
  X,
  Search,
  Filter,
  FileText,
  Clock,
  Sparkles,
  ArrowRight,
  ShieldAlert,
  Loader2,
  ExternalLink,
  MessageSquare,
  Check
} from 'lucide-react';

export const IssuesReviewsPage: React.FC = () => {
  const [searchParams] = useSearchParams();
  const initialAnalysisId = searchParams.get('analysis_id') || '';

  const [analyses, setAnalyses] = useState<any[]>([]);
  const [selectedAnalysisId, setSelectedAnalysisId] = useState<string>(initialAnalysisId);
  const [issues, setIssues] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<string>('All');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedSeverity, setSelectedSeverity] = useState<string>('All');

  // Editing correction state
  const [editingCorrectionId, setEditingCorrectionId] = useState<string | null>(null);
  const [correctionDraft, setCorrectionDraft] = useState('');
  const [savingCorrection, setSavingCorrection] = useState(false);

  // Reject modal state
  const [rejectingIssue, setRejectingIssue] = useState<any | null>(null);
  const [rejectionReason, setRejectionReason] = useState('');

  // Mark as corrected confirmation state
  const [correctingIssue, setCorrectingIssue] = useState<any | null>(null);

  // View details modal state
  const [detailIssue, setDetailIssue] = useState<any | null>(null);

  // Notification state
  const [toastMessage, setToastMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const showToast = (text: string, type: 'success' | 'error' = 'success') => {
    setToastMessage({ type, text });
    setTimeout(() => setToastMessage(null), 4000);
  };

  // Load analyses list for dropdown
  useEffect(() => {
    const fetchAnalyses = async () => {
      try {
        const list = await api.getAnalyses();
        setAnalyses(list);
      } catch (err: any) {
        console.error('Failed to load audits', err);
      }
    };
    fetchAnalyses();
  }, []);

  // Fetch issues
  const loadIssues = async () => {
    try {
      setLoading(true);
      const params: any = {};
      if (selectedAnalysisId) params.analysis_id = selectedAnalysisId;
      if (selectedCategory !== 'All') params.category = selectedCategory;
      if (selectedSeverity !== 'All') params.severity = selectedSeverity;
      if (selectedStatus !== 'All') params.verification_status = selectedStatus;

      const data = await api.getIssues(params);
      setIssues(data);
    } catch (err: any) {
      showToast(err.message || 'Failed to load issues.', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadIssues();
  }, [selectedAnalysisId, selectedCategory, selectedSeverity, selectedStatus]);

  // Actions
  const handleApprove = async (issue: any) => {
    try {
      const updated = await api.reviewIssue(issue.id, {
        verification_status: 'confirmed',
        reviewer_notes: issue.reviewer_notes ? `${issue.reviewer_notes}\n[Approved by reviewer]` : '[Approved by reviewer]'
      });
      setIssues((prev) => prev.map((i) => (i.id === issue.id ? updated : i)));
      showToast(`Finding ${issue.issue_code} approved successfully.`);
    } catch (err: any) {
      showToast(err.message || 'Failed to approve finding.', 'error');
    }
  };

  const handleConfirmReject = async () => {
    if (!rejectingIssue) return;
    try {
      const notes = rejectionReason.trim()
        ? `[Rejected]: ${rejectionReason}`
        : '[Rejected as false positive]';
      const updated = await api.reviewIssue(rejectingIssue.id, {
        verification_status: 'rejected',
        reviewer_notes: rejectingIssue.reviewer_notes ? `${rejectingIssue.reviewer_notes}\n${notes}` : notes
      });
      setIssues((prev) => prev.map((i) => (i.id === rejectingIssue.id ? updated : i)));
      showToast(`Finding ${rejectingIssue.issue_code} rejected.`);
      setRejectingIssue(null);
      setRejectionReason('');
    } catch (err: any) {
      showToast(err.message || 'Failed to reject finding.', 'error');
    }
  };

  const handleConfirmMarkCorrected = async () => {
    if (!correctingIssue) return;
    try {
      const updated = await api.reviewIssue(correctingIssue.id, {
        verification_status: 'corrected',
        reviewer_notes: correctingIssue.reviewer_notes
          ? `${correctingIssue.reviewer_notes}\n[Marked as addressed & corrected in documentation]`
          : '[Marked as addressed & corrected in documentation]'
      });
      setIssues((prev) => prev.map((i) => (i.id === correctingIssue.id ? updated : i)));
      showToast(`Finding ${correctingIssue.issue_code} marked as corrected.`);
      setCorrectingIssue(null);
    } catch (err: any) {
      showToast(err.message || 'Failed to update status.', 'error');
    }
  };

  const handleReopen = async (issue: any) => {
    try {
      const updated = await api.reviewIssue(issue.id, {
        verification_status: 'pending',
        reviewer_notes: issue.reviewer_notes ? `${issue.reviewer_notes}\n[Review reopened]` : '[Review reopened]'
      });
      setIssues((prev) => prev.map((i) => (i.id === issue.id ? updated : i)));
      showToast(`Finding ${issue.issue_code} reopened for human review.`);
    } catch (err: any) {
      showToast(err.message || 'Failed to reopen review.', 'error');
    }
  };

  const startEditCorrection = (issue: any) => {
    setEditingCorrectionId(issue.id);
    setCorrectionDraft(issue.suggested_correction || '');
  };

  const cancelEditCorrection = () => {
    setEditingCorrectionId(null);
    setCorrectionDraft('');
  };

  const saveCorrection = async (issueId: string) => {
    if (!correctionDraft.trim()) {
      showToast('Correction cannot be empty.', 'error');
      return;
    }
    try {
      setSavingCorrection(true);
      const updated = await api.updateCorrection(issueId, correctionDraft);
      setIssues((prev) => prev.map((i) => (i.id === issueId ? updated : i)));
      setEditingCorrectionId(null);
      showToast('Suggested correction updated and persisted.');
    } catch (err: any) {
      showToast(err.message || 'Failed to save correction.', 'error');
    } finally {
      setSavingCorrection(false);
    }
  };

  // Filter by search query
  const filteredIssues = issues.filter((iss) => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return (
      iss.issue_code.toLowerCase().includes(q) ||
      iss.title.toLowerCase().includes(q) ||
      iss.explanation.toLowerCase().includes(q) ||
      (iss.old_evidence && iss.old_evidence.toLowerCase().includes(q)) ||
      (iss.new_evidence && iss.new_evidence.toLowerCase().includes(q)) ||
      (iss.analysis_title && iss.analysis_title.toLowerCase().includes(q))
    );
  });

  // Calculate statistics across loaded issues
  const pendingCount = issues.filter((i) => i.verification_status === 'pending').length;
  const approvedCount = issues.filter((i) => i.verification_status === 'confirmed' || i.verification_status === 'approved').length;
  const rejectedCount = issues.filter((i) => i.verification_status === 'rejected').length;
  const correctedCount = issues.filter((i) => i.verification_status === 'corrected').length;

  const CATEGORY_COLORS: Record<string, string> = {
    'Consistent': '#10B981',
    'Contradiction': '#EF4444',
    'Outdated Information': '#F59E0B',
    'Missing Content': '#3B82F6',
    'Terminology Inconsistency': '#8B5CF6'
  };

  return (
    <div className="space-y-6">
      {/* Toast Notification */}
      {toastMessage && (
        <div className={`fixed top-20 right-6 z-50 p-4 rounded-xl shadow-xl border text-xs font-semibold flex items-center gap-2 max-w-md transition-all ${
          toastMessage.type === 'success'
            ? 'bg-emerald-50 text-emerald-900 border-emerald-200'
            : 'bg-rose-50 text-rose-900 border-rose-200'
        }`}>
          {toastMessage.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          ) : (
            <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
          )}
          <span>{toastMessage.text}</span>
        </div>
      )}

      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-6 rounded-2xl bg-gradient-to-r from-indigo-950 via-indigo-900 to-violet-950 text-white shadow-lg">
        <div>
          <div className="flex items-center gap-2 text-indigo-300 text-xs font-semibold uppercase tracking-wider mb-1">
            <CheckSquare className="w-4 h-4 text-cyan-400" />
            <span>Human-in-the-Loop Verification</span>
          </div>
          <h1 className="text-2xl font-black text-white">Issues & Human Review Workspace</h1>
          <p className="text-xs sm:text-sm text-indigo-200 mt-1 max-w-2xl">
            Individually inspect detected documentation discrepancies, modify recommended corrections, record formal approval decisions, or mark issues as corrected.
          </p>
        </div>

        <Link
          to="/new-analysis"
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-teal-400 hover:bg-teal-300 text-slate-950 text-xs font-bold shadow-md shadow-teal-500/20 transition-all self-start md:self-auto"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>New Comparison</span>
        </Link>
      </div>

      {/* Status Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div
          onClick={() => setSelectedStatus(selectedStatus === 'pending' ? 'All' : 'pending')}
          className={`cursor-pointer glass-card-light rounded-2xl p-4 border transition-all ${
            selectedStatus === 'pending' ? 'ring-2 ring-amber-500 border-amber-300' : 'hover:-translate-y-0.5'
          }`}
        >
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-semibold">Pending Review</span>
            <Clock className="w-4 h-4 text-amber-500" />
          </div>
          <p className="text-2xl font-black text-amber-600">{pendingCount}</p>
          <p className="text-[11px] text-slate-500">Awaiting human sign-off</p>
        </div>

        <div
          onClick={() => setSelectedStatus(selectedStatus === 'confirmed' ? 'All' : 'confirmed')}
          className={`cursor-pointer glass-card-light rounded-2xl p-4 border transition-all ${
            selectedStatus === 'confirmed' ? 'ring-2 ring-emerald-500 border-emerald-300' : 'hover:-translate-y-0.5'
          }`}
        >
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-semibold">Approved Findings</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-500" />
          </div>
          <p className="text-2xl font-black text-emerald-600">{approvedCount}</p>
          <p className="text-[11px] text-slate-500">Confirmed inconsistencies</p>
        </div>

        <div
          onClick={() => setSelectedStatus(selectedStatus === 'corrected' ? 'All' : 'corrected')}
          className={`cursor-pointer glass-card-light rounded-2xl p-4 border transition-all ${
            selectedStatus === 'corrected' ? 'ring-2 ring-cyan-500 border-cyan-300' : 'hover:-translate-y-0.5'
          }`}
        >
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-semibold">Corrected</span>
            <CheckSquare className="w-4 h-4 text-cyan-600" />
          </div>
          <p className="text-2xl font-black text-cyan-700">{correctedCount}</p>
          <p className="text-[11px] text-slate-500">Addressed in source doc</p>
        </div>

        <div
          onClick={() => setSelectedStatus(selectedStatus === 'rejected' ? 'All' : 'rejected')}
          className={`cursor-pointer glass-card-light rounded-2xl p-4 border transition-all ${
            selectedStatus === 'rejected' ? 'ring-2 ring-slate-500 border-slate-300' : 'hover:-translate-y-0.5'
          }`}
        >
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-semibold">Rejected</span>
            <XCircle className="w-4 h-4 text-slate-400" />
          </div>
          <p className="text-2xl font-black text-slate-600">{rejectedCount}</p>
          <p className="text-[11px] text-slate-500">Dismissed false positives</p>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="glass-card-light rounded-2xl p-4 space-y-3">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
          {/* Audit Selector */}
          <div>
            <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">
              Comparison Project
            </label>
            <select
              value={selectedAnalysisId}
              onChange={(e) => setSelectedAnalysisId(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-semibold text-slate-800 bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="">All Comparisons</option>
              {analyses.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.title} ({a.consistency_score}%)
                </option>
              ))}
            </select>
          </div>

          {/* Status Filter */}
          <div>
            <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">
              Review Status
            </label>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-semibold text-slate-800 bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="All">All Statuses</option>
              <option value="pending">Pending Review</option>
              <option value="confirmed">Approved / Confirmed</option>
              <option value="corrected">Corrected</option>
              <option value="rejected">Rejected (False Positive)</option>
            </select>
          </div>

          {/* Category Filter */}
          <div>
            <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">
              Category
            </label>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-semibold text-slate-800 bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="All">All Categories</option>
              <option value="Contradiction">Contradiction</option>
              <option value="Outdated Information">Outdated Information</option>
              <option value="Missing Content">Missing Content</option>
              <option value="Terminology Inconsistency">Terminology Inconsistency</option>
              <option value="Consistent">Consistent</option>
            </select>
          </div>

          {/* Severity Filter */}
          <div>
            <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">
              Severity
            </label>
            <select
              value={selectedSeverity}
              onChange={(e) => setSelectedSeverity(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-semibold text-slate-800 bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="All">All Severities</option>
              <option value="Critical">Critical</option>
              <option value="High">High</option>
              <option value="Medium">Medium</option>
              <option value="Low">Low</option>
              <option value="Informational">Informational</option>
            </select>
          </div>

          {/* Search Box */}
          <div>
            <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">
              Search Findings
            </label>
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Code, keyword, or evidence..."
                className="w-full pl-8 pr-3 py-2 rounded-xl border border-slate-300 text-xs text-slate-800 bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Issues Review List */}
      {loading ? (
        <div className="min-h-[40vh] flex flex-col items-center justify-center gap-3">
          <Loader2 className="w-8 h-8 text-indigo-600 animate-spin" />
          <p className="text-xs text-slate-500 font-medium">Loading issues for review...</p>
        </div>
      ) : filteredIssues.length === 0 ? (
        <div className="glass-card-light rounded-3xl p-12 text-center space-y-3">
          <CheckSquare className="w-12 h-12 text-slate-300 mx-auto" />
          <p className="font-bold text-sm text-slate-700">No Issues Match Current Filter</p>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Try adjusting your search query, status, or category filter to view other audit findings.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          <div className="flex items-center justify-between text-xs text-slate-500 font-semibold px-1">
            <span>Showing {filteredIssues.length} finding{filteredIssues.length === 1 ? '' : 's'}</span>
          </div>

          {filteredIssues.map((issue) => {
            const catColor = CATEGORY_COLORS[issue.category] || '#6366F1';
            const isEditing = editingCorrectionId === issue.id;

            return (
              <div
                key={issue.id}
                className="glass-card-light rounded-2xl p-5 border border-slate-200/80 shadow-sm space-y-4 hover:border-slate-300 transition-all"
              >
                {/* Issue Header */}
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-mono text-xs font-black text-slate-800 bg-slate-100 px-2 py-0.5 rounded-lg border border-slate-200">
                        {issue.issue_code}
                      </span>
                      <span
                        className="text-[10px] font-bold uppercase px-2.5 py-0.5 rounded-full"
                        style={{
                          backgroundColor: `${catColor}15`,
                          color: catColor,
                          border: `1px solid ${catColor}35`
                        }}
                      >
                        {issue.category}
                      </span>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                        issue.severity === 'Critical' ? 'bg-rose-100 text-rose-700' :
                        issue.severity === 'High' ? 'bg-orange-100 text-orange-700' :
                        issue.severity === 'Medium' ? 'bg-amber-100 text-amber-700' :
                        'bg-emerald-100 text-emerald-700'
                      }`}>
                        {issue.severity}
                      </span>
                      <span className="text-[11px] text-slate-400 font-mono">
                        Confidence: {Math.round(issue.confidence * 100)}%
                      </span>
                    </div>

                    <h3 className="text-sm font-bold text-slate-900 pt-1">{issue.title}</h3>
                    {issue.analysis_title && (
                      <p className="text-[11px] text-slate-400">
                        Audit: <span className="font-semibold text-slate-600">{issue.analysis_title}</span>
                      </p>
                    )}
                  </div>

                  {/* Status Badge */}
                  <div>
                    <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold capitalize ${
                      issue.verification_status === 'confirmed' || issue.verification_status === 'approved'
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                        : issue.verification_status === 'corrected'
                        ? 'bg-cyan-50 text-cyan-700 border border-cyan-200'
                        : issue.verification_status === 'rejected'
                        ? 'bg-slate-100 text-slate-600 border border-slate-300'
                        : 'bg-amber-50 text-amber-700 border border-amber-200'
                    }`}>
                      {issue.verification_status === 'confirmed' ? <CheckCircle2 className="w-3.5 h-3.5" /> :
                       issue.verification_status === 'corrected' ? <CheckSquare className="w-3.5 h-3.5" /> :
                       issue.verification_status === 'rejected' ? <XCircle className="w-3.5 h-3.5" /> :
                       <Clock className="w-3.5 h-3.5" />}
                      <span>{issue.verification_status === 'confirmed' ? 'Approved' : issue.verification_status}</span>
                    </span>
                  </div>
                </div>

                {/* Explanation */}
                <p className="text-xs text-slate-600 leading-relaxed bg-slate-50/70 p-3 rounded-xl border border-slate-100">
                  <span className="font-semibold text-slate-700">Audit Explanation: </span>
                  {issue.explanation}
                </p>

                {/* Side-by-Side Evidence Boxes */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                  <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                    <div className="flex items-center justify-between text-[10px] font-bold uppercase text-slate-500 mb-1">
                      <span>Baseline Text (Old Version)</span>
                      {issue.source_section_old && <span className="text-indigo-600 font-mono">§ {issue.source_section_old}</span>}
                    </div>
                    <p className="font-mono text-[11px] text-slate-800 whitespace-pre-wrap">
                      {issue.old_evidence || '[No excerpt recorded]'}
                    </p>
                  </div>

                  <div className="p-3 rounded-xl bg-indigo-50/40 border border-indigo-200/70">
                    <div className="flex items-center justify-between text-[10px] font-bold uppercase text-indigo-700 mb-1">
                      <span>Target Text (New Version)</span>
                      {issue.source_section_new && <span className="text-indigo-600 font-mono">§ {issue.source_section_new}</span>}
                    </div>
                    <p className="font-mono text-[11px] text-slate-800 whitespace-pre-wrap">
                      {issue.new_evidence || '[No matching target section]'}
                    </p>
                  </div>
                </div>

                {/* Suggested Correction Box (Editable) */}
                <div className="p-3.5 rounded-xl bg-violet-50/50 border border-violet-200/70 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-violet-900">
                      Suggested Correction & Remediation
                    </span>
                    {!isEditing && (
                      <button
                        type="button"
                        onClick={() => startEditCorrection(issue)}
                        className="inline-flex items-center gap-1 text-[11px] font-semibold text-indigo-600 hover:text-indigo-800"
                      >
                        <Edit3 className="w-3 h-3" />
                        <span>Edit Suggested Correction</span>
                      </button>
                    )}
                  </div>

                  {isEditing ? (
                    <div className="space-y-2 pt-1">
                      <textarea
                        value={correctionDraft}
                        onChange={(e) => setCorrectionDraft(e.target.value)}
                        rows={3}
                        className="w-full p-2.5 text-xs bg-white border border-indigo-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 font-sans"
                        placeholder="Modify the recommended correction text..."
                      />
                      <div className="flex items-center justify-end gap-2">
                        <button
                          type="button"
                          onClick={cancelEditCorrection}
                          disabled={savingCorrection}
                          className="px-3 py-1.5 text-xs font-semibold text-slate-600 hover:bg-slate-200/60 rounded-lg transition-colors"
                        >
                          Cancel
                        </button>
                        <button
                          type="button"
                          onClick={() => saveCorrection(issue.id)}
                          disabled={savingCorrection}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-sm transition-colors"
                        >
                          {savingCorrection ? <Loader2 className="w-3 h-3 animate-spin" /> : <Save className="w-3 h-3" />}
                          <span>Save Correction</span>
                        </button>
                      </div>
                    </div>
                  ) : (
                    <p className="text-xs text-indigo-950 italic leading-relaxed">
                      "{issue.suggested_correction || 'No specific correction proposed.'}"
                    </p>
                  )}
                </div>

                {/* Reviewer Notes & Audit History if present */}
                {issue.reviewer_notes && (
                  <div className="p-2.5 rounded-lg bg-slate-100 text-[11px] text-slate-700 font-mono whitespace-pre-wrap">
                    <span className="font-bold text-slate-800">Review History:</span>
                    <div>{issue.reviewer_notes}</div>
                  </div>
                )}

                {/* Human Review Action Bar */}
                <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2">
                  <button
                    type="button"
                    onClick={() => setDetailIssue(issue)}
                    className="text-xs font-semibold text-slate-600 hover:text-slate-900 inline-flex items-center gap-1"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>View Full Details</span>
                  </button>

                  <div className="flex flex-wrap items-center gap-2">
                    {/* Approve Finding */}
                    <button
                      type="button"
                      onClick={() => handleApprove(issue)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 text-xs font-bold transition-all hover:scale-[1.02]"
                      title="Approve finding as a confirmed documentation inconsistency"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Approve Finding</span>
                    </button>

                    {/* Reject Finding (False Positive) */}
                    <button
                      type="button"
                      onClick={() => {
                        setRejectingIssue(issue);
                        setRejectionReason('');
                      }}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-200 text-xs font-bold transition-all hover:scale-[1.02]"
                      title="Reject finding as false positive with reason"
                    >
                      <XCircle className="w-3.5 h-3.5 text-rose-600" />
                      <span>Reject Finding</span>
                    </button>

                    {/* Mark as Corrected */}
                    <button
                      type="button"
                      onClick={() => setCorrectingIssue(issue)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-50 hover:bg-cyan-100 text-cyan-800 border border-cyan-200 text-xs font-bold transition-all hover:scale-[1.02]"
                      title="Mark as corrected once documentation has been modified"
                    >
                      <CheckSquare className="w-3.5 h-3.5 text-cyan-600" />
                      <span>Mark as Corrected</span>
                    </button>

                    {/* Reopen Review (if already reviewed) */}
                    {issue.verification_status !== 'pending' && (
                      <button
                        type="button"
                        onClick={() => handleReopen(issue)}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-all"
                        title="Reopen review state back to pending"
                      >
                        <RotateCcw className="w-3.5 h-3.5 text-slate-500" />
                        <span>Reopen Review</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Reject Finding Modal with Reason */}
      {rejectingIssue && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white rounded-2xl p-6 max-w-md w-full shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2 text-rose-600">
                <XCircle className="w-5 h-5" />
                <h3 className="font-bold text-sm text-slate-900">Reject Finding ({rejectingIssue.issue_code})</h3>
              </div>
              <button
                type="button"
                onClick={() => setRejectingIssue(null)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-slate-600">
              Please enter the justification for rejecting this finding as a false positive or intentional discrepancy:
            </p>

            <textarea
              value={rejectionReason}
              onChange={(e) => setRejectionReason(e.target.value)}
              placeholder="e.g., Difference is intentional due to v2.0 architectural deprecation policy."
              rows={3}
              className="w-full p-3 text-xs bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-rose-500"
            />

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setRejectingIssue(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmReject}
                className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 shadow-md shadow-rose-600/20"
              >
                Confirm Rejection
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Mark as Corrected Confirmation Modal */}
      {correctingIssue && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white rounded-2xl p-6 max-w-md w-full shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2 text-cyan-700">
                <CheckSquare className="w-5 h-5" />
                <h3 className="font-bold text-sm text-slate-900">Confirm Documentation Correction</h3>
              </div>
              <button
                type="button"
                onClick={() => setCorrectingIssue(null)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              Are you sure you want to mark <b>{correctingIssue.issue_code}: {correctingIssue.title}</b> as corrected?
            </p>
            <p className="text-[11px] text-slate-500 italic bg-slate-50 p-3 rounded-xl border border-slate-100">
              Note: This action records your human verification that the documentation contradiction or discrepancy has been rectified in the source documentation.
            </p>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setCorrectingIssue(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmMarkCorrected}
                className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-cyan-600 hover:bg-cyan-700 shadow-md shadow-cyan-600/20"
              >
                Mark as Corrected
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Full Details Modal */}
      {detailIssue && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white rounded-3xl p-6 max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <span className="font-mono text-xs font-bold text-indigo-600">{detailIssue.issue_code}</span>
                <h2 className="text-base font-bold text-slate-900 mt-0.5">{detailIssue.title}</h2>
              </div>
              <button
                type="button"
                onClick={() => setDetailIssue(null)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              <div className="p-2.5 rounded-xl bg-slate-50">
                <span className="text-[10px] text-slate-400 uppercase font-bold block">Category</span>
                <span className="font-semibold text-slate-800">{detailIssue.category}</span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-50">
                <span className="text-[10px] text-slate-400 uppercase font-bold block">Severity</span>
                <span className="font-semibold text-slate-800">{detailIssue.severity}</span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-50">
                <span className="text-[10px] text-slate-400 uppercase font-bold block">Confidence</span>
                <span className="font-semibold text-slate-800">{Math.round(detailIssue.confidence * 100)}%</span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-50">
                <span className="text-[10px] text-slate-400 uppercase font-bold block">Status</span>
                <span className="font-semibold capitalize text-indigo-600">{detailIssue.verification_status}</span>
              </div>
            </div>

            <div className="space-y-1 text-xs">
              <span className="font-bold text-slate-800 block">Detailed Explanation</span>
              <p className="text-slate-600 leading-relaxed bg-slate-50 p-3 rounded-xl border border-slate-200">
                {detailIssue.explanation}
              </p>
            </div>

            <div className="space-y-2 text-xs">
              <span className="font-bold text-slate-800 block">Baseline Evidence</span>
              <pre className="p-3 bg-slate-900 text-slate-100 rounded-xl font-mono text-[11px] whitespace-pre-wrap overflow-x-auto">
                {detailIssue.old_evidence || 'N/A'}
              </pre>
            </div>

            <div className="space-y-2 text-xs">
              <span className="font-bold text-slate-800 block">Target Evidence</span>
              <pre className="p-3 bg-slate-900 text-slate-100 rounded-xl font-mono text-[11px] whitespace-pre-wrap overflow-x-auto">
                {detailIssue.new_evidence || 'N/A'}
              </pre>
            </div>

            <div className="space-y-1 text-xs">
              <span className="font-bold text-indigo-900 block">Suggested Correction</span>
              <p className="text-indigo-950 italic bg-indigo-50 p-3 rounded-xl border border-indigo-200">
                "{detailIssue.suggested_correction || 'None'}"
              </p>
            </div>

            <div className="flex justify-end pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setDetailIssue(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
