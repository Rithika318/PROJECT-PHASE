import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import {
  Cpu,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  RefreshCw,
  Terminal,
  Copy,
  Check,
  Server,
  Database,
  Brain,
  Sliders,
  ExternalLink,
  Loader2
} from 'lucide-react';

export const ModelStatusPage: React.FC = () => {
  const [status, setStatus] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [copiedCmd, setCopiedCmd] = useState<string | null>(null);

  const fetchModelHealth = async () => {
    try {
      setLoading(true);
      const res = await api.getModelStatus();
      setStatus(res);
    } catch (err: any) {
      console.error('Failed to load model status', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchModelHealth();
  }, []);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCmd(text);
    setTimeout(() => setCopiedCmd(null), 2000);
  };

  const getStatusBadge = (componentStatus: string) => {
    switch (componentStatus) {
      case 'Ready':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            Ready
          </span>
        );
      case 'Not Installed':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-rose-50 text-rose-700 border border-rose-200">
            <XCircle className="w-3.5 h-3.5 text-rose-600" />
            Not Installed
          </span>
        );
      case 'Active (Local Analytical Engine)':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-indigo-50 text-indigo-700 border border-indigo-200">
            <CheckCircle2 className="w-3.5 h-3.5 text-indigo-600" />
            Active (Rule-Verified)
          </span>
        );
      case 'Not Configured':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-slate-100 text-slate-600 border border-slate-200">
            Optional / Unset
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-amber-50 text-amber-700 border border-amber-200">
            <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
            {componentStatus || 'Unavailable'}
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-2xl bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white shadow-lg">
        <div>
          <div className="flex items-center gap-2 text-indigo-300 text-xs font-semibold uppercase tracking-wider mb-1">
            <Cpu className="w-4 h-4 text-cyan-400" />
            <span>Infrastructure Health</span>
          </div>
          <h1 className="text-2xl font-black text-white">AI Engine & Service Diagnostics</h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-1">
            Real-time verification of local Ollama runtime, model weights, SBERT embeddings, and database services.
          </p>
        </div>

        <button
          onClick={fetchModelHealth}
          disabled={loading}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 border border-white/20 text-white text-xs font-semibold transition-all self-start sm:self-auto disabled:opacity-50"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>Refresh Health Checks</span>
        </button>
      </div>

      {/* Active Operational Mode Card */}
      <div className="glass-card-light rounded-2xl p-5 border-l-4 border-indigo-600 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Active Analysis Engine</span>
          <h3 className="text-base font-extrabold text-slate-900">{status?.current_inference_mode || 'Checking...'}</h3>
          <p className="text-xs text-slate-500 mt-0.5">
            {status?.last_analysis_time ? `Last successful audit: ${new Date(status.last_analysis_time).toLocaleString()}` : 'No previous analysis timestamp recorded.'}
          </p>
        </div>
      </div>

      {/* Components Grid */}
      {loading ? (
        <div className="min-h-[40vh] flex flex-col items-center justify-center gap-3">
          <Loader2 className="w-8 h-8 text-indigo-600 animate-spin" />
          <p className="text-xs text-slate-500 font-medium">Querying local model endpoints...</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* 1. Ollama Daemon */}
          <div className="glass-card-light rounded-2xl p-5 space-y-3">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center shrink-0">
                  <Server className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-sm text-slate-900">{status?.ollama_service?.name}</h4>
                  <p className="text-[11px] text-slate-500">Local LLM Server (Port 11434)</p>
                </div>
              </div>
              {getStatusBadge(status?.ollama_service?.status)}
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">{status?.ollama_service?.details}</p>
            {status?.ollama_service?.command_to_run && (
              <div className="p-3 rounded-xl bg-slate-900 text-slate-200 font-mono text-xs flex items-center justify-between">
                <span>$ {status.ollama_service.command_to_run}</span>
                <button
                  onClick={() => copyToClipboard(status.ollama_service.command_to_run)}
                  className="text-slate-400 hover:text-white"
                  title="Copy command"
                >
                  {copiedCmd === status.ollama_service.command_to_run ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>
            )}
          </div>

          {/* 2. Llama 3.1 8B Instruct Model */}
          <div className="glass-card-light rounded-2xl p-5 space-y-3">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-violet-50 text-violet-600 flex items-center justify-center shrink-0">
                  <Cpu className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-sm text-slate-900">{status?.llama31_model?.name}</h4>
                  <p className="text-[11px] text-slate-500">Primary Reasoning & Verification LLM</p>
                </div>
              </div>
              {getStatusBadge(status?.llama31_model?.status)}
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">{status?.llama31_model?.details}</p>
            {status?.llama31_model?.command_to_run && (
              <div className="space-y-1">
                <span className="text-[10px] font-bold text-slate-500 block uppercase">Download Model Command:</span>
                <div className="p-3 rounded-xl bg-slate-900 text-slate-200 font-mono text-xs flex items-center justify-between">
                  <span>$ {status.llama31_model.command_to_run}</span>
                  <button
                    onClick={() => copyToClipboard(status.llama31_model.command_to_run)}
                    className="text-slate-400 hover:text-white"
                    title="Copy command"
                  >
                    {copiedCmd === status.llama31_model.command_to_run ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* 3. Sentence-BERT Embeddings */}
          <div className="glass-card-light rounded-2xl p-5 space-y-3">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-cyan-50 text-cyan-600 flex items-center justify-center shrink-0">
                  <Brain className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-sm text-slate-900">{status?.sbert_embeddings?.name}</h4>
                  <p className="text-[11px] text-slate-500">Semantic Cosine Alignment</p>
                </div>
              </div>
              {getStatusBadge(status?.sbert_embeddings?.status)}
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">{status?.sbert_embeddings?.details}</p>
          </div>

          {/* 4. DeBERTa-v3 NLI */}
          <div className="glass-card-light rounded-2xl p-5 space-y-3">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center shrink-0">
                  <Sliders className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-sm text-slate-900">{status?.deberta_nli?.name}</h4>
                  <p className="text-[11px] text-slate-500">Entailment & Contradiction Scoring</p>
                </div>
              </div>
              {getStatusBadge(status?.deberta_nli?.status)}
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">{status?.deberta_nli?.details}</p>
          </div>

          {/* 5. SQLite Database (WAL Mode) */}
          <div className="glass-card-light rounded-2xl p-5 space-y-3">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
                  <Database className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-sm text-slate-900">{status?.database?.name}</h4>
                  <p className="text-[11px] text-slate-500">Persistent Local Relational Storage</p>
                </div>
              </div>
              {getStatusBadge(status?.database?.status)}
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">{status?.database?.details}</p>
          </div>

          {/* 6. Fine-Tuned LoRA Adapter */}
          <div className="glass-card-light rounded-2xl p-5 space-y-3">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center shrink-0">
                  <Cpu className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-sm text-slate-900">{status?.finetuned_adapter?.name}</h4>
                  <p className="text-[11px] text-slate-500">Domain-Adapted Consistency Adapter</p>
                </div>
              </div>
              {getStatusBadge(status?.finetuned_adapter?.status)}
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">{status?.finetuned_adapter?.details}</p>
          </div>
        </div>
      )}
    </div>
  );
};
