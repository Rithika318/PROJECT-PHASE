import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { api } from '../services/api';
import {
  FileText,
  AlertTriangle,
  CheckCircle2,
  Download,
  Filter,
  Search,
  Copy,
  Check,
  MessageSquare,
  ShieldAlert,
  ArrowRight,
  Sparkles,
  GitCompare,
  Clock,
  Layers,
  FileCheck2,
  X,
  ExternalLink,
  Loader2
} from 'lucide-react';
import {
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend
} from 'recharts';

export const ResultsPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();

  const [analysesList, setAnalysesList] = useState<any[]>([]);
  const [selectedAnalysisId, setSelectedAnalysisId] = useState<string | null>(id || null);
  const [analysis, setAnalysis] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Filters & Search
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedSeverity, setSelectedSeverity] = useState<string>('All');
  const [reviewFilter, setReviewFilter] = useState<string>('All');

  // Selected Issue for Side-by-Side Modal / Evidence View
  const [activeIssue, setActiveIssue] = useState<any>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [commentText, setCommentText] = useState('');
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);

  // Load analyses list if no id, or load specific analysis
  useEffect(() => {
    const fetchAnalyses = async () => {
      try {
        setLoading(true);
        const list = await api.getAnalyses();
        setAnalysesList(list);

        const targetId = id || (list.length > 0 ? list[0].id : null);
        setSelectedAnalysisId(targetId);

        if (targetId) {
          const detail = await api.getAnalysis(targetId);
          setAnalysis(detail);
          if (detail.issues && detail.issues.length > 0) {
            setActiveIssue(detail.issues[0]);
          }
        }
      } catch (err: any) {
        setError(err.message || 'Failed to load analysis results.');
      } finally {
        setLoading(false);
      }
    };
    fetchAnalyses();
  }, [id]);

  const switchAnalysis = async (targetId: string) => {
    setSelectedAnalysisId(targetId);
    try {
      setLoading(true);
      const detail = await api.getAnalysis(targetId);
      setAnalysis(detail);
      if (detail.issues && detail.issues.length > 0) {
        setActiveIssue(detail.issues[0]);
      } else {
        setActiveIssue(null);
      }
    } catch (err: any) {
      setError(err.message || 'Failed to switch analysis.');
    } finally {
      setLoading(false);
    }
  };

  const handleReviewAction = async (status: 'confirmed' | 'rejected' | 'reviewed') => {
    if (!activeIssue) return;
    try {
      const updated = await api.reviewIssue(activeIssue.id, { verification_status: status });
      setActiveIssue(updated);
      // Update in local state
      setAnalysis((prev: any) => ({
        ...prev,
        issues: prev.issues.map((iss: any) => (iss.id === updated.id ? updated : iss)),
      }));
      setActionSuccess(`Issue marked as ${status}.`);
      setTimeout(() => setActionSuccess(null), 3000);
    } catch (err: any) {
      alert(`Action failed: ${err.message}`);
    }
  };

  const handleAddComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeIssue || !commentText.trim()) return;
    try {
      const updated = await api.addComment(activeIssue.id, commentText);
      setActiveIssue(updated);
      setCommentText('');
      setAnalysis((prev: any) => ({
        ...prev,
        issues: prev.issues.map((iss: any) => (iss.id === updated.id ? updated : iss)),
      }));
    } catch (err: any) {
      alert(`Comment failed: ${err.message}`);
    }
  };

  const copyToClipboard = (text: string, idStr: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(idStr);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const CATEGORY_COLORS: Record<string, string> = {
    'Consistent': '#10B981',
    'Contradiction': '#EF4444',
    'Outdated Information': '#F59E0B',
    'Missing Content': '#3B82F6',
    'Terminology Inconsistency': '#8B5CF6'
  };

  const SEVERITY_COLORS: Record<string, string> = {
    'Critical': '#EF4444',
    'High': '#F97316',
    'Medium': '#F59E0B',
    'Low': '#10B981',
    'Informational': '#6366F1'
  };

  if (loading) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center gap-3">
        <Loader2 className="w-8 h-8 text-indigo-600 animate-spin" />
        <p className="text-sm text-slate-500 font-medium">Loading comprehensive consistency audit report...</p>
      </div>
    );
  }

  if (!analysis) {
    return (
      <div className="glass-card-light rounded-3xl p-10 text-center space-y-4">
        <FileCheck2 className="w-16 h-16 text-indigo-400 mx-auto" />
        <h2 className="text-xl font-bold text-slate-900">No Analysis Results Available</h2>
        <p className="text-xs sm:text-sm text-slate-500 max-w-md mx-auto">
          You haven't run any document comparisons yet. Upload an old and new version to view results.
        </p>
        <Link
          to="/new-analysis"
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-600 text-white font-semibold text-xs shadow-md shadow-indigo-500/20"
        >
          Start New Analysis
        </Link>
      </div>
    );
  }

  // Filter issues
  const filteredIssues = (analysis.issues || []).filter((iss: any) => {
    const matchesSearch =
      searchQuery === '' ||
      iss.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      iss.explanation.toLowerCase().includes(searchQuery.toLowerCase()) ||
      iss.issue_code.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesCategory = selectedCategory === 'All' || iss.category === selectedCategory;
    const matchesSeverity = selectedSeverity === 'All' || iss.severity === selectedSeverity;
    const matchesReview =
      reviewFilter === 'All' ||
      (reviewFilter === 'needs_review' && iss.verification_status === 'pending') ||
      iss.verification_status === reviewFilter;

    return matchesSearch && matchesCategory && matchesSeverity && matchesReview;
  });

  const score = analysis.consistency_score || 0;
  const scoreColor = score >= 85 ? '#10B981' : score >= 70 ? '#F59E0B' : '#EF4444';

  return (
    <div className="space-y-6">
      {/* Top Bar: Selector & Export Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 glass-card-light rounded-2xl p-4">
        <div className="flex items-center gap-3">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Select Audit:</span>
          <select
            value={selectedAnalysisId || ''}
            onChange={(e) => switchAnalysis(e.target.value)}
            className="px-3 py-1.5 rounded-xl border border-slate-300 text-xs font-semibold text-slate-800 bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            {analysesList.map((a) => (
              <option key={a.id} value={a.id}>
                {a.title} ({new Date(a.created_at).toLocaleDateString()}) - {a.consistency_score}%
              </option>
            ))}
          </select>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => api.downloadPdf(analysis.id, `Consistency_Report_${analysis.id.slice(0, 8)}.pdf`)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold text-xs border border-indigo-200 transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            Download PDF Report
          </button>
          <button
            onClick={() => api.downloadCsv(analysis.id, `Issues_${analysis.id.slice(0, 8)}.csv`)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs border border-slate-300 transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            Export CSV
          </button>
        </div>
      </div>

      {/* Audit Executive Header & Score Card */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Metadata & Executive Overview */}
        <div className="lg:col-span-2 glass-card-light rounded-2xl p-6 space-y-4">
          <div className="flex items-start justify-between">
            <div>
              <span className="text-xs font-bold text-indigo-600 uppercase tracking-wider">Audit Overview</span>
              <h1 className="text-xl sm:text-2xl font-black text-slate-900 mt-0.5">{analysis.title}</h1>
              {analysis.description && <p className="text-xs text-slate-500 mt-1">{analysis.description}</p>}
            </div>
            <span className="text-[11px] font-mono px-2.5 py-1 rounded-full bg-slate-100 text-slate-600">
              ID: {analysis.id.slice(0, 8)}
            </span>
          </div>

          {/* Document Comparison Reference */}
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Baseline (Old Version)</span>
              <span className="font-semibold text-slate-800 truncate block">{analysis.old_doc_name || 'Document A'}</span>
            </div>
            <div>
              <span className="text-indigo-500 block text-[10px] uppercase font-bold">Target (New Version)</span>
              <span className="font-semibold text-indigo-900 truncate block">{analysis.new_doc_name || 'Document B'}</span>
            </div>
          </div>

          {/* Quick Metrics Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-1">
            <div className="p-3 rounded-xl bg-indigo-50/60 border border-indigo-100 text-center">
              <span className="text-[10px] font-semibold text-slate-500 block uppercase">Matched Pairs</span>
              <span className="text-lg font-black text-indigo-900">{analysis.matched_pairs_count || 0}</span>
            </div>
            <div className="p-3 rounded-xl bg-rose-50/60 border border-rose-100 text-center">
              <span className="text-[10px] font-semibold text-slate-500 block uppercase">Inconsistencies</span>
              <span className="text-lg font-black text-rose-600">{analysis.confirmed_issues_count || 0}</span>
            </div>
            <div className="p-3 rounded-xl bg-amber-50/60 border border-amber-100 text-center">
              <span className="text-[10px] font-semibold text-slate-500 block uppercase">Needs Review</span>
              <span className="text-lg font-black text-amber-600">{analysis.review_required_count || 0}</span>
            </div>
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-center">
              <span className="text-[10px] font-semibold text-slate-500 block uppercase">Duration</span>
              <span className="text-lg font-black text-slate-800">{analysis.duration_seconds || 0}s</span>
            </div>
          </div>
        </div>

        {/* Right: Circular Score Gauge Card */}
        <div className="glass-card-light rounded-2xl p-6 flex flex-col items-center justify-center text-center space-y-3">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Consistency Rating</span>
          
          {/* Circular SVG Gauge */}
          <div className="relative w-36 h-36 flex items-center justify-center">
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
              <circle
                cx="50"
                cy="50"
                r="40"
                stroke="#E2E8F0"
                strokeWidth="8"
                fill="transparent"
              />
              <circle
                cx="50"
                cy="50"
                r="40"
                stroke={scoreColor}
                strokeWidth="8"
                strokeDasharray={251.2}
                strokeDashoffset={251.2 - (251.2 * score) / 100}
                strokeLinecap="round"
                fill="transparent"
                className="transition-all duration-1000 ease-out"
              />
            </svg>
            <div className="absolute flex flex-col items-center justify-center">
              <span className="text-3xl font-black text-slate-900">{score}%</span>
              <span className="text-[10px] text-slate-400 uppercase font-semibold">Normalized</span>
            </div>
          </div>

          <div>
            <span
              className="inline-block px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider"
              style={{
                backgroundColor: `${scoreColor}15`,
                color: scoreColor,
                border: `1px solid ${scoreColor}40`
              }}
            >
              {analysis.status_label || 'Evaluated'}
            </span>
            <p className="text-[11px] text-slate-500 mt-2 max-w-xs leading-relaxed">
              Formula: 100 - (Weighted Discrepancy Penalty / Baseline Capacity)
            </p>
          </div>
        </div>
      </div>

      {/* Search and Filters Bar */}
      <div className="glass-card-light rounded-2xl p-4 space-y-3">
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
          {/* Search Input */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search findings by keyword, code, or explanation..."
              className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {/* Filter Pills */}
          <div className="flex flex-wrap items-center gap-2">
            {/* Category Filter */}
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="px-2.5 py-1.5 rounded-xl border border-slate-300 text-xs font-semibold text-slate-700 bg-white"
            >
              <option value="All">All Categories</option>
              <option value="Consistent">Consistent</option>
              <option value="Contradiction">Contradiction</option>
              <option value="Outdated Information">Outdated Information</option>
              <option value="Missing Content">Missing Content</option>
              <option value="Terminology Inconsistency">Terminology Inconsistency</option>
            </select>

            {/* Severity Filter */}
            <select
              value={selectedSeverity}
              onChange={(e) => setSelectedSeverity(e.target.value)}
              className="px-2.5 py-1.5 rounded-xl border border-slate-300 text-xs font-semibold text-slate-700 bg-white"
            >
              <option value="All">All Severities</option>
              <option value="Critical">Critical</option>
              <option value="High">High</option>
              <option value="Medium">Medium</option>
              <option value="Low">Low</option>
              <option value="Informational">Informational</option>
            </select>

            {/* Review Status Filter */}
            <select
              value={reviewFilter}
              onChange={(e) => setReviewFilter(e.target.value)}
              className="px-2.5 py-1.5 rounded-xl border border-slate-300 text-xs font-semibold text-slate-700 bg-white"
            >
              <option value="All">All Statuses</option>
              <option value="needs_review">Needs Review</option>
              <option value="confirmed">Confirmed</option>
              <option value="rejected">Rejected</option>
              <option value="reviewed">Reviewed</option>
            </select>
          </div>
        </div>
      </div>

      {/* Main Split: Left Table vs Right Side-by-Side Evidence Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Issues Table (7 Cols) */}
        <div className="lg:col-span-7 glass-card-light rounded-2xl p-4 overflow-hidden space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <span className="font-bold text-xs text-slate-800">
              Audit Findings ({filteredIssues.length} of {analysis.issues?.length || 0})
            </span>
          </div>

          <div className="overflow-x-auto max-h-[600px] overflow-y-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 font-semibold uppercase tracking-wider text-[10px] sticky top-0 z-10">
                <tr>
                  <th className="py-2.5 px-3">Code</th>
                  <th className="py-2.5 px-3">Category</th>
                  <th className="py-2.5 px-3">Finding Title</th>
                  <th className="py-2.5 px-3">Severity</th>
                  <th className="py-2.5 px-3">Confidence</th>
                  <th className="py-2.5 px-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredIssues.map((issue: any) => {
                  const isSelected = activeIssue?.id === issue.id;
                  const catColor = CATEGORY_COLORS[issue.category] || '#6366F1';
                  return (
                    <tr
                      key={issue.id}
                      onClick={() => setActiveIssue(issue)}
                      className={`cursor-pointer transition-colors ${
                        isSelected ? 'bg-indigo-50/80 font-medium' : 'hover:bg-slate-50'
                      }`}
                    >
                      <td className="py-2.5 px-3 font-mono text-[11px] font-bold text-slate-700">
                        {issue.issue_code}
                      </td>
                      <td className="py-2.5 px-3">
                        <span
                          className="inline-block px-2 py-0.5 rounded-full text-[10px] font-bold uppercase whitespace-nowrap"
                          style={{
                            backgroundColor: `${catColor}15`,
                            color: catColor,
                            border: `1px solid ${catColor}30`
                          }}
                        >
                          {issue.category}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-slate-900 font-medium max-w-[180px] truncate">
                        {issue.title}
                      </td>
                      <td className="py-2.5 px-3">
                        <span className={`inline-block px-1.5 py-0.5 rounded text-[10px] font-bold ${
                          issue.severity === 'Critical' ? 'bg-rose-100 text-rose-700' :
                          issue.severity === 'High' ? 'bg-orange-100 text-orange-700' :
                          issue.severity === 'Medium' ? 'bg-amber-100 text-amber-700' :
                          'bg-emerald-100 text-emerald-700'
                        }`}>
                          {issue.severity}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-slate-600 font-mono text-[11px]">
                        {Math.round(issue.confidence * 100)}%
                      </td>
                      <td className="py-2.5 px-3">
                        <span className={`inline-block px-1.5 py-0.5 rounded text-[10px] font-semibold capitalize ${
                          issue.verification_status === 'confirmed' ? 'bg-emerald-100 text-emerald-800' :
                          issue.verification_status === 'rejected' ? 'bg-slate-200 text-slate-700' :
                          'bg-indigo-100 text-indigo-800'
                        }`}>
                          {issue.verification_status}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Side-by-Side Evidence & Review Workspace (5 Cols) */}
        <div className="lg:col-span-5 glass-card-light rounded-2xl p-5 space-y-4 flex flex-col justify-between">
          {activeIssue ? (
            <div className="space-y-4">
              {/* Header & Verification Actions */}
              <div className="border-b border-slate-100 pb-3">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs font-bold text-slate-500">{activeIssue.issue_code}</span>
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => handleReviewAction('confirmed')}
                      className="px-2 py-1 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-bold text-[11px] border border-emerald-200"
                    >
                      Confirm Issue
                    </button>
                    <button
                      onClick={() => handleReviewAction('rejected')}
                      className="px-2 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-[11px] border border-slate-300"
                    >
                      False Positive
                    </button>
                    <button
                      onClick={() => handleReviewAction('reviewed')}
                      className="px-2 py-1 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold text-[11px] border border-indigo-200"
                    >
                      Mark Reviewed
                    </button>
                  </div>
                </div>
                <h3 className="text-sm font-bold text-slate-900 mt-2">{activeIssue.title}</h3>
                <p className="text-xs text-slate-600 mt-1 leading-relaxed">{activeIssue.explanation}</p>
              </div>

              {actionSuccess && (
                <div className="p-2 rounded-lg bg-emerald-50 text-emerald-800 text-xs font-semibold flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>{actionSuccess}</span>
                </div>
              )}

              {/* Side-by-Side Evidence Boxes */}
              <div className="space-y-3">
                {/* Old Document Evidence */}
                <div>
                  <div className="flex items-center justify-between text-[11px] font-semibold text-slate-500 mb-1">
                    <span>Baseline (Old Version Evidence)</span>
                    {activeIssue.source_section_old && (
                      <span className="font-mono text-slate-400">§ {activeIssue.source_section_old}</span>
                    )}
                  </div>
                  <div className={`p-3 rounded-xl text-xs font-mono text-slate-800 highlight-${
                    activeIssue.category.toLowerCase().includes('contradiction') ? 'contradiction' :
                    activeIssue.category.toLowerCase().includes('outdated') ? 'outdated' :
                    activeIssue.category.toLowerCase().includes('terminology') ? 'terminology' :
                    activeIssue.category.toLowerCase().includes('missing') ? 'missing' : 'consistent'
                  }`}>
                    {activeIssue.old_evidence || 'No verbatim excerpt recorded.'}
                  </div>
                </div>

                {/* New Document Evidence */}
                <div>
                  <div className="flex items-center justify-between text-[11px] font-semibold text-slate-500 mb-1">
                    <span>Target (New Version Evidence)</span>
                    {activeIssue.source_section_new && (
                      <span className="font-mono text-indigo-500">§ {activeIssue.source_section_new}</span>
                    )}
                  </div>
                  <div className={`p-3 rounded-xl text-xs font-mono text-slate-800 highlight-${
                    activeIssue.category.toLowerCase().includes('contradiction') ? 'contradiction' :
                    activeIssue.category.toLowerCase().includes('outdated') ? 'outdated' :
                    activeIssue.category.toLowerCase().includes('terminology') ? 'terminology' :
                    activeIssue.category.toLowerCase().includes('missing') ? 'missing' : 'consistent'
                  }`}>
                    {activeIssue.new_evidence || 'No matching section in target document.'}
                  </div>
                </div>
              </div>

              {/* Recommended Correction */}
              {activeIssue.suggested_correction && (
                <div className="p-3.5 rounded-xl bg-indigo-50/70 border border-indigo-200/80 space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-bold text-indigo-900 uppercase">Recommended Correction</span>
                    <button
                      onClick={() => copyToClipboard(activeIssue.suggested_correction, activeIssue.id)}
                      className="text-[11px] text-indigo-600 hover:text-indigo-800 font-semibold flex items-center gap-1"
                    >
                      {copiedId === activeIssue.id ? <><Check className="w-3 h-3 text-emerald-600" /> Copied</> : <><Copy className="w-3 h-3" /> Copy</>}
                    </button>
                  </div>
                  <p className="text-xs text-indigo-950 italic leading-relaxed">
                    "{activeIssue.suggested_correction}"
                  </p>
                </div>
              )}

              {/* Reviewer Comments Feed */}
              <div className="space-y-2 pt-2 border-t border-slate-100">
                <span className="text-[11px] font-bold text-slate-700 block">Reviewer Notes & Feedback</span>
                {activeIssue.reviewer_notes ? (
                  <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 text-xs text-slate-700 whitespace-pre-wrap font-sans">
                    {activeIssue.reviewer_notes}
                  </div>
                ) : (
                  <p className="text-[11px] text-slate-400">No reviewer notes attached yet.</p>
                )}

                <form onSubmit={handleAddComment} className="flex gap-2 pt-1">
                  <input
                    type="text"
                    value={commentText}
                    onChange={(e) => setCommentText(e.target.value)}
                    placeholder="Add audit note or rationale..."
                    className="flex-1 px-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                  <button
                    type="submit"
                    className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs"
                  >
                    Post
                  </button>
                </form>
              </div>
            </div>
          ) : (
            <div className="py-20 text-center text-slate-400 text-xs">
              Select an issue from the findings table to inspect side-by-side evidence.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
