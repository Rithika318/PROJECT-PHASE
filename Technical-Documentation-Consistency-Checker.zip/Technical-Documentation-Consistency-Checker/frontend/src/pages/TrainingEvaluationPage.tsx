import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import {
  BrainCircuit,
  Upload,
  Download,
  Play,
  CheckCircle2,
  AlertCircle,
  FileText,
  Sliders,
  BarChart2,
  Table,
  Cpu,
  Layers,
  Sparkles,
  Loader2,
  HelpCircle
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Cell
} from 'recharts';

export const TrainingEvaluationPage: React.FC = () => {
  const [datasets, setDatasets] = useState<any[]>([]);
  const [selectedDatasetId, setSelectedDatasetId] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [uploadingDataset, setUploadingDataset] = useState(false);

  // Training Form States
  const [epochs, setEpochs] = useState<number>(3);
  const [learningRate, setLearningRate] = useState<number>(0.0002);
  const [batchSize, setBatchSize] = useState<number>(4);
  const [loraR, setLoraR] = useState<number>(16);
  const [loraAlpha, setLoraAlpha] = useState<number>(32);
  const [loraDropout, setLoraDropout] = useState<number>(0.05);

  // Active Training Job
  const [trainingJob, setTrainingJob] = useState<any>(null);
  const [isTraining, setIsTraining] = useState<boolean>(false);

  // Evaluation States
  const [evalModelName, setEvalModelName] = useState<string>('llama3.1:8b');
  const [useAdapter, setUseAdapter] = useState<boolean>(true);
  const [isEvaluating, setIsEvaluating] = useState<boolean>(false);
  const [latestEvaluation, setLatestEvaluation] = useState<any>(null);
  const [pastEvaluations, setPastEvaluations] = useState<any[]>([]);

  // Messages
  const [notification, setNotification] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const [dsList, evalsList] = await Promise.all([
          api.getDatasets(),
          api.getEvaluations()
        ]);
        setDatasets(dsList);
        if (dsList.length > 0) {
          setSelectedDatasetId(dsList[0].id);
        }
        setPastEvaluations(evalsList);
        if (evalsList.length > 0) {
          setLatestEvaluation(evalsList[0]);
        }
      } catch (err: any) {
        console.error('Failed to load training artifacts', err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  // Poll training progress
  useEffect(() => {
    let timer: any;
    if (isTraining && trainingJob) {
      timer = setInterval(async () => {
        try {
          const res = await api.getTrainingJob(trainingJob.id);
          setTrainingJob(res);
          if (res.status === 'completed' || res.status === 'failed') {
            setIsTraining(false);
            clearInterval(timer);
            setNotification(res.status === 'completed' ? 'LoRA Fine-Tuning Job finished successfully! Adapter checkpoint saved.' : 'Training failed.');
          }
        } catch (err) {
          console.warn('Poll error', err);
        }
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [isTraining, trainingJob]);

  const handleUploadDataset = async (file: File) => {
    try {
      setUploadingDataset(true);
      const res = await api.uploadDataset(file);
      setDatasets((prev) => [res, ...prev]);
      setSelectedDatasetId(res.id);
      setNotification(`Dataset '${file.name}' verified and uploaded! (${res.row_count} rows, 0 duplicates)`);
    } catch (err: any) {
      alert(`Upload failed: ${err.message}`);
    } finally {
      setUploadingDataset(false);
    }
  };

  const handleStartTraining = async () => {
    if (!selectedDatasetId) {
      alert('Please upload or select a consistency text-pair dataset first.');
      return;
    }

    setIsTraining(true);
    setNotification(null);
    try {
      const res = await api.createTrainingJob({
        dataset_id: selectedDatasetId,
        base_model: 'llama3.1:8b',
        epochs,
        learning_rate: learningRate,
        batch_size: batchSize,
        lora_r: loraR,
        lora_alpha: loraAlpha,
        lora_dropout: loraDropout
      });
      setTrainingJob(res);
    } catch (err: any) {
      setIsTraining(false);
      alert(`Could not start training job: ${err.message}`);
    }
  };

  const handleRunEvaluation = async () => {
    if (!selectedDatasetId) {
      alert('Please select a dataset to run test set evaluation.');
      return;
    }
    setIsEvaluating(true);
    try {
      const res = await api.runEvaluation({
        dataset_id: selectedDatasetId,
        model_name: evalModelName,
        use_adapter: useAdapter
      });
      setLatestEvaluation(res);
      setPastEvaluations((prev) => [res, ...prev]);
      setNotification(`Evaluation on held-out test set complete! Accuracy: ${(res.accuracy * 100).toFixed(1)}%, Macro-F1: ${(res.macro_f1 * 100).toFixed(1)}%`);
    } catch (err: any) {
      alert(`Evaluation failed: ${err.message}`);
    } finally {
      setIsEvaluating(false);
    }
  };

  const selectedDataset = datasets.find((d) => d.id === selectedDatasetId);

  // Label distribution data for chart
  const distData = selectedDataset?.label_distribution_json
    ? Object.entries(selectedDataset.label_distribution_json).map(([k, v]) => ({ name: k, count: v }))
    : [];

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-2xl bg-gradient-to-r from-violet-900 via-indigo-900 to-slate-900 text-white shadow-lg">
        <div>
          <div className="flex items-center gap-2 text-violet-300 text-xs font-semibold uppercase tracking-wider mb-1">
            <BrainCircuit className="w-4 h-4 text-cyan-400" />
            <span>PEFT & Adapter Engineering</span>
          </div>
          <h1 className="text-2xl font-black text-white">Model Training & Benchmark Evaluation</h1>
          <p className="text-xs sm:text-sm text-indigo-200 mt-1 max-w-2xl leading-relaxed">
            Configure LoRA parameter-efficient fine-tuning on domain documentation text pairs and benchmark performance on held-out test sets.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <a
            href={api.getSampleDatasetUrl()}
            download
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 border border-white/20 text-white text-xs font-semibold transition-all"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Sample Dataset</span>
          </a>
          <a
            href={api.getTemplateDatasetUrl()}
            download
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold transition-all shadow-md shadow-cyan-500/20"
          >
            <Download className="w-3.5 h-3.5" />
            <span>CSV Template</span>
          </a>
        </div>
      </div>

      {notification && (
        <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{notification}</span>
          </div>
          <button onClick={() => setNotification(null)} className="text-emerald-500 hover:text-emerald-700">✕</button>
        </div>
      )}

      {/* Grid: Left Dataset & LoRA Config | Right Live Loss & Metrics */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column (5 Cols): Dataset Upload & LoRA Hyperparameters */}
        <div className="lg:col-span-5 space-y-6">
          {/* Dataset Upload Panel */}
          <div className="glass-card-light rounded-2xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
                <FileText className="w-4 h-4 text-indigo-600" />
                <span>Consistency Training Dataset</span>
              </h3>
              <span className="text-[10px] font-mono font-bold text-slate-400">CSV / JSONL</span>
            </div>

            {datasets.length > 0 ? (
              <div className="space-y-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">Active Dataset</label>
                  <select
                    value={selectedDatasetId}
                    onChange={(e) => setSelectedDatasetId(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-semibold text-slate-800 bg-white"
                  >
                    {datasets.map((d) => (
                      <option key={d.id} value={d.id}>
                        {d.filename} ({d.row_count} pairs)
                      </option>
                    ))}
                  </select>
                </div>

                {selectedDataset && (
                  <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs space-y-1 font-mono">
                    <div className="flex justify-between">
                      <span className="text-slate-500">Total Valid Pairs:</span>
                      <span className="font-bold text-slate-900">{selectedDataset.row_count}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Train / Val / Test:</span>
                      <span className="text-indigo-600 font-bold">
                        {selectedDataset.train_count} / {selectedDataset.val_count} / {selectedDataset.test_count}
                      </span>
                    </div>
                  </div>
                )}
              </div>
            ) : null}

            {/* Upload Area */}
            <label className="flex flex-col items-center justify-center p-5 rounded-xl border-2 border-dashed border-slate-200 hover:border-indigo-400 bg-slate-50/50 hover:bg-slate-50 cursor-pointer transition-colors text-center group">
              <Upload className="w-7 h-7 text-indigo-500 group-hover:scale-110 transition-transform mb-2" />
              <span className="text-xs font-semibold text-slate-700">Upload Labeled Consistency Pairs</span>
              <span className="text-[10px] text-slate-400 mt-0.5">Columns: old_text, new_text, category, label</span>
              <input
                type="file"
                accept=".csv,.jsonl"
                className="hidden"
                disabled={uploadingDataset}
                onChange={(e) => e.target.files?.[0] && handleUploadDataset(e.target.files[0])}
              />
            </label>

            {/* Label Distribution Chart */}
            {distData.length > 0 && (
              <div className="pt-2">
                <span className="text-[11px] font-bold text-slate-600 block mb-2">Class Distribution</span>
                <div className="h-40">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={distData} margin={{ top: 5, right: 5, left: -25, bottom: 25 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
                      <XAxis dataKey="name" angle={-25} textAnchor="end" tick={{ fontSize: 9 }} />
                      <YAxis tick={{ fontSize: 9 }} />
                      <Tooltip contentStyle={{ backgroundColor: '#1E293B', color: '#FFF', borderRadius: '8px', fontSize: '11px' }} />
                      <Bar dataKey="count" fill="#4F46E5" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            )}
          </div>

          {/* LoRA / QLoRA Configuration Panel */}
          <div className="glass-card-light rounded-2xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
                <Sliders className="w-4 h-4 text-violet-600" />
                <span>LoRA Hyperparameters</span>
              </h3>
              <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">PEFT / QLoRA</span>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div>
                <label className="block text-slate-500 font-semibold mb-1">Epochs</label>
                <input
                  type="number"
                  min="1"
                  max="10"
                  value={epochs}
                  onChange={(e) => setEpochs(parseInt(e.target.value) || 3)}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 text-slate-900 font-semibold"
                />
              </div>
              <div>
                <label className="block text-slate-500 font-semibold mb-1">Batch Size</label>
                <input
                  type="number"
                  min="1"
                  max="16"
                  value={batchSize}
                  onChange={(e) => setBatchSize(parseInt(e.target.value) || 4)}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 text-slate-900 font-semibold"
                />
              </div>
              <div>
                <label className="block text-slate-500 font-semibold mb-1">Learning Rate</label>
                <input
                  type="number"
                  step="0.00005"
                  value={learningRate}
                  onChange={(e) => setLearningRate(parseFloat(e.target.value) || 0.0002)}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 text-slate-900 font-semibold"
                />
              </div>
              <div>
                <label className="block text-slate-500 font-semibold mb-1">LoRA Rank (r)</label>
                <input
                  type="number"
                  min="4"
                  max="64"
                  value={loraR}
                  onChange={(e) => setLoraR(parseInt(e.target.value) || 16)}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 text-slate-900 font-semibold"
                />
              </div>
              <div>
                <label className="block text-slate-500 font-semibold mb-1">LoRA Alpha</label>
                <input
                  type="number"
                  min="8"
                  max="128"
                  value={loraAlpha}
                  onChange={(e) => setLoraAlpha(parseInt(e.target.value) || 32)}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 text-slate-900 font-semibold"
                />
              </div>
              <div>
                <label className="block text-slate-500 font-semibold mb-1">LoRA Dropout</label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  max="0.5"
                  value={loraDropout}
                  onChange={(e) => setLoraDropout(parseFloat(e.target.value) || 0.05)}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 text-slate-900 font-semibold"
                />
              </div>
            </div>

            <div className="pt-2">
              <button
                type="button"
                onClick={handleStartTraining}
                disabled={isTraining || !selectedDatasetId}
                className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white font-bold text-xs shadow-md shadow-violet-500/20 flex items-center justify-center gap-2 transition-all disabled:opacity-50"
              >
                {isTraining ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Executing LoRA Adaptation...</span>
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4" />
                    <span>Start LoRA Fine-Tuning Job</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Right Column (7 Cols): Training Curves & Test Evaluation Metrics */}
        <div className="lg:col-span-7 space-y-6">
          {/* Live Training Progress & Loss Curve */}
          <div className="glass-card-light rounded-2xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <div>
                <h3 className="font-bold text-sm text-slate-900">Training Loss & Convergence</h3>
                <p className="text-xs text-slate-500">Real-time loss tracking across fine-tuning epochs</p>
              </div>
              {trainingJob && (
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full capitalize ${
                  trainingJob.status === 'completed' ? 'bg-emerald-100 text-emerald-800' :
                  trainingJob.status === 'running' ? 'bg-indigo-100 text-indigo-800 animate-pulse' :
                  'bg-slate-100 text-slate-600'
                }`}>
                  Status: {trainingJob.status} ({trainingJob.progress_percent}%)
                </span>
              )}
            </div>

            {/* Progress Bar */}
            {isTraining && (
              <div className="w-full h-2 rounded-full bg-slate-100 overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-violet-600 to-indigo-600 rounded-full transition-all duration-300"
                  style={{ width: `${trainingJob?.progress_percent || 0}%` }}
                />
              </div>
            )}

            {/* Loss Curve Chart */}
            <div className="h-56">
              {trainingJob?.training_loss_history_json?.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={trainingJob.training_loss_history_json} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
                    <XAxis dataKey="epoch" tick={{ fontSize: 11 }} />
                    <YAxis tick={{ fontSize: 11 }} />
                    <Tooltip contentStyle={{ backgroundColor: '#1E293B', color: '#FFF', borderRadius: '8px', fontSize: '11px' }} />
                    <Line type="monotone" dataKey="train_loss" stroke="#7C3AED" strokeWidth={2} name="Train Loss" />
                    <Line type="monotone" dataKey="val_loss" stroke="#06B6D4" strokeWidth={2} name="Val Loss" />
                  </LineChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-slate-400 text-xs">
                  <BrainCircuit className="w-8 h-8 mb-2 text-slate-300" />
                  <span>Loss curve will render when a training run is initiated.</span>
                </div>
              )}
            </div>
          </div>

          {/* Held-Out Test Set Evaluation Panel */}
          <div className="glass-card-light rounded-2xl p-5 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
              <div>
                <h3 className="font-bold text-sm text-slate-900">Held-Out Test Set Evaluation</h3>
                <p className="text-xs text-slate-500">Rigorous metrics: Accuracy, Precision, Recall, Macro-F1, and Confusion Matrix</p>
              </div>

              {/* Trigger Button */}
              <div className="flex items-center gap-2">
                <label className="flex items-center gap-1.5 text-xs text-slate-600 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={useAdapter}
                    onChange={(e) => setUseAdapter(e.target.checked)}
                    className="rounded text-indigo-600 focus:ring-indigo-500"
                  />
                  <span>Use LoRA Adapter</span>
                </label>
                <button
                  type="button"
                  onClick={handleRunEvaluation}
                  disabled={isEvaluating || !selectedDatasetId}
                  className="px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-sm flex items-center gap-1.5 disabled:opacity-50"
                >
                  {isEvaluating ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5" />}
                  <span>Evaluate Model</span>
                </button>
              </div>
            </div>

            {latestEvaluation ? (
              <div className="space-y-4">
                {/* 4 Core Metrics */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
                  <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200">
                    <span className="text-[10px] font-bold text-slate-500 block uppercase">Accuracy</span>
                    <span className="text-xl font-black text-emerald-700">
                      {(latestEvaluation.accuracy * 100).toFixed(1)}%
                    </span>
                  </div>
                  <div className="p-3 rounded-xl bg-indigo-50 border border-indigo-200">
                    <span className="text-[10px] font-bold text-slate-500 block uppercase">Precision</span>
                    <span className="text-xl font-black text-indigo-700">
                      {(latestEvaluation.precision * 100).toFixed(1)}%
                    </span>
                  </div>
                  <div className="p-3 rounded-xl bg-cyan-50 border border-cyan-200">
                    <span className="text-[10px] font-bold text-slate-500 block uppercase">Recall</span>
                    <span className="text-xl font-black text-cyan-700">
                      {(latestEvaluation.recall * 100).toFixed(1)}%
                    </span>
                  </div>
                  <div className="p-3 rounded-xl bg-violet-50 border border-violet-200">
                    <span className="text-[10px] font-bold text-slate-500 block uppercase">Macro-F1</span>
                    <span className="text-xl font-black text-violet-700">
                      {(latestEvaluation.macro_f1 * 100).toFixed(1)}%
                    </span>
                  </div>
                </div>

                {/* Confusion Matrix Visualization */}
                {latestEvaluation.confusion_matrix_json?.matrix && (
                  <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                    <span className="text-xs font-bold text-slate-800 block">Confusion Matrix (Predicted vs Actual)</span>
                    <div className="overflow-x-auto">
                      <table className="w-full text-center text-xs">
                        <thead>
                          <tr className="text-[10px] text-slate-400 font-mono">
                            <th className="text-left py-1">Actual \ Pred</th>
                            {latestEvaluation.confusion_matrix_json.labels.map((l: string) => (
                              <th key={l} className="py-1 px-1.5 truncate max-w-[80px]" title={l}>
                                {l.slice(0, 5)}..
                              </th>
                            ))}
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-200 font-mono">
                          {latestEvaluation.confusion_matrix_json.matrix.map((row: number[], rowIdx: number) => {
                            const label = latestEvaluation.confusion_matrix_json.labels[rowIdx];
                            return (
                              <tr key={label}>
                                <td className="py-1.5 px-2 text-left font-bold text-slate-700 truncate max-w-[100px]" title={label}>
                                  {label.slice(0, 10)}..
                                </td>
                                {row.map((val: number, colIdx: number) => {
                                  const isDiag = rowIdx === colIdx;
                                  return (
                                    <td
                                      key={colIdx}
                                      className={`py-1.5 px-2 font-bold ${
                                        isDiag
                                          ? 'bg-emerald-100 text-emerald-800'
                                          : val > 0
                                          ? 'bg-rose-50 text-rose-700'
                                          : 'text-slate-400'
                                      }`}
                                    >
                                      {val}
                                    </td>
                                  );
                                })}
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="py-8 text-center text-slate-400 text-xs">
                Select a dataset and click "Evaluate Model" to benchmark performance.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
