import React, { createContext, useContext, useState } from 'react';
import { Issue, DocumentFile, ValidationRule, ASTDefinition, PipelineStage } from '../types';
import { SAMPLE_ISSUES } from '../data/sampleIssues';
import { SAMPLE_OLD_DOCUMENT, SAMPLE_NEW_DOCUMENT } from '../data/sampleDocuments';
import { DEFAULT_VALIDATION_RULES } from '../data/validationRules';
import { SAMPLE_AST_DEFINITIONS } from '../data/sampleAst';

export type NavTab = 
  | 'dashboard'
  | 'documents'
  | 'compare'
  | 'ai-analysis'
  | 'issues'
  | 'source-code'
  | 'knowledge-graph'
  | 'analytics'
  | 'history'
  | 'reports'
  | 'settings';

export const PIPELINE_STAGES: PipelineStage[] = [
  { id: 1, title: 'Document Upload & Ingestion', description: 'Ingesting Multi-Format sources (PDF, MD, HTML, TXT)', status: 'completed', extractedDetail: '2 documents loaded (320 KB)' },
  { id: 2, title: 'Document Parsing & Text Extraction', description: 'AST structural tokenization and markdown parsing', status: 'completed', extractedDetail: '7 sections, 14 code blocks identified' },
  { id: 3, title: 'Section, Code & Parameter Extraction', description: 'Isolating endpoint signatures, types, and schemas', status: 'completed', extractedDetail: '18 endpoints, 64 parameters mapped' },
  { id: 4, title: 'Custom Transformer NLP Model', description: 'Self-attention inference over technical vocab', status: 'completed', extractedDetail: '4-layer Transformer (128-d, zero external APIs)' },
  { id: 5, title: 'Technical Information & Entity Extraction', description: 'Resolving entity relations: API -> Param -> Type -> Version', status: 'completed', extractedDetail: '48 entity nodes, 92 relation edges' },
  { id: 6, title: 'Consistency Verification Engine', description: 'Bilateral diff checking + Source AST rule verification', status: 'completed', extractedDetail: 'Cross-validated with 6 validation rules' },
  { id: 7, title: 'Issue Detection & Severity Engine', description: 'Classifying inconsistencies, outdated info & missing items', status: 'completed', extractedDetail: '37 issues flagged (8 High, 17 Med, 12 Low)' },
  { id: 8, title: 'Scoring & Report Compilation', description: 'Computing 78% Consistency Index and audit breakdown', status: 'completed', extractedDetail: 'Report ready for download' },
];

interface AnalysisContextType {
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
  oldDoc: DocumentFile;
  newDoc: DocumentFile;
  setOldDoc: (doc: DocumentFile) => void;
  setNewDoc: (doc: DocumentFile) => void;
  issues: Issue[];
  selectedIssue: Issue | null;
  setSelectedIssue: (issue: Issue | null) => void;
  rules: ValidationRule[];
  toggleRule: (id: string) => void;
  astDefinitions: ASTDefinition[];
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  selectedSeverity: string;
  setSelectedSeverity: (sev: string) => void;
  selectedCategory: string;
  setSelectedCategory: (cat: string) => void;
  selectedSection: string;
  setSelectedSection: (sec: string) => void;
  toggleResolveIssue: (id: string) => void;
  isHowItWorksOpen: boolean;
  setIsHowItWorksOpen: (open: boolean) => void;
  isPipelineModalOpen: boolean;
  setIsPipelineModalOpen: (open: boolean) => void;
  isDownloadModalOpen: boolean;
  setIsDownloadModalOpen: (open: boolean) => void;
  isAnalyzing: boolean;
  pipelineProgress: number;
  currentPipelineStage: number;
  runAnalysisSimulation: () => void;
  loadSampleDocs: () => void;
}

const AnalysisContext = createContext<AnalysisContextType | undefined>(undefined);

export const AnalysisProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activeTab, setActiveTab] = useState<NavTab>('dashboard');
  const [oldDoc, setOldDoc] = useState<DocumentFile>(SAMPLE_OLD_DOCUMENT);
  const [newDoc, setNewDoc] = useState<DocumentFile>(SAMPLE_NEW_DOCUMENT);
  const [issues, setIssues] = useState<Issue[]>(SAMPLE_ISSUES);
  const [selectedIssue, setSelectedIssue] = useState<Issue | null>(null);
  const [rules, setRules] = useState<ValidationRule[]>(DEFAULT_VALIDATION_RULES);
  const [astDefinitions] = useState<ASTDefinition[]>(SAMPLE_AST_DEFINITIONS);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSeverity, setSelectedSeverity] = useState('All');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedSection, setSelectedSection] = useState('All');
  const [isHowItWorksOpen, setIsHowItWorksOpen] = useState(false);
  const [isPipelineModalOpen, setIsPipelineModalOpen] = useState(false);
  const [isDownloadModalOpen, setIsDownloadModalOpen] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [pipelineProgress, setPipelineProgress] = useState(100);
  const [currentPipelineStage, setCurrentPipelineStage] = useState(8);

  const toggleResolveIssue = (id: string) => {
    setIssues(prev => prev.map(issue => 
      issue.id === id ? { ...issue, resolved: !issue.resolved } : issue
    ));
    if (selectedIssue && selectedIssue.id === id) {
      setSelectedIssue(prev => prev ? { ...prev, resolved: !prev.resolved } : null);
    }
  };

  const toggleRule = (id: string) => {
    setRules(prev => prev.map(rule => 
      rule.id === id ? { ...rule, enabled: !rule.enabled } : rule
    ));
  };

  const loadSampleDocs = () => {
    setOldDoc(SAMPLE_OLD_DOCUMENT);
    setNewDoc(SAMPLE_NEW_DOCUMENT);
    setIssues(SAMPLE_ISSUES);
  };

  const runAnalysisSimulation = () => {
    setIsAnalyzing(true);
    setIsPipelineModalOpen(true);
    setPipelineProgress(0);
    setCurrentPipelineStage(1);

    const stageDuration = 600;
    for (let i = 1; i <= 8; i++) {
      setTimeout(() => {
        setCurrentPipelineStage(i);
        setPipelineProgress(Math.round((i / 8) * 100));
        if (i === 8) {
          setIsAnalyzing(false);
        }
      }, i * stageDuration);
    }
  };

  return (
    <AnalysisContext.Provider value={{
      activeTab,
      setActiveTab,
      oldDoc,
      newDoc,
      setOldDoc,
      setNewDoc,
      issues,
      selectedIssue,
      setSelectedIssue,
      rules,
      toggleRule,
      astDefinitions,
      searchQuery,
      setSearchQuery,
      selectedSeverity,
      setSelectedSeverity,
      selectedCategory,
      setSelectedCategory,
      selectedSection,
      setSelectedSection,
      toggleResolveIssue,
      isHowItWorksOpen,
      setIsHowItWorksOpen,
      isPipelineModalOpen,
      setIsPipelineModalOpen,
      isDownloadModalOpen,
      setIsDownloadModalOpen,
      isAnalyzing,
      pipelineProgress,
      currentPipelineStage,
      runAnalysisSimulation,
      loadSampleDocs
    }}>
      {children}
    </AnalysisContext.Provider>
  );
};

export const useAnalysis = () => {
  const context = useContext(AnalysisContext);
  if (!context) {
    throw new Error('useAnalysis must be used within an AnalysisProvider');
  }
  return context;
};
