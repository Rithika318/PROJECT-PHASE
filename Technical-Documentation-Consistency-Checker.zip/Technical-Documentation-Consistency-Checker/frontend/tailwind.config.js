/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        navy: {
          900: '#111827',
          800: '#1F2937',
          700: '#374151',
        },
        indigo: {
          50: '#EEF2FF',
          100: '#E0E7FF',
          500: '#6366F1',
          600: '#4F46E5',
          700: '#4338CA',
        },
        violet: {
          500: '#8B5CF6',
          600: '#7C3AED',
          700: '#6D28D9',
        },
        teal: {
          400: '#2DD4BF',
          500: '#14B8A6',
          600: '#0D9488',
        },
        cyan: {
          400: '#22D3EE',
          500: '#06B6D4',
        },
        lavender: '#F1EEFF',
        paleblue: '#EAF4FF',
        appbg: '#F6F7FF',
        // Discrepancy Category Colors
        category: {
          consistent: '#10B981',      // Green
          contradiction: '#EF4444',   // Coral / Red
          outdated: '#F59E0B',        // Amber
          missing: '#3B82F6',         // Blue
          terminology: '#8B5CF6',     // Purple
        }
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto', 'sans-serif'],
        mono: ['JetBrains Mono', 'Fira Code', 'Menlo', 'monospace'],
      }
    },
  },
  plugins: [],
}
