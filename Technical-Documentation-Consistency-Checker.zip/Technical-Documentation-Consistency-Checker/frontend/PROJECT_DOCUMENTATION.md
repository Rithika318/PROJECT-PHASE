﻿# AI-Based Technical Documentation Consistency Detection and Analysis System
**Final-Year Engineering Project • System Design, Implementation & Audit Specification**

---

## 1. Project Abstract & Objectives
Technical documentation and API specifications frequently drift out of synchronization with production source-code repositories and evolutionary release versions. Such discrepancies cause developer onboarding friction, client integration outages, and critical breaking changes.

This project implements a **100% offline, local AI-driven technical documentation consistency detection system** that:
1. Ingests and parses multi-format documents (PDF, Markdown, HTML, Plain Text).
2. Extracts technical entities: REST endpoints, HTTP methods, parameter names, data types, authentication mechanisms, operational quotas, and version flags.
3. Analyzes semantic and syntactic representations using a **Custom Lightweight Transformer NLP Model trained from scratch** on technical documentation datasets.
4. Cross-verifies extracted documentation entities against both updated document revisions and live source-code **Abstract Syntax Tree (AST)** definitions.
5. Accurately detects and classifies inconsistencies, outdated information, and missing content.
6. Computes an objective, multi-factor Consistency Score and produces a formal engineering audit report with line-specific corrections.

---

## 2. Hard Constraints & Academic Integrity Compliance
- **Zero External AI APIs**: The system uses NO OpenAI, Google Gemini, Anthropic, or external inference APIs.
- **Zero Pre-trained Checkpoints**: The model uses NO BERT, GPT, RoBERTa, or Hugging Face pre-trained weights.
- **Custom Architecture**: A 4-layer Transformer Encoder with 4 self-attention heads and a 128-dimensional embedding space, trained strictly from randomly initialized weights on technical documentation corpora.
- **Local Execution**: Standalone client and local tensor pipeline operating without internet dependency.

---

## 3. End-to-End Architectural Pipeline
```
[ Document A: Baseline ]            [ Document B: Updated ]
          │                                   │
          ▼                                   ▼
┌─────────────────────────────────────────────────────────────┐
│             Stage 1: Multi-Format Ingestion                 │
│         (PDF, Markdown, HTML, Plain Text files)             │
└──────────────────────────────┬──────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────┐
│          Stage 2 & 3: Structural & AST Tokenization         │
│      Sections, Code Blocks, Signatures, Query & Headers     │
└──────────────────────────────┬──────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────┐
│     Stage 4: Custom Lightweight Transformer NLP Model       │
│    (4-Layer Multi-Head Self-Attention, Trained from Scratch)│
└──────────────────────────────┬──────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────┐
│    Stage 5: Technical Information & Entity Extraction       │
│      (BIO-tagged parameters, data types, endpoints, schemas) │
└──────────────────────────────┬──────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────┐
│           Stage 6: Consistency Verification Engine          │
│    Cross-checks Doc vs Doc & Doc vs Source Code AST         │
└──────────────────────────────┬──────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────┐
│          Stage 7: Issue Classification & Severity           │
│     Inconsistency (8 High) • Outdated (17 Med) • (12 Low)   │
└──────────────────────────────┬──────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────┐
│       Stage 8: Consistency Index & Audit Generation         │
│          Overall Score: 78% • Executive Report Export       │
└─────────────────────────────────────────────────────────────┘
```

---

## 4. Key Failure Categories Detected
1. **Inconsistency / Mismatch**:
   - Parameter data type shifts (e.g., `id: integer` ➔ `id: string UUIDv4`).
   - Renamed parameter identifiers (e.g., `q` ➔ `query`).
   - Multicurrency constraints (e.g., `USD only` ➔ `ISO-4217 multi-currency`).
   - HTTP status code shifts (e.g., `HTTP 400` ➔ `HTTP 401 Unauthorized`).
2. **Outdated Information**:
   - Deprecated protocol versions (e.g., `API v1.0` ➔ `API v2.0`).
   - Obsolete authentication headers (e.g., OAuth 1.0 cookies ➔ Bearer JWT).
   - Insecure cryptographic algorithms (e.g., `HMAC-MD5` ➔ `HMAC-SHA256`).
   - Changed quotas and limits (e.g., `5 MB` ➔ `10 MB`).
3. **Missing Content**:
   - Undocumented newly deployed endpoints (e.g., `DELETE /api/v2/users/{user_id}`).
   - Missing mandatory headers (e.g., `Idempotency-Key`, `Content-MD5`).
   - Undocumented enum expansion states (`suspended`, `archived`).

---

## 5. Running the Project Locally

### Prerequisites
- Node.js >= 18 LTS
- npm >= 9.x
- (Optional for Python model script) Python 3.9+ and PyTorch

### Setup Instructions
```bash
# 1. Navigate to project root
cd doc-consistency-dashboard

# 2. Install dependencies
npm install

# 3. Start local development server
npm run dev

# 4. Access the web dashboard
http://localhost:5173/

# 5. Build production bundle
npm run build
```
